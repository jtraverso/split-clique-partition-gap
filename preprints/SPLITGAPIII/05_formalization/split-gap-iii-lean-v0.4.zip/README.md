# Split Gap III · Lean supplement for review draft 0.4

This source archive includes the project and its local libraries. The Lake manifest pins external dependencies. The audit entry point is SplitGapIIIAudit.lean. Its 77 recorded declaration reports are in AUDIT.txt. They were obtained with Lean 4.35.0-rc3 and previously compiled dependencies. The two-scale asymptotic refinement in manuscript 0.5 belongs to the written proof.

## Reproduction

With the pinned toolchain and Git available, from the extracted directory run

```sh
lake exe cache get
lake build SplitGapIII
lake env lean SplitGapIIIAudit.lean
```

SHA256SUMS identifies the files in this archive. The table below records the formal coverage.

## Cobertura de la versión 0.4

El manuscrito inglés distingue el grafo que sobrevive al borrado del soporte seleccionado en el Teorema 5. Los siguientes resultados pertenecen al árbol activo de la versión 0.4.

| Declaración en `SplitGapIII` | Qué verifica y qué datos recibe |
| --- | --- |
| `clique_integer_switch_generation`, `hosted_switch_mem`, `hosted_clique_deficit_mem` | Las ecuaciones enteras de margen cero bastan para generar el déficit mediante intercambios con dos anclas. Si los cuatro triángulos de cada intercambio existen en el soporte seleccionado, el déficit pertenece al retículo físico de ese soporte. |
| `physical_hinges_ge_completions`, `selected_hinge_condition` | Inyección de las completaciones ordenadas de seis vértices en los conjuntos reales de aristas auxiliares. Una cota inferior por pareja de triángulos incidentes implica la hipótesis H4 de T+. |
| `alternating_same_basePool`, `alternating_same_ownedBlock`, `alternating_candidates_one_block` | Clasifica las cuatro bases alternadas. Usa el grupo de cada anfitrión y las condiciones de propiedad de cada base, incluidas las restricciones del segundo orden. Vale también antes de elegir la asignación. |
| `hosted_pasch_alternates`, `hosted_pasch_one_block` | Parten del predicado `TypedTriangle.Pasch.IsPasch` sobre las cuatro ternas concretas con anfitrión. Recuperan los dos emparejamientos alternados y, a partir de la propiedad local de cada base, identifican un solo bloque para las cuatro ternas. |
| `selected_decomposition_with_reference_targets` | Aplica el T+ publicado sobre un mismo soporte con H1, H2, H3 y suficientes completaciones para H4. Obtiene una misma descomposición para todos los monitores y Pasch. Hay que suministrar el error de comparación entre cada objetivo de referencia y el objetivo de la semilla. |

Siguen en el manuscrito la deducción probabilística de los cortes y de las disponibilidades comunes, el ensamblaje de todas las hipótesis en ambos modelos, la aplicación de coloración ponderada al umbral óptimo y la comparación asintótica con los objetivos anteriores al borrado. El informe de axiomas es una comprobación de las declaraciones invocadas por la auditoría.

