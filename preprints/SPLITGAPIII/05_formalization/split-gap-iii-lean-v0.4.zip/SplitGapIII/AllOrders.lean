module

public import SplitGapIII.OriginalOrder
public import Mathlib.Data.Nat.Sqrt

@[expose] public section

namespace SplitGapIII

open Finset GapExtremal GapExtremal.R434 GapExtremal.R434.EHPS QuadraticExteriorPalomar
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal Topology

noncomputable section

local instance (m j : ℕ) : DecidableEq (PartICore m j) :=
  inferInstanceAs (DecidableEq (H54.Role × ProductGrid m j))

local instance (m j k : ℕ) : DecidableEq (OldHost m j k) := Classical.typeDecidableEq _

variable {ε : ℝ} {m j k s q : ℕ} [NeZero m]
variable {W : Type} [Fintype W] [DecidableEq W]

/-- Recover the same residual score without deleting a radio. -/
theorem original_gap_without_deletions (hm : Odd m) (cs : PartICylinders ε m j)
    (hk : 0 < k) (hs : 0 < s) (hw : Fintype.card (PartICore m j) ≤ Fintype.card W)
    (a : ℝ) (ha : a < 1) (hold : 2 ≤ a * k) (hnew : (Fintype.card W : ℝ) ≤ a * s) :
    gap (hostGraph (witnessPalettes (W := W) (oldPalettes (k := k) cs) (fun x => x.1.1) s q)) =
      residualSup (withIsolates (X := W) (partIResidual ε m j)) -
        residualInt (withIsolates (X := W) (partIResidual ε m j)) := by
  classical
  let keep (_ : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W)) : Set Unit := Set.univ
  have before : witnessLive cs keep () =
      witnessPalettes (oldPalettes (k := k) cs) (fun x => x.1.1) s q := by
    funext h
    simp [witnessLive, keep]
  obtain ⟨sel⟩ := recover_witness_from_counts hm cs hk hs hw keep () a hold hnew (by
    intro e
    have hn : 0 < #(witnessAvailable (k := k) (s := s) (q := q) cs e) := by
      rcases e with e | e | e
      · simpa only [witnessAvailable, card_map] using
          card_pos.mpr (oldBaseHosts_positive (oldRequestGroup cs e) k hk)
      · simpa only [witnessAvailable, card_map, card_univ, Fintype.card_fin] using hs
      · simpa only [witnessAvailable, card_map, card_univ, Fintype.card_fin] using hs
    have hc : 0 < (#(witnessAvailable (k := k) (s := s) (q := q) cs e) : ℝ) := by
      exact_mod_cast hn
    simpa [surviving_hosts, keep] using mul_lt_mul_of_pos_right ha hc)
  rw [← before]
  exact gap_eq_residual_difference (assembled_host_hyp (partIResidual ε m j) (fun x => x.1.1)
    (fun _ _ he => H54.core_is_tripartite _ _ he) (oldPalettes cs) (witnessLive cs keep ())
    (by intro b x hx; rw [before] at hx; exact hx) sel)

/-- Explicit parameters of the padded witness for a fixed survival threshold. -/
theorem original_parameters_all_orders {a : ℝ} (ha : 0 < a) {k : ℕ} (hk : 0 < k) :
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n →
      ∃ (m j w s q : ℕ) (_ : NeZero m) (cs : PartICylinders (7/(1080*(j : ℝ))) m j),
        Odd m ∧ 0 < s ∧ Fintype.card (PartICore m j) ≤ w ∧ (w : ℝ) ≤ a*s ∧
        Fintype.card ((PartICore m j ⊕ Fin w) ⊕ WitnessHosts (OldHost m j k) s q) = n ∧
        Nat.sqrt (n-1) + 1 ≤ min (k*m^(2*(j-1))) s := by
  obtain ⟨d, hd⟩ := exists_nat_gt (max 8 (16/a))
  have hd0 : 0 < d := by
    have hdR : (8 : ℝ) < d := (le_max_left _ _).trans_lt hd
    exact_mod_cast (show (0 : ℝ) < d by linarith)
  have hd8 : 8 ≤ d := by exact_mod_cast ((le_max_left 8 (16/a)).trans hd.le)
  have had : (16 : ℝ) ≤ a*d := by
    have hh := (le_max_right 8 (16/a)).trans hd.le
    exact mul_comm (d : ℝ) a ▸ (div_le_iff₀ ha).mp hh
  let M := max 25 (max (4*k) d)
  have hM25 : 25 ≤ M := le_max_left _ _
  have hMk : 4*k ≤ M := (le_max_left _ _).trans (le_max_right _ _)
  have hMd : d ≤ M := (le_max_right _ _).trans (le_max_right _ _)
  obtain ⟨N, hN⟩ := partI_cylinders_at_order M hM25
  refine ⟨max N 144, fun n hn => ?_⟩
  have hn144 : 144 ≤ n := (le_max_right _ _).trans hn
  obtain ⟨m,j,hm,hmOdd,hj,hbudget,_,⟨cs⟩,hfiber,_⟩ :=
    hN n ((le_max_left _ _).trans hn)
  letI : NeZero m := hm
  let v := Fintype.card (PartICore m j)
  let h := Fintype.card (OldHost m j k)
  let w := n/d
  have hov : v+h ≤ n/4 := by
    apply (Nat.le_div_iff_mul_le (by decide : 0 < 4)).2
    calc
      _ ≤ (k * (255 + 2880*j) * m^(2*j))*4 :=
        Nat.mul_le_mul_right 4 (original_host_budget (m := m) (j := j) hk)
      _ = (4*k) * ((255 + 2880*j) * m^(2*j)) := by ring
      _ ≤ M * ((255 + 2880*j) * m^(2*j)) := Nat.mul_le_mul_right _ hMk
      _ ≤ n := by simpa only [← Nat.mul_assoc] using hbudget
  have hv : v ≤ w := by
    apply (Nat.le_div_iff_mul_le hd0).2
    have hg : Fintype.card (ProductGrid m j) = m^(2*j) := by simp [ZMod.card, pow_mul, pow_two]
    have hv' : v = 15*m^(2*j) := by simp [v, PartICore, H54.Role, hg]
    calc
      v*d = d*15*m^(2*j) := by rw [hv']; ring
      _ ≤ M*(255+2880*j)*m^(2*j) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul hMd (by omega))
      _ ≤ n := hbudget
  have hw₈ : w ≤ n/8 := Nat.div_le_div_left hd8 (by decide)
  obtain ⟨s,q,hs,_,hnEq⟩ := original_padding_parameters v h w n hov hw₈
  have hspos : 0 < s := by omega
  have hws : (w : ℝ) ≤ a*s := by
    have hwN : w*d ≤ n := Nat.div_mul_le_self n d
    have hns : n ≤ 16*s := by omega
    refine le_of_mul_le_mul_right ?_ (by exact_mod_cast hd0 : (0:ℝ) < d)
    calc
      (w : ℝ)*d ≤ n := by exact_mod_cast hwN
      _ ≤ 16*s := by exact_mod_cast hns
      _ ≤ (a*d)*s := mul_le_mul_of_nonneg_right had (by positivity)
      _ = (a*s)*d := by ring
  have hbig : n ≤ (m^(2*(j-1)))^2 := by
    let i : Fin j := ⟨0, by omega⟩
    simpa only [product_grid_fiber_card] using hfiber i 0
  have hss : n ≤ s^2 := by
    have hs9 : 9 ≤ s := by omega
    have hns : n ≤ 9*s := by omega
    exact hns.trans (by simpa only [pow_two] using Nat.mul_le_mul_right s hs9)
  have hsq (u : ℕ) (hu : n ≤ u^2) : Nat.sqrt (n-1) + 1 ≤ u := by
    exact Nat.succ_le_of_lt (Nat.sqrt_lt.mpr (by rw [← pow_two]; omega))
  refine ⟨m,j,w,s,q,hm,cs,hmOdd,hspos,hv,hws,?_,le_min ?_ (hsq s hss)⟩
  · simp only [WitnessHosts, Fintype.card_sum, Fintype.card_fin]
    rw [Fintype.card_prod (Fin 3) (Fin s)]
    simp only [Fintype.card_fin]
    change v + w + (h + (3*s + (s + q))) = n
    omega
  · exact (hsq _ hbig).trans (by simpa only [one_mul] using Nat.mul_le_mul_right (m^(2*(j-1))) (show 1 ≤ k by omega))

/-- A fixed positive survival probability works at every sufficiently large order.
The comparison uses the original graph, with the same vertex labels after deletion. -/
theorem split_gap_recovery_all_orders {p : ℝ≥0∞} (hp₀ : 0 < p) (hp₁ : p ≤ 1) :
    ∃ (ρ : ℝ) (N k : ℕ), 0 ≤ ρ ∧ ρ < 1 ∧
      ∀ n : ℕ, N ≤ n →
        ∃ (m j w s q : ℕ) (_ : NeZero m) (cs : PartICylinders (7/(1080*(j : ℝ))) m j),
          Fintype.card ((PartICore m j ⊕ Fin w) ⊕ WitnessHosts (OldHost m j k) s q) = n ∧
          ∀ {Ω : Type} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
            (keep : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ Fin w) → Set Ω),
            (∀ r, MeasurableSet (keep r)) → iIndepSet keep μ → (∀ r, μ (keep r) = p) →
            μ.real {ω | gap (hostGraph (witnessLive cs keep ω)) ≠
              gap (hostGraph (witnessPalettes (W := Fin w)
                (oldPalettes (k := k) cs) (fun x => x.1.1) s q))} ≤
              (n : ℝ)^2 * ρ^(Nat.sqrt (n-1)+1) := by
  have hpne : p ≠ ⊤ := ne_of_lt (hp₁.trans_lt ENNReal.one_lt_top)
  have hpr : 0 < p.toReal := ENNReal.toReal_pos hp₀.ne' hpne
  have hpr₁ : p.toReal ≤ 1 := by
    simpa using ENNReal.toReal_mono ENNReal.one_ne_top hp₁
  let a := p.toReal^2/2
  have ha : 0 < a := by dsimp [a]; positivity
  have hsquare : p.toReal^2 ≤ 1 := by nlinarith [mul_nonneg hpr.le (sub_nonneg.mpr hpr₁)]
  obtain ⟨t, ht, hρ⟩ := exists_strict_tail_factor (p.toReal^2) a
    (by dsimp [a]; nlinarith only [sq_pos_of_pos hpr])
  let ρ := Real.exp (-t*a)*(1-p.toReal^2+p.toReal^2*Real.exp t)
  have hρ₀ : 0 ≤ ρ := by
    dsimp [ρ]
    exact mul_nonneg (Real.exp_nonneg _) (add_nonneg (sub_nonneg.mpr hsquare) (by positivity))
  obtain ⟨k, hk⟩ := exists_nat_gt (max 1 (2/a))
  have hkpos : 0 < k := by
    have hh := (le_max_left (1:ℝ) (2/a)).trans_lt hk
    exact_mod_cast (show (0:ℝ) < k by linarith)
  have hka : 2 ≤ a*k := by
    have hh := (div_le_iff₀ ha).mp ((le_max_right (1:ℝ) (2/a)).trans hk.le)
    simpa only [mul_comm] using hh
  obtain ⟨N, hN⟩ := original_parameters_all_orders ha hkpos
  refine ⟨ρ,N,k,hρ₀,hρ,fun n hn => ?_⟩
  obtain ⟨m,j,w,s,q,hm,cs,hmOdd,hs,hw,hws,hcard,hmin⟩ := hN n hn
  letI : NeZero m := hm
  have hw' : Fintype.card (PartICore m j) ≤ Fintype.card (Fin w) := by simpa using hw
  have hws' : (Fintype.card (Fin w) : ℝ) ≤ a*s := by simpa using hws
  have hncore : Fintype.card (PartICore m j) + Fintype.card (Fin w) ≤ n := by
    simp only [Fintype.card_sum] at hcard
    omega
  refine ⟨m,j,w,s,q,hm,cs,hcard,?_⟩
  intro Ω _ μ _ keep hmeas hind hp
  rw [original_gap_without_deletions hmOdd cs hkpos hs hw' a (by dsimp [a]; linarith) hka hws']
  have htprob := original_witness_probability μ hmOdd cs hkpos hs hw' keep hmeas hind p hp a t ht.le hka hws'
  apply htprob.trans
  apply (witness_tail_sum_le cs ρ hρ₀ hρ.le).trans
  have hNR : ((Fintype.card (PartICore m j) + Fintype.card (Fin w) : ℕ) : ℝ) ≤ n := by
    exact_mod_cast hncore
  exact mul_le_mul (by gcongr) (pow_le_pow_of_le_one hρ₀ hρ.le hmin) (by positivity) (by positivity)

theorem all_orders_error_tendsto_zero {ρ : ℝ} (hρ₀ : 0 ≤ ρ) (hρ₁ : ρ < 1) :
    Tendsto (fun n : ℕ => (n : ℝ)^2 * ρ^(Nat.sqrt (n-1)+1)) atTop (𝓝 0) := by
  apply tendsto_zero_of_polynomial_tests (fun n => Nat.sqrt (n-1)+1) ρ hρ₀ hρ₁
  filter_upwards [eventually_ge_atTop (1 : ℕ)] with n hn
  have h := Nat.lt_succ_sqrt (n-1)
  rw [← pow_two, Nat.succ_eq_add_one] at h
  omega

end
end SplitGapIII
