module

public import SplitGapIII.RadioSeed
public import Mathlib.Algebra.Order.BigOperators.Group.Finset
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.Positivity

/-! # A bounded real correction on the surviving host rectangles -/

@[expose] public section

namespace SplitGapIII

open Finset

variable {U V H : Type*} [Fintype U] [Fintype V] [Fintype H]
  [DecidableEq U] [DecidableEq V]

private def commonRectangle (A : H → Finset U) (B : H → Finset V)
    (u a : U) (v b : V) : Finset H :=
  univ.filter fun h => u ∈ A h ∧ a ∈ A h ∧ v ∈ B h ∧ b ∈ B h

/-- The four signed appearances of an entry after averaging over the anchors. -/
private def fourTerms (w : U → U → V → V → ℝ) (x a : U) (y b : V) : ℝ :=
  w x a y b - w a x y b - w x a b y + w a x b y

private theorem sum_skew_zero {X : Type*} [Fintype X] (f : X → X → ℝ) :
    (∑ i, ∑ j, (f i j - f j i)) = 0 := by
  simp only [sum_sub_distrib]
  exact sub_eq_zero.mpr (sum_comm ..)

/-- Splitting each rectangle uniformly among its eligible hosts gives the
prescribed base correction with zero radio margins and an explicit
entrywise bound. Repetitions of an endpoint cancel in the alternating sum. -/
theorem exists_bounded_radio_correction [Nonempty U] [Nonempty V]
    (A : H → Finset U) (B : H → Finset V) (D : U → V → ℝ)
    (hrow : ∀ u, ∑ v, D u v = 0) (hcol : ∀ v, ∑ u, D u v = 0)
    (q E : ℝ) (hq : 0 < q) (hE : 0 ≤ E) (hD : ∀ u v, |D u v| ≤ E)
    (hsupply : ∀ u a v b, q ≤ ((univ.filter fun h =>
      u ∈ A h ∧ a ∈ A h ∧ v ∈ B h ∧ b ∈ B h).card : ℝ)) :
    ∃ δ : H → U → V → ℝ,
      (∀ h x y, (x ∉ A h ∨ y ∉ B h) → δ h x y = 0) ∧
      (∀ h x, ∑ y, δ h x y = 0) ∧ (∀ h y, ∑ x, δ h x y = 0) ∧
      (∀ x y, ∑ h, δ h x y = D x y) ∧ (∀ h x y, |δ h x y| ≤ 4 * E / q) := by
  classical
  let C := commonRectangle A B
  have hC (u a : U) (v b : V) : q ≤ ((C u a v b).card : ℝ) := hsupply u a v b
  let w (h : H) (u a : U) (v b : V) : ℝ :=
    if h ∈ C u a v b then D u v / (C u a v b).card else 0
  have hmass (u a : U) (v b : V) : (∑ h, w h u a v b) = D u v := by
    have hp := hq.trans_le (hC u a v b)
    simp [w, sum_ite_mem, nsmul_eq_mul]
    field_simp
  have hbound (h : H) (u a : U) (v b : V) : |w h u a v b| ≤ E / q := by
    dsimp only [w]
    split_ifs
    · rw [abs_div, abs_of_nonneg (Nat.cast_nonneg (C u a v b).card : 0 ≤ ((C u a v b).card : ℝ))]
      exact div_le_div₀ hE (hD u v) hq (hC u a v b)
    · simpa using div_nonneg hE hq.le
  let N : ℝ := Fintype.card U * (Fintype.card V : ℝ)
  have hN : 0 < N := by dsimp [N]; positivity
  let δ (h : H) (x : U) (y : V) := (∑ a, ∑ b, fourTerms (w h) x a y b) / N
  refine ⟨δ, ?_, ?_, ?_, ?_, ?_⟩
  · intro h x y hout
    rcases hout with hx | hy <;> simp [δ, fourTerms, w, C, commonRectangle, *]
  · intro h x
    simp only [δ, ← sum_div]
    rw [sum_comm]
    apply (div_eq_zero_iff).mpr
    left
    apply sum_eq_zero
    intro a _
    convert sum_skew_zero (fun y b => w h x a y b - w h a x y b) using 1
    apply sum_congr rfl
    intro y _
    apply sum_congr rfl
    intro b _
    unfold fourTerms
    ring
  · intro h y
    simp only [δ, ← sum_div]
    apply (div_eq_zero_iff).mpr
    left
    calc
      _ = ∑ b, ∑ x, ∑ a, fourTerms (w h) x a y b := by
        have swap (x : U) : (∑ a, ∑ b, fourTerms (w h) x a y b) =
            ∑ b, ∑ a, fourTerms (w h) x a y b := sum_comm
        simp only [swap]
        exact sum_comm
      _ = 0 := by
        apply sum_eq_zero
        intro b _
        convert sum_skew_zero (fun x a => w h x a y b - w h x a b y) using 1
        apply sum_congr rfl
        intro x _
        apply sum_congr rfl
        intro a _
        unfold fourTerms
        ring
  · intro x y
    simp only [δ, ← sum_div]
    rw [sum_comm]
    have per (a : U) :
        (∑ h, ∑ b, fourTerms (w h) x a y b) =
        ∑ b, (D x y - D a y - D x b + D a b) := by
      rw [sum_comm]
      simp only [fourTerms, sum_add_distrib, sum_sub_distrib, hmass]
    simp only [per, sum_add_distrib, sum_sub_distrib, hrow, hcol, sum_const,
      card_univ, nsmul_eq_mul, sub_zero, add_zero, mul_zero, ← mul_sum]
    dsimp [N]
    field_simp
  · intro h x y
    have per (a : U) (b : V) : |fourTerms (w h) x a y b| ≤ 4 * E / q := by
      unfold fourTerms
      have h₁ := abs_le.mp (hbound h x a y b)
      have h₂ := abs_le.mp (hbound h a x y b)
      have h₃ := abs_le.mp (hbound h x a b y)
      have h₄ := abs_le.mp (hbound h a x b y)
      rw [show 4 * E / q = 4 * (E / q) by ring]
      exact abs_le.mpr ⟨by linarith, by linarith⟩
    dsimp only [δ]
    rw [abs_div, abs_of_pos hN, div_le_iff₀ hN]
    calc
      _ ≤ ∑ a, ∑ b, |fourTerms (w h) x a y b| :=
        (abs_sum_le_sum_abs _ _).trans (sum_le_sum fun a _ => abs_sum_le_sum_abs _ _)
      _ ≤ ∑ _a : U, ∑ _b : V, 4 * E / q := sum_le_sum fun a _ => sum_le_sum fun b _ => per a b
      _ = _ := by simp [N, nsmul_eq_mul]; ring

omit [Fintype U] [Fintype V] in
private theorem extend_rectangle_supply [Nontrivial U] [Nontrivial V]
    (A : H → Finset U) (B : H → Finset V) (q : ℝ)
    (hs : ∀ u a v b, u ≠ a → v ≠ b → q ≤ ((commonRectangle A B u a v b).card : ℝ))
    (u a : U) (v b : V) : q ≤ ((commonRectangle A B u a v b).card : ℝ) := by
  obtain ⟨u', hu'⟩ := exists_ne u
  obtain ⟨v', hv'⟩ := exists_ne v
  let a' := if u = a then u' else a
  let b' := if v = b then v' else b
  have h₁ : u ≠ a' := by
    by_cases he : u = a
    · simpa only [a', ite_eq_left he] using hu'.symm
    · simpa only [a', ite_eq_right he] using he
  have h₂ : v ≠ b' := by
    by_cases he : v = b
    · simpa only [b', ite_eq_left he] using hv'.symm
    · simpa only [b', ite_eq_right he] using he
  apply (hs u a' v b' h₁ h₂).trans
  exact_mod_cast card_le_card (show commonRectangle A B u a' v b' ⊆ commonRectangle A B u a v b from by
    intro h hm
    simp only [commonRectangle, mem_filter, mem_univ, true_and] at hm ⊢
    by_cases hu : u = a <;> by_cases hv : v = b <;> simp_all [a', b'])

/-- The averaged correction gives an exact positive seed as soon as the
four-vertex supply pays eight times the largest host size times the deficit. -/
theorem exists_positive_bipartite_seed [Nontrivial U] [Nontrivial V]
    (A : H → Finset U) (B : H → Finset V) (a : H → ℕ)
    (hA : ∀ h, (A h).card = a h) (hB : ∀ h, (B h).card = a h)
    (hU : ∀ u, (univ.filter fun h => u ∈ A h).card = Fintype.card V)
    (hV : ∀ v, (univ.filter fun h => v ∈ B h).card = Fintype.card U)
    (q E lo hi : ℝ) (hq : 0 < q) (hE : 0 ≤ E) (hlo : 0 < lo)
    (hhi : 0 < hi) (ha : ∀ h, lo ≤ (a h : ℝ) ∧ (a h : ℝ) ≤ hi)
    (hD : ∀ u v, |1 - ∑ h, rectangleSeed A B a h u v| ≤ E)
    (hpay : 8 * hi * E ≤ q)
    (hsupply : ∀ u b v c, u ≠ b → v ≠ c → q ≤ ((univ.filter fun h =>
      u ∈ A h ∧ b ∈ A h ∧ v ∈ B h ∧ c ∈ B h).card : ℝ)) :
    ∃ μ : H → U → V → ℝ,
      (∀ h u v, (u ∉ A h ∨ v ∉ B h) → μ h u v = 0) ∧
      (∀ h u, ∑ v, μ h u v = if u ∈ A h then 1 else 0) ∧
      (∀ h v, ∑ u, μ h u v = if v ∈ B h then 1 else 0) ∧
      (∀ u v, ∑ h, μ h u v = 1) ∧
      (∀ h u v, u ∈ A h → v ∈ B h →
        1 / (2 * hi) ≤ μ h u v ∧ μ h u v ≤ 1 / lo + 4 * E / q) := by
  let D (u : U) (v : V) := 1 - ∑ h, rectangleSeed A B a h u v
  obtain ⟨hrow, hcol⟩ := rectangleSeed_base_deficit_zero_margins A B a hA hB hU hV
  obtain ⟨δ, hout, hleft, hright, hbase, hbound⟩ :=
    exists_bounded_radio_correction A B D hrow hcol q E hq hE hD
      (extend_rectangle_supply A B q hsupply)
  obtain ⟨hL, hR⟩ := rectangleSeed_radio_margins A B a hA hB
  refine ⟨fun h u v => rectangleSeed A B a h u v + δ h u v, ?_, ?_, ?_, ?_, ?_⟩
  · intro h u v huv
    change rectangleSeed A B a h u v + δ h u v = 0
    rw [hout h u v huv, add_zero]
    rcases huv with hu | hv <;> simp [rectangleSeed, *]
  · intro h u
    rw [sum_add_distrib, hL, hleft, add_zero]
  · intro h v
    rw [sum_add_distrib, hR, hright, add_zero]
  · intro u v
    rw [sum_add_distrib, hbase]
    dsimp [D]
    ring
  · intro h u v hu hv
    simp only [rectangleSeed, hu, hv, and_self, ite_true]
    have hp := hlo.trans_le (ha h).1
    have hmin := inv_anti₀ hp (ha h).2
    have hmax := inv_anti₀ hlo (ha h).1
    have hsmall : 4 * E / q ≤ 1 / (2 * hi) := by
      apply (div_le_div_iff₀ hq (by positivity : 0 < 2 * hi)).mpr
      nlinarith only [hpay]
    have hid : 1 / (2 * hi) + 1 / (2 * hi) = hi⁻¹ := by field_simp; ring
    obtain ⟨hdlo, hdhi⟩ := abs_le.mp (hbound h u v)
    rw [one_div lo]
    constructor <;> linarith

end SplitGapIII
