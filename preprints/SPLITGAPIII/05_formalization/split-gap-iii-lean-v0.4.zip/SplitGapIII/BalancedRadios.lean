module

public import Mathlib.Combinatorics.Hall.Basic
public import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Fintype.BigOperators
public import Mathlib.Data.Fintype.Fin
public import Mathlib.Data.Finset.Sum

/-! # Integral factors of the surviving radios

The reduction to Hall uses one token for each available radio. The token can
stay unused, or pass a central slot to a host slot. -/

@[expose] public section

namespace SplitGapIII

open Finset

variable {U H E : Type*} [Fintype U] [Fintype H] [Fintype E]

/-- A distinct token for every available radio enforces capacity one.
The endpoint maps may be instantiated on a subtype of surviving pairs. -/
theorem exists_radio_factor_of_cuts [DecidableEq U] [DecidableEq H]
    (central : E → U) (host : E → H) (d : U → ℕ) (a : H → ℕ)
    (hbalance : ∑ u, d u = ∑ h, a h)
    (hcut : ∀ (X : Finset U) (Y : Finset H),
      (∑ u ∈ X, d u) ≤
        (univ.filter fun e : E => central e ∈ X ∧ host e ∉ Y).card + ∑ h ∈ Y, a h) :
    ∃ F : Finset E,
      (∀ u, (F.filter fun e => central e = u).card = d u) ∧
      (∀ h, (F.filter fun e => host e = h).card = a h) := by
  classical
  let L := Σ u, Fin (d u)
  let R := Σ h, Fin (a h)
  let adj : L ⊕ E → E ⊕ R → Prop := fun x y =>
    match x, y with
    | .inl u, .inl e => central e = u.1
    | .inl _, .inr _ => False
    | .inr e, .inl e' => e = e'
    | .inr e, .inr h => host e = h.1
  have hhall (s : Finset (L ⊕ E)) :
      s.card ≤ (univ.filter fun y => ∃ x ∈ s, adj x y).card := by
    let X := s.toLeft.image Sigma.fst
    let Y := s.toRight.image host
    let B := univ.filter fun e : E => central e ∈ X ∧ host e ∉ Y
    let T : Finset R := Y.sigma fun _ => univ
    have hdisjoint : Disjoint s.toRight B := by
      apply disjoint_left.mpr
      intro e he hb
      exact (mem_filter.mp hb).2.2 (mem_image_of_mem host he)
    have hleft : s.toLeft.card ≤ ∑ u ∈ X, d u := by
      calc
        s.toLeft.card ≤ (X.sigma fun u => (univ : Finset (Fin (d u)))).card := by
          apply card_le_card
          intro u hu
          exact mem_sigma.mpr ⟨mem_image_of_mem Sigma.fst hu, mem_univ _⟩
        _ = _ := by
          rw [card_sigma]
          simp only [card_univ, Fintype.card_fin]
    have hneigh : (s.toRight ∪ B).disjSum T ⊆
        univ.filter fun y => ∃ x ∈ s, adj x y := by
      intro y hy
      apply mem_filter.mpr
      refine ⟨mem_univ _, ?_⟩
      cases y with
      | inl e =>
        simp only [inl_mem_disjSum, mem_union] at hy
        rcases hy with he | hb
        · exact ⟨Sum.inr e, mem_toRight.mp he, rfl⟩
        · obtain ⟨u, hu, hue⟩ := mem_image.mp (mem_filter.mp hb).2.1
          exact ⟨Sum.inl u, mem_toLeft.mp hu, hue.symm⟩
      | inr h =>
        have hY : h.1 ∈ Y := (mem_sigma.mp (inr_mem_disjSum.mp hy)).1
        obtain ⟨e, he, hh⟩ := mem_image.mp hY
        exact ⟨Sum.inr e, mem_toRight.mp he, hh⟩
    have ht : T.card = ∑ h ∈ Y, a h := by
      change (Y.sigma fun h => (univ : Finset (Fin (a h)))).card = _
      rw [card_sigma]
      simp
    have hc := hcut X Y
    change (∑ u ∈ X, d u) ≤ B.card + ∑ h ∈ Y, a h at hc
    calc
      s.card ≤ ((s.toRight ∪ B).disjSum T).card := by
        rw [card_disjSum, card_union_of_disjoint hdisjoint, ht, ← card_toLeft_add_card_toRight (u := s)]
        omega
      _ ≤ _ := card_le_card hneigh
  obtain ⟨f, hfi, hf⟩ := (Fintype.all_card_le_filter_rel_iff_exists_injective adj).mp hhall
  have hcard : Fintype.card (L ⊕ E) = Fintype.card (E ⊕ R) := by
    simpa [L, R, Fintype.card_sigma, Nat.add_comm] using congrArg (· + Fintype.card E) hbalance
  have hfs := ((Fintype.bijective_iff_injective_and_card f).mpr ⟨hfi, hcard⟩).2
  let F : Finset E := univ.filter fun e => ∃ h : R, f (Sum.inr e) = Sum.inr h
  have hchosen (e : E) : e ∈ F ↔ ∃ h : R, f (Sum.inr e) = Sum.inr h := by simp [F]
  have hrequest (u : U) (j : Fin (d u)) :
      ∃ e : E, f (Sum.inl ⟨u, j⟩) = Sum.inl e ∧ central e = u := by
    have hl := hf (Sum.inl ⟨u, j⟩)
    cases he : f (Sum.inl ⟨u, j⟩) with
    | inl e => exact ⟨e, rfl, by simpa [he, adj] using hl⟩
    | inr x => simp [he, adj] at hl
  choose cr hcr hcru using hrequest
  have hreceives (h : H) (j : Fin (a h)) :
      ∃ e : E, f (Sum.inr e) = Sum.inr ⟨h, j⟩ ∧ host e = h := by
    obtain ⟨x, hx⟩ := hfs (Sum.inr ⟨h, j⟩)
    have hl := hf x
    rw [hx] at hl
    cases x with
    | inl u => simp [adj] at hl
    | inr e => exact ⟨e, hx, hl⟩
  choose hr hhr hhrh using hreceives
  refine ⟨F, ?_, ?_⟩
  · intro u
    rw [← Fintype.card_fin (d u), ← card_univ]
    symm
    apply card_nbij (cr u)
    · intro j _
      refine mem_filter.mpr ⟨hchosen _ |>.mpr ?_, hcru u j⟩
      have hl := hf (Sum.inr (cr u j))
      cases he : f (Sum.inr (cr u j)) with
      | inl e =>
        have heq : cr u j = e := by simpa [he, adj] using hl
        subst e
        cases hfi (he.trans (hcr u j).symm)
      | inr h => exact ⟨h, rfl⟩
    · intro j _ k _ he
      have hh := hfi ((hcr u j).trans (he ▸ (hcr u k).symm))
      have hs : (⟨u, j⟩ : Σ u, Fin (d u)) = ⟨u, k⟩ := Sum.inl.inj hh
      exact eq_of_heq (Sigma.mk.inj_iff.mp hs).2
    · intro e he
      have heF := mem_filter.mp he
      obtain ⟨h, hh⟩ := (hchosen _).mp heF.1
      obtain ⟨x, hx⟩ := hfs (Sum.inl e)
      have hl := hf x
      rw [hx] at hl
      cases x with
      | inl s =>
        obtain ⟨v, j⟩ := s
        have hv : central e = v := hl
        have hvu : v = u := hv.symm.trans heF.2
        clear hv
        subst v
        have hEq : cr u j = e := Sum.inl.inj ((hcr u j).symm.trans hx)
        exact ⟨j, mem_univ _, hEq⟩
      | inr z =>
        have hze : z = e := hl
        subst z
        rw [hh] at hx
        cases hx
  · intro h
    rw [← Fintype.card_fin (a h), ← card_univ]
    symm
    apply card_nbij (hr h)
    · intro j _
      exact mem_filter.mpr ⟨(hchosen _).mpr ⟨⟨h,j⟩, hhr h j⟩, hhrh h j⟩
    · intro j _ k _ he
      have hh := (hhr h j).symm.trans (he ▸ hhr h k)
      have hs : (⟨h, j⟩ : Σ h, Fin (a h)) = ⟨h, k⟩ := Sum.inr.inj hh
      exact eq_of_heq (Sigma.mk.inj_iff.mp hs).2
    · intro e he
      have heF := mem_filter.mp he
      obtain ⟨⟨h', j⟩, hh⟩ := (hchosen _).mp heF.1
      have hx := hf (Sum.inr e)
      rw [hh] at hx
      have hh' : host e = h' := hx
      have heq : h' = h := hh'.symm.trans heF.2
      clear hh'
      subst h'
      have hEq := Sum.inr.inj (hfi ((hhr h j).trans hh.symm))
      exact ⟨j, mem_univ _, hEq⟩

omit [Fintype E] in
/-- Realize the factor as host palettes on the original surviving pairs. -/
theorem exists_surviving_radio_palettes [DecidableEq U] [DecidableEq H]
    (available : Finset (U × H)) (d : U → ℕ) (a : H → ℕ)
    (hbalance : ∑ u, d u = ∑ h, a h)
    (hcut : ∀ (X : Finset U) (Y : Finset H),
      (∑ u ∈ X, d u) ≤
        (available.filter fun e => e.1 ∈ X ∧ e.2 ∉ Y).card + ∑ h ∈ Y, a h) :
    ∃ P : H → Finset U,
      (∀ h u, u ∈ P h → (u, h) ∈ available) ∧
      (∀ h, (P h).card = a h) ∧
      (∀ u, (univ.filter fun h => u ∈ P h).card = d u) := by
  classical
  let inc : available ↪ U × H := Function.Embedding.subtype _
  have hproject (F : Finset available) (q : U × H → Prop) [DecidablePred q] :
      ((F.map inc).filter q).card = (F.filter fun e => q e.val).card := by
    rw [filter_map, card_map]
    rfl
  obtain ⟨S, hSr, hSc⟩ := exists_radio_factor_of_cuts
    (fun e : available => e.val.1) (fun e : available => e.val.2) d a hbalance (by
      intro X Y
      rw [← hproject (univ : Finset available) (fun e => e.1 ∈ X ∧ e.2 ∉ Y)]
      simpa [inc, univ_eq_attach, attach_map_val] using hcut X Y)
  let F := S.map inc
  let P (h : H) : Finset U := univ.filter fun u => (u, h) ∈ F
  have hmem (u : U) (h : H) : u ∈ P h ↔ (u, h) ∈ F := by simp [P]
  refine ⟨P, ?_, ?_, ?_⟩
  · intro h u hu
    obtain ⟨e, _, he⟩ := mem_map.mp ((hmem u h).mp hu)
    exact he ▸ e.property
  · intro h
    rw [← hSc h, ← hproject S (fun e => e.2 = h)]
    symm
    apply card_nbij Prod.fst
    · intro e he
      have hf := mem_filter.mp he
      have heq : e = (e.1, h) := Prod.ext rfl hf.2
      exact (hmem _ _).mpr (heq ▸ hf.1)
    · intro e he e' he' hh
      exact Prod.ext hh ((mem_filter.mp he).2.trans (mem_filter.mp he').2.symm)
    · intro u hu
      exact ⟨(u, h), mem_filter.mpr ⟨(hmem _ _).mp hu, rfl⟩, rfl⟩
  · intro u
    rw [← hSr u, ← hproject S (fun e => e.1 = u)]
    symm
    apply card_nbij Prod.snd
    · intro e he
      have hf := mem_filter.mp he
      have heq : e = (u, e.2) := Prod.ext hf.2 rfl
      exact mem_filter.mpr ⟨mem_univ _, (hmem _ _).mpr (heq ▸ hf.1)⟩
    · intro e he e' he' hh
      exact Prod.ext ((mem_filter.mp he).2.trans (mem_filter.mp he').2.symm) hh
    · intro h hh
      exact ⟨(u, h), mem_filter.mpr ⟨(hmem _ _).mp (mem_filter.mp hh).2, rfl⟩, rfl⟩

end SplitGapIII

namespace SplitGapIII

open Finset

/-- Rounded host degrees of a prescribed total, with discrepancy at most one. -/
theorem rounded_host_degrees (mass r : ℕ) (hr : 0 < r) :
    ∃ a : Fin r → ℕ, (∑ h, a h = mass) ∧
      ∀ h, mass / r ≤ a h ∧ a h ≤ mass / r + 1 := by
  let a (h : Fin r) := mass / r + if h.val < mass % r then 1 else 0
  refine ⟨a, ?_, ?_⟩
  · simp only [a, sum_add_distrib, sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul,
      ← sum_filter, mul_one]
    rw [Fin.card_filter_val_lt, min_eq_right (Nat.mod_lt mass hr).le]
    exact Nat.div_add_mod mass r
  · intro h
    dsimp only [a]
    split <;> omega

/-- Even host degrees of the prescribed even total, with discrepancy at most two. -/
theorem rounded_even_host_degrees (halfMass r : ℕ) (hr : 0 < r) :
    ∃ a : Fin r → ℕ, (∑ h, a h = 2 * halfMass) ∧
      ∀ h, Even (a h) ∧ 2 * (halfMass / r) ≤ a h ∧ a h ≤ 2 * (halfMass / r) + 2 := by
  obtain ⟨a, ha, hb⟩ := rounded_host_degrees halfMass r hr
  refine ⟨fun h => 2 * a h, ?_, ?_⟩
  · change (∑ h, 2 * a h) = 2 * halfMass
    rw [← mul_sum, ha]
  · intro h
    obtain ⟨hl, hu⟩ := hb h
    change Even (2 * a h) ∧ 2 * (halfMass / r) ≤ 2 * a h ∧ 2 * a h ≤ 2 * (halfMass / r) + 2
    exact ⟨⟨a h, two_mul _⟩, by omega, by omega⟩

/-- The total loss in a common-neighbor set is bounded by the sum of the
individual palette losses. The index type can be a pair or a quadruple. -/
theorem common_hosts_after_losses {I H : Type*} [Fintype I] [DecidableEq H]
    (S : Finset H) (old kept : I → Finset H)
    [goodDec : DecidablePred fun h => ∀ i, h ∈ kept i]
    (hcommon : ∀ h ∈ S, ∀ i, h ∈ old i) :
    S.card ≤ (S.filter fun h => ∀ i, h ∈ kept i).card +
      ∑ i, ((old i) \ (kept i)).card := by
  classical
  let good := @Finset.filter H (fun h => ∀ i, h ∈ kept i) goodDec S
  let lost := univ.biUnion fun i => old i \ kept i
  have hc : S ⊆ good ∪ lost := by
    intro h hh
    by_cases hk : ∀ i, h ∈ kept i
    · exact mem_union_left _ (mem_filter.mpr ⟨hh, hk⟩)
    · obtain ⟨i, hi⟩ := not_forall.mp hk
      exact mem_union_right _ (mem_biUnion.mpr ⟨i, mem_univ _, mem_sdiff.mpr ⟨hcommon h hh i, hi⟩⟩)
  exact (card_le_card hc).trans ((card_union_le _ _).trans (Nat.add_le_add_left card_biUnion_le _))

end SplitGapIII
