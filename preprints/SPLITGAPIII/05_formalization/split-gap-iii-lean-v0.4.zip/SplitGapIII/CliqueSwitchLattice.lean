module

public import Mathlib

@[expose] public section
namespace SplitGapIII

open Finset
variable {V E : Type*} [Fintype V] [Fintype E] [DecidableEq V]

/-- Signed incidence at the chosen end of each oriented outside edge. -/
def endLoad (endpt : E → V) (z : E → ℤ) (i : V) : ℤ :=
  ∑ e, if endpt e = i then z e else 0

private theorem endLoad_eval {M : Type*} [AddCommGroup M] (k : E → V)
    (z : E → ℤ) (g : V → M) :
    ∑ i, endLoad k z i • g i = ∑ e, z e • g (k e) := by
  classical
  simp only [endLoad, Finset.sum_smul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  simp [ite_smul]

private theorem endLoad_sum (k : E → V) (z : E → ℤ) :
    ∑ i, endLoad k z i = ∑ e, z e := by
  classical
  simp only [endLoad]
  rw [Finset.sum_comm]
  simp

/-- Integral generation by four-point switches on a clique. Remove two
anchors; orient each remaining edge once, from l(e) to r(e). The edge vectors
may be the physical base indicators, or their images in any abelian group.
The hypotheses on L only request rectangular exchanges used by elimination. -/
theorem clique_integer_switch_generation {M : Type*} [AddCommGroup M]
    (L : AddSubgroup M) (t : V) (l r : E → V)
    (outside : E → M) (a b : V → M) (ab : M)
    (z : E → ℤ) (f g : V → ℤ) (zab : ℤ)
    (houtside : ∀ e, outside e + ab - a (l e) - b (r e) ∈ L)
    (hstar : ∀ i, i ≠ t → a i + b t - b i - a t ∈ L)
    (hv : ∀ i, f i + g i + endLoad l z i + endLoad r z i = 0)
    (ha : zab + ∑ i, f i = 0) (hb : zab + ∑ i, g i = 0) :
    (∑ e, z e • outside e) + (∑ i, f i • a i) + (∑ i, g i • b i) + zab • ab ∈ L := by
  classical
  let u i := f i + endLoad l z i
  have hneg i : g i + endLoad r z i = -u i := by dsimp [u]; linarith [hv i]
  have hs := Finset.sum_congr (s₁ := Finset.univ) rfl (fun i _ => hneg i)
  simp only [Finset.sum_add_distrib, endLoad_sum, Finset.sum_neg_distrib, u] at hs
  have hz : zab = ∑ e, z e := by omega
  have hu : ∑ i, u i = 0 := by simp only [u, Finset.sum_add_distrib, endLoad_sum]; omega
  have h₁ := L.sum_mem (t := Finset.univ)
    (fun e _ => L.zsmul_mem (houtside e) (z e))
  have hr i : a i + b t - b i - a t ∈ L := by
    by_cases hi : i = t
    · subst i
      convert L.zero_mem using 1
      abel
    · exact hstar i hi
  have h₂ := L.sum_mem (t := Finset.univ) (fun i _ => L.zsmul_mem (hr i) (u i))
  have hsum := L.add_mem h₁ h₂
  simp only [smul_add, smul_sub, Finset.sum_add_distrib, Finset.sum_sub_distrib,
    ← Finset.sum_smul, hu, zero_smul] at hsum
  have hA : ∑ i, u i • a i = (∑ i, f i • a i) + ∑ e, z e • a (l e) := by
    simp only [u, add_smul, Finset.sum_add_distrib, endLoad_eval]
  have hB : -(∑ i, u i • b i) = (∑ i, g i • b i) + ∑ e, z e • b (r e) := by
    rw [← Finset.sum_neg_distrib]
    simp only [← neg_smul, ← hneg, add_smul, Finset.sum_add_distrib, endLoad_eval]
  have hU := congrArg Neg.neg hB
  simp only [neg_neg] at hU
  rw [hA, hU, ← hz] at hsum
  convert hsum using 1
  abel

end SplitGapIII
