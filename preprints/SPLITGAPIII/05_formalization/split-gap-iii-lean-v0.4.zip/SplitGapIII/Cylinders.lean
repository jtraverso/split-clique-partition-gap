module

public import SplitGapIII.Reassignment

@[expose] public section

namespace SplitGapIII
open Finset

variable {I D : Type*}

/-- A required direction has a coordinate outside the old support. -/
theorem exists_factor_for_required_direction (A : Set D) (d : I → D)
    (required : ¬ ∀ i, d i ∈ A) : ∃ i, d i ∉ A := by
  classical
  simpa only [not_forall] using required

/-- Midpoint closure of one complemented coordinate suffices for an entire cylinder. -/
theorem cylinder_midpoint_outside (A C : Set D) (mid : D → D → D)
    (closed : ∀ a ∈ C, ∀ b ∈ C, mid a b ∉ A)
    (p : I) (u v : I → D) (hu : u p ∈ C) (hv : v p ∈ C) :
    ¬ ∀ i, mid (u i) (v i) ∈ A :=
  fun h => closed _ hu _ hv (h p)

/-- Once one coordinate of a center is fixed, all remaining coordinates are free. -/
def centerFiberEquiv [DecidableEq I] (p : I) (a : D) :
    {c : I → D // c p = a} ≃ ({i : I // i ≠ p} → D) where
  toFun c i := c.val i.val
  invFun c := ⟨fun i => if hi : i = p then a else c ⟨i, hi⟩, by simp⟩
  left_inv c := by
    apply Subtype.ext
    funext i
    by_cases h : i = p
    · subst i
      simpa using c.property.symm
    · simp [h]
  right_inv c := by
    funext i
    simp [i.property]

theorem centerFiber_card [Fintype I] [DecidableEq I] [Fintype D] [DecidableEq D]
    (p : I) (a : D) :
    Fintype.card {c : I → D // c p = a} = Fintype.card D ^ Fintype.card {i : I // i ≠ p} := by
  rw [Fintype.card_congr (centerFiberEquiv p a), Fintype.card_fun]

/-- Actual host lists on one cylinder can be colored whenever they reach its center-fiber size. -/
theorem recover_center_fiber [Fintype I] [DecidableEq I] [Fintype D] [DecidableEq D]
    {V H : Type*} [Finite V] [DecidableEq V] (N : H → Finset V) (J : Finset (Finset V))
    (p : I) (a : D) (left right : J → V) (center : J → I → D)
    (hc : ∀ e, center e p = a)
    (proper : GalvinMultigraph.Proper left right center)
    (ends : ∀ e, e.val = {left e, right e})
    (sides : ∀ e f, left e ≠ right f)
    (lists : J → Finset H)
    (physical : ∀ e h, h ∈ lists e → e.val ⊆ N h)
    (large : ∀ e, Fintype.card D ^ Fintype.card {i : I // i ≠ p} ≤ (lists e).card) :
    ∃ host : J → H, Assigned N J host := by
  let tag (e : J) : {c : I → D // c p = a} := ⟨center e, hc e⟩
  have hp : GalvinMultigraph.Proper left right tag := by
    intro e f hne hside heq
    exact proper e f hne hside (congrArg Subtype.val heq)
  apply recover_physical_bipartite_group N J left right tag ends sides hp lists physical
  simpa only [centerFiber_card] using large

end SplitGapIII
