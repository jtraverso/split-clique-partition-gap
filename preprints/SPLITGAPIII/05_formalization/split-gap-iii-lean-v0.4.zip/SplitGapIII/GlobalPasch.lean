module

public import SplitGapIII.TwoOrderPasch
public import Mathlib.Data.Sym.Sym2

@[expose] public section

namespace SplitGapIII

/-- Only the slice of a padding vertex or the role of an original vertex is
needed to determine the first level of block ownership. -/
inductive BasePool (Slice Color Role : Type*)
  | terminal
  | mixed (slice : Slice) (color : Color)
  | original (roles : Sym2 Role)

variable {Slice Color Role : Type*}

def basePool (color : Role → Color) :
    Sum Slice Role → Sum Slice Role → BasePool Slice Color Role
  | .inl _, .inl _ => .terminal
  | .inl s, .inr r | .inr r, .inl s => .mixed s (color r)
  | .inr a, .inr b => .original s(a,b)

/-- Each host uses one pool. The two alternating matchings in a Pasch
therefore have the same terminal pool, slice/color pool or unordered role pair. -/
theorem alternating_same_basePool (color : Role → Color) (a b c d : Sum Slice Role)
    (h : basePool color a b = basePool color c d)
    (k : basePool color a d = basePool color c b) :
    basePool color a b = basePool color a d := by
  cases a <;> cases b <;> cases c <;> cases d <;>
    simp_all [basePool]
  grind [Sym2.eq_iff]

variable {A : Type*} [AddCommGroup A] {S : Set A} {j : ℕ}

/-- In a hard role pair, coordinates are oriented from the first role to the
second. Prefix endpoints determine the center. The class is the partition
label of the failed direction, as in the construction. -/
noncomputable def ownedBlockKey {Band : Type*} (label : A → Band) (p : TwoOrderPaschPool S j)
    (u v : ℕ → A) : TwoOrderStage j × Band × (ℕ → Option (A × A)) := by
  classical
  exact (p.stage, label (v p.stage.failure - u p.stage.failure),
    fun i : ℕ => if p.stage.observes i then some (u i, v i) else none)

theorem alternating_same_ownedBlock {Band : Type*} (label : A → Band)
    (hdouble : Function.Injective (fun x : A => x + x))
    (p q : TwoOrderPaschPool S j) (a b c d : ℕ → A)
    (hab : p.Owns a b) (hcd : p.Owns c d) (had : q.Owns a d) (hcb : q.Owns c b) :
    ownedBlockKey label p a b = ownedBlockKey label p c d ∧
    ownedBlockKey label p a b = ownedBlockKey label q a d ∧
    ownedBlockKey label p a b = ownedBlockKey label q c b := by
  classical
  obtain ⟨hs, hcoords⟩ := alternating_two_order_same_prefix hdouble p q hab hcd had hcb
  have observed : p.stage.observes p.stage.failure := by
    cases e : p.stage <;> simp [TwoOrderStage.observes, TwoOrderStage.failure]
  have key_eq (t : TwoOrderPaschPool S j) (x y : ℕ → A) (ht : t.stage = p.stage)
      (hxy : ∀ i, p.stage.observes i → a i = x i ∧ b i = y i) :
      ownedBlockKey label p a b = ownedBlockKey label t x y := by
    obtain ⟨hx, hy⟩ := hxy _ observed
    simp only [ownedBlockKey, ht, hx, hy, Prod.mk.injEq, true_and]
    funext i
    by_cases hi : p.stage.observes i
    · simp [hi, (hxy i hi).1, (hxy i hi).2]
    · simp [hi]
  exact ⟨key_eq p c d rfl (fun i hi => ⟨(hcoords i hi).1, (hcoords i hi).2.1⟩),
    key_eq q a d hs.symm (fun i hi => ⟨rfl, (hcoords i hi).2.1⟩),
    key_eq q c b hs.symm (fun i hi => ⟨(hcoords i hi).1, rfl⟩)⟩


/-- A hard type has a fixed first and second role. This distinction orients
the coordinates before the two-order ownership test is applied. -/
private theorem hard_orientations {color : Role → Color} {u v x y : Sum Slice Role}
    {l r : Role} (hne : l ≠ r)
    (h₁ : basePool color u v = .original s(l,r))
    (h₂ : basePool color x y = .original s(l,r))
    (h₃ : basePool color u y = .original s(l,r))
    (h₄ : basePool color x v = .original s(l,r)) :
    (u = .inr l ∧ v = .inr r ∧ x = .inr l ∧ y = .inr r) ∨
    (u = .inr r ∧ v = .inr l ∧ x = .inr r ∧ y = .inr l) := by
  cases u <;> cases v <;> cases x <;> cases y <;> simp_all [basePool]
  grind

variable {Vertex Band : Type*}
noncomputable def orientedEnds (zone : Vertex → Sum Slice Role)
    (pos : Vertex → ℕ → A) (l : Role) (u v : Vertex) : (ℕ → A) × (ℕ → A) := by
  classical
  exact if zone u = Sum.inr l then (pos u,pos v) else (pos v,pos u)

/-- Physical block identifier of an individual candidate. Easy pairs need
only their coarse pool. A hard pair also needs its stage, class and fibers. -/
noncomputable def candidateBlock (color : Role → Color) (zone : Vertex → Sum Slice Role)
    (pos : Vertex → ℕ → A) (hard : BasePool Slice Color Role → Option (Role × Role))
    (band : A → Band) (p : TwoOrderPaschPool S j) (u v : Vertex) := 
  let k := basePool color (zone u) (zone v)
  (k, (hard k).map fun lr =>
    let ends := orientedEnds zone pos lr.1 u v
    ownedBlockKey band p ends.1 ends.2)

/-- The complete block interface for a hosted Pasch in alternating form.
The four hypotheses on hard ownership concern individual candidate bases.
The result is consequently valid also when no assignment has been chosen. -/
theorem alternating_candidates_one_block (color : Role → Color)
    (zone : Vertex → Sum Slice Role) (pos : Vertex → ℕ → A)
    (hard : BasePool Slice Color Role → Option (Role × Role)) (band : A → Band)
    (hr : ∀ k l r, hard k = some (l,r) → l ≠ r ∧ k = .original s(l,r))
    (hdouble : Function.Injective (fun x : A => x+x))
    (p q : TwoOrderPaschPool S j) (u v x y : Vertex)
    (hp : basePool color (zone u) (zone v) = basePool color (zone x) (zone y))
    (hq : basePool color (zone u) (zone y) = basePool color (zone x) (zone v))
    (own : ∀ l r, hard (basePool color (zone u) (zone v)) = some (l,r) →
      let pair := orientedEnds zone pos l
      p.Owns (pair u v).1 (pair u v).2 ∧ p.Owns (pair x y).1 (pair x y).2 ∧
      q.Owns (pair u y).1 (pair u y).2 ∧ q.Owns (pair x v).1 (pair x v).2) :
    let key := candidateBlock color zone pos hard band
    key p u v = key p x y ∧ key p u v = key q u y ∧ key p u v = key q x v := by
  classical
  have h := alternating_same_basePool color _ _ _ _ hp hq
  dsimp only
  unfold candidateBlock
  simp only [← hq, ← h, ← hp]
  cases he : hard (basePool color (zone u) (zone v)) with
  | none => simp
  | some lr =>
    obtain ⟨l,r⟩ := lr
    obtain ⟨hne, hk⟩ := hr _ _ _ he
    obtain ⟨h₁,h₂,h₃,h₄⟩ := own _ _ he
    obtain ho | ho := hard_orientations hne hk (hp.symm.trans hk)
      (h.symm.trans hk) (hq.symm.trans (h.symm.trans hk))
    · obtain ⟨hu,hv,hx,hy⟩ := ho
      simp [orientedEnds, hu,hx] at h₁ h₂ h₃ h₄ ⊢
      exact alternating_same_ownedBlock band hdouble p q _ _ _ _ h₁ h₂ h₃ h₄
    · obtain ⟨hu,hv,hx,hy⟩ := ho
      simp [orientedEnds, hu,hx, hne.symm] at h₁ h₂ h₃ h₄ ⊢
      obtain ⟨ha,hb,hc⟩ := alternating_same_ownedBlock band hdouble p q _ _ _ _ h₁ h₂ h₄ h₃
      exact ⟨ha,hc,hb⟩

end SplitGapIII
