module

public import SplitGapIII.CliqueSwitchLattice
public import RequestProject.TypedTriangle.SparseEdgeDefs
public import RequestProject.TypedTriangle.Lattice

@[expose] public section
namespace SplitGapIII

open Finset TypedTriangle

noncomputable section
open Classical
variable {X I : Type}

def baseUnit (u v : X) : Sym2 X → ℤ := ind {s(u,v)}

private theorem triangle_units {H : Host X I} {F : Set (Multiset I)} {u v h : X}
    (ht : IsAllowed H F {u,v,h}) :
    ind (triEdges {u,v,h}) = baseUnit u v + baseUnit u h + baseUnit v h := by
  obtain ⟨huv,huh,hvh⟩ := distinct_of_card_three ht.1
  have ht' : triEdges {u,v,h} = insert s(u,v) (wedge u v h) :=
    SparseEdge.triEdges_triple huv huh hvh
  rw [ht']
  funext e
  simp only [baseUnit, ind, wedge, mem_insert, mem_singleton, Pi.add_apply]
  have h₁ : s(u,v) ≠ s(u,h) := by simp [*]
  have h₂ : s(u,v) ≠ s(v,h) := by simp [*]
  have h₃ : s(u,h) ≠ s(v,h) := by simp [*]
  grind

/-- Four allowed triangles at one host implement an integral switch entirely
on the bases. All four crossing loads cancel in the actual physical lattice. -/
theorem hosted_switch_mem {H : Host X I} {F : Set (Multiset I)} {u v a b h : X}
    (h₁ : IsAllowed H F {u,v,h}) (h₂ : IsAllowed H F {a,b,h})
    (h₃ : IsAllowed H F {u,a,h}) (h₄ : IsAllowed H F {v,b,h}) :
    baseUnit u v + baseUnit a b - baseUnit u a - baseUnit v b ∈ lattice H F := by
  have hm (x y : X) (hxy : IsAllowed H F {x,y,h}) :
      baseUnit x y + baseUnit x h + baseUnit y h ∈ lattice H F := by
    rw [← triangle_units hxy]
    exact isPhysical_triEdges hxy
  have hsum := (lattice H F).sub_mem ((lattice H F).sub_mem
    ((lattice H F).add_mem (hm _ _ h₁) (hm _ _ h₂)) (hm _ _ h₃)) (hm _ _ h₄)
  convert hsum using 1
  abel

/-- A signed base deficit with zero vertex sums is physically correctable.
The outside edges are oriented once. Each required elementary correction
uses a common host in the selected graph. -/
theorem hosted_clique_deficit_mem {O E : Type*} [Fintype O] [Fintype E] [DecidableEq O]
    (H : Host X I) (F : Set (Multiset I)) (x : O → X) (a b : X) (t : O)
    (l r : E → O) (z : E → ℤ) (f g : O → ℤ) (zab : ℤ)
    (ho : ∀ e, ∃ h, IsAllowed H F {x (l e),x (r e),h} ∧ IsAllowed H F {a,b,h} ∧
      IsAllowed H F {x (l e),a,h} ∧ IsAllowed H F {x (r e),b,h})
    (hs : ∀ i, i ≠ t → ∃ h, IsAllowed H F {x i,a,h} ∧ IsAllowed H F {x t,b,h} ∧
      IsAllowed H F {x i,b,h} ∧ IsAllowed H F {x t,a,h})
    (hv : ∀ i, f i + g i + endLoad l z i + endLoad r z i = 0)
    (ha : zab + ∑ i, f i = 0) (hb : zab + ∑ i, g i = 0) :
    (∑ e, z e • baseUnit (x (l e)) (x (r e))) + (∑ i, f i • baseUnit (x i) a) +
      (∑ i, g i • baseUnit (x i) b) + zab • baseUnit a b ∈ lattice H F := by
  apply clique_integer_switch_generation (lattice H F).toAddSubgroup t l r _ _ _ _ z f g zab
      _ _ hv ha hb
  · intro e
    obtain ⟨h,h₁,h₂,h₃,h₄⟩ := ho e
    exact hosted_switch_mem h₁ h₂ h₃ h₄
  · intro i hi
    obtain ⟨h,h₁,h₂,h₃,h₄⟩ := hs i hi
    have hc (v w : X) : baseUnit v w = baseUnit w v := by
      unfold baseUnit
      rw [Sym2.eq_swap]
    have h₂' : IsAllowed H F {b,x t,h} := by rwa [Finset.insert_comm]
    have h₄' : IsAllowed H F {a,x t,h} := by rwa [Finset.insert_comm]
    have hh := hosted_switch_mem h₁ h₂' h₃ h₄'
    rw [hc b (x t),hc a (x t)] at hh
    exact hh

end
end SplitGapIII
