module

public import RequestProject.TypedTriangle.PaschEmbedding
public import RequestProject.TypedTriangle.PaschRootedInfluence
public import SplitGapIII.GlobalPasch

@[expose] public section
namespace SplitGapIII
open Finset TypedTriangle.Pasch
variable {C H : Type*} [DecidableEq C] [DecidableEq H]

def hostTriple (h : H) (u v : C) : Finset (C ⊕ H) :=
  {Sum.inl u, Sum.inl v, Sum.inr h}

private theorem finish_rectangle {S : Finset (Finset (C ⊕ H))} (hS : IsPasch S)
    {h k : H} {u v x y : C}
    (huv : u ≠ v) (hux : u ≠ x) (huy : u ≠ y) (hvx : v ≠ x) (hvy : v ≠ y)
    (hxy : x ≠ y) (hhk : h ≠ k)
    (a : hostTriple h u v ∈ S) (b : hostTriple h x y ∈ S) (c : hostTriple k u y ∈ S) :
    S = {hostTriple h u v, hostTriple k u y, hostTriple k x v, hostTriple h x y} := by
  let f : Fin 6 → C ⊕ H := ![Sum.inl u, Sum.inl x, Sum.inl v, Sum.inl y, Sum.inr h, Sum.inr k]
  have hi : Function.Injective f := by
    intro i j e
    fin_cases i <;> fin_cases j <;> simp_all [f]
  have hp : IsPasch {hostTriple h u v, hostTriple k u y, hostTriple k x v, hostTriple h x y} := by
    simpa [gridImage,gridPasch,f,hostTriple] using gridImage_isPasch f hi
  apply hS.eq_of_common_triple hp (K := {hostTriple h u v, hostTriple h x y, hostTriple k u y})
  · have neq (s t : Finset (C ⊕ H)) (z : C ⊕ H) (hs : z ∈ s) (ht : z ∉ t) : s ≠ t :=
      fun eq => ht (eq ▸ hs)
    have ab := neq _ _ (.inl u) (by simp [hostTriple] : Sum.inl u ∈ hostTriple h u v)
      (by simp [hostTriple,hux,huy] : Sum.inl u ∉ hostTriple h x y)
    have ac := neq _ _ (.inr h) (by simp [hostTriple] : Sum.inr h ∈ hostTriple h u v)
      (by simp [hostTriple,hhk] : Sum.inr h ∉ hostTriple k u y)
    have bc := neq _ _ (.inr h) (by simp [hostTriple] : Sum.inr h ∈ hostTriple h x y)
      (by simp [hostTriple,hhk] : Sum.inr h ∉ hostTriple k u y)
    simp [ab,ac,bc]
  · simpa only [insert_subset_iff,singleton_subset_iff] using And.intro a (And.intro b c)
  · intro T ht
    simp only [mem_insert,mem_singleton] at ht ⊢
    tauto

/-- Classification on the literal configuration finset; it applies before a
packing is chosen. The fourth triangle is forced by the other three. -/
theorem hosted_pasch_alternates {S : Finset (Finset (C ⊕ H))} (hS : IsPasch S)
    (hosted : ∀ T ∈ S, ∃ h u v, u ≠ v ∧ T = hostTriple h u v) :
    ∃ (h k : H) (u v x y : C), h ≠ k ∧
      S = {hostTriple h u v, hostTriple k u y, hostTriple k x v, hostTriple h x y} := by
  obtain ⟨Q,hQ⟩ := card_pos.mp (show 0 < S.card by rw [hS.1]; decide)
  obtain ⟨h,u,v,huv,rfl⟩ := hosted Q hQ
  obtain ⟨A,⟨hA,haQ,hha⟩,_⟩ := exists_unique_other hS hQ
    (by simp [hostTriple] : Sum.inr h ∈ hostTriple h u v)
  obtain ⟨h',x,y,hxy,rfl⟩ := hosted A hA
  have hh' : h = h' := by simpa [hostTriple] using hha
  subst h'
  have outside (z : C) (hz : Sum.inl z ∈ hostTriple h u v) :
      Sum.inl z ∉ hostTriple h x y := by
    intro hza
    exact haQ (eq_of_common_pair hS.2.2.2.2 hA hQ (Sum.inl_ne_inr : Sum.inl z ≠ Sum.inr h)
      hza (by simp [hostTriple]) hz (by simp [hostTriple]))
  have ou := outside u (by simp [hostTriple])
  have ov := outside v (by simp [hostTriple])
  simp [hostTriple] at ou ov
  obtain ⟨B,⟨hB,hbQ,huB⟩,_⟩ := exists_unique_other hS hQ
    (by simp [hostTriple] : Sum.inl u ∈ hostTriple h u v)
  obtain ⟨k,i,j,hij,rfl⟩ := hosted B hB
  have hhk : h ≠ k := by
    rintro rfl
    exact hbQ (eq_of_common_pair hS.2.2.2.2 hB hQ (Sum.inl_ne_inr : Sum.inl u ≠ Sum.inr h)
      huB (by simp [hostTriple]) (by simp [hostTriple]) (by simp [hostTriple]))
  have hba : hostTriple k i j ≠ hostTriple h x y := by
    intro eq
    rw [eq] at huB
    simp [hostTriple,ou] at huB
  obtain ⟨z,hz⟩ := inter_nonempty hS hB hA hba
  obtain ⟨hzB,hzA⟩ := mem_inter.mp hz
  have hswap (a : H) (s t : C) : hostTriple a s t = hostTriple a t s := Finset.insert_comm ..
  have hm : i = x ∨ i = y ∨ j = x ∨ j = y := by
    cases z with
    | inl z =>
      simp [hostTriple] at hzB hzA
      rcases hzB with rfl|rfl <;> tauto
    | inr z =>
      simp [hostTriple] at hzB hzA
      exact (hhk (hzA.symm.trans hzB)).elim
  have hb : hostTriple k u x ∈ S ∨ hostTriple k u y ∈ S := by
    simp [hostTriple] at huB
    rcases huB with rfl|rfl
    · rcases hm with he|he|rfl|rfl
      · exact (ou.1 he).elim
      · exact (ou.2 he).elim
      · exact Or.inl hB
      · exact Or.inr hB
    · rw [hswap] at hB
      rcases hm with rfl|rfl|he|he
      · exact Or.inl hB
      · exact Or.inr hB
      · exact (ou.1 he).elim
      · exact (ou.2 he).elim
  rcases hb with hx | hy
  · rw [hswap] at hA
    exact ⟨h,k,u,v,y,x,hhk,finish_rectangle hS huv ou.2 ou.1 ov.2 ov.1 hxy.symm hhk hQ hA hx⟩
  · exact ⟨h,k,u,v,x,y,hhk,finish_rectangle hS huv ou.1 ou.2 ov.1 ov.2 hxy hhk hQ hA hy⟩

/-- Passage from a literal T+ Pasch to a single block. The input constraints
are per candidate: membership in its host's pool and ownership of its base. -/
theorem hosted_pasch_one_block {A Slice Role Color Band : Type*} [AddCommGroup A]
    {directions : Set A} {j : ℕ} (color : Role → Color) (zone : C → Sum Slice Role)
    (pos : C → ℕ → A) (hard : BasePool Slice Color Role → Option (Role × Role))
    (tag : H → BasePool Slice Color Role) (pool : H → TwoOrderPaschPool directions j)
    (band : A → Band) (hd : Function.Injective (fun a : A => a+a))
    (hr : ∀ k l r, hard k = some (l,r) → l ≠ r ∧ k = .original s(l,r))
    {S : Finset (Finset (C ⊕ H))} (hS : IsPasch S)
    (hs : ∀ T ∈ S, ∃ h u v, u ≠ v ∧ T = hostTriple h u v)
    (ht : ∀ h u v, hostTriple h u v ∈ S → basePool color (zone u) (zone v) = tag h)
    (ho : ∀ h u v l r, hostTriple h u v ∈ S → hard (tag h) = some (l,r) →
      let e := orientedEnds zone pos l u v
      (pool h).Owns e.1 e.2) :
    ∃ (h k : H) (u v x y : C), h ≠ k ∧
      S = {hostTriple h u v, hostTriple k u y, hostTriple k x v, hostTriple h x y} ∧
      let key := candidateBlock color zone pos hard band
      key (pool h) u v = key (pool h) x y ∧ key (pool h) u v = key (pool k) u y ∧
      key (pool h) u v = key (pool k) x v := by
  obtain ⟨h,k,u,v,x,y,hk,he⟩ := hosted_pasch_alternates hS hs
  have a : hostTriple h u v ∈ S := by rw [he]; simp
  have b : hostTriple h x y ∈ S := by rw [he]; simp
  have c : hostTriple k u y ∈ S := by rw [he]; simp
  have d : hostTriple k x v ∈ S := by rw [he]; simp
  have hp := (ht _ _ _ a).trans (ht _ _ _ b).symm
  have hq := (ht _ _ _ c).trans (ht _ _ _ d).symm
  have hc := alternating_same_basePool color _ _ _ _ hp hq
  refine ⟨h,k,u,v,x,y,hk,he,alternating_candidates_one_block color zone pos hard band hr hd
    (pool h) (pool k) u v x y hp hq ?_⟩
  intro l r hl
  have hh := hl
  rw [ht _ _ _ a] at hh
  rw [hc,ht _ _ _ c] at hl
  exact ⟨ho _ _ _ _ _ a hh,ho _ _ _ _ _ b hh,ho _ _ _ _ _ c hl,ho _ _ _ _ _ d hl⟩

end SplitGapIII
