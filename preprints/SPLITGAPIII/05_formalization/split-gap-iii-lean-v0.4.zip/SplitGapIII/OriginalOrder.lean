module

public import SplitGapIII.OriginalProbability

@[expose] public section

namespace SplitGapIII

open Finset GapExtremal GapExtremal.R434 GapExtremal.R434.EHPS

noncomputable section

local instance (m j : ℕ) : DecidableEq (PartICore m j) :=
  inferInstanceAs (DecidableEq (H54.Role × ProductGrid m j))

variable {ε : ℝ} {m j k : ℕ} [NeZero m]

theorem original_host_budget (hk : 0 < k) :
    Fintype.card (PartICore m j) + Fintype.card (OldHost m j k) ≤
      k * (255 + 2880*j) * m^(2*j) := by
  have hgrid : Fintype.card (ProductGrid m j) = m^(2*j) := by
    simp [ZMod.card, pow_mul, pow_two]
  have hrole : Fintype.card H54.Role = 15 := by simp [H54.Role]
  have hlabel : Fintype.card (CylinderLabel j) = 24*j := by simp [CylinderLabel, Nat.mul_comm]
  have hs : Fintype.card (Sym2 H54.Role) = 120 := by rw [Sym2.card, hrole]; decide
  simp only [PartICore, OldHost, Fintype.card_prod, Fintype.card_option,
    Fintype.card_fin, hrole, hgrid, hs, hlabel]
  have hconst : 15 + 120*k ≤ 255*k := by omega
  calc
    _ = (15 + 120*k + 2880*k*j) * m^(2*j) := by ring
    _ ≤ _ := Nat.mul_le_mul_right _ (by nlinarith only [hconst])

theorem witness_test_count {W : Type} [Fintype W] [DecidableEq W] :
    Fintype.card (WitnessTest ε m j W) ≤ (Fintype.card (PartICore m j) + Fintype.card W)^2 := by
  classical
  have hold : Fintype.card (OldRequest ε m j) ≤ (Fintype.card (PartICore m j))^2 := by
    rw [pow_two, ← Fintype.card_prod]
    exact Fintype.card_le_of_injective (fun e => (oldLeft e, oldRight e)) (by
      intro e f h
      apply Subtype.ext
      change (oldLeft e, oldRight e) = (oldLeft f, oldRight f) at h
      rw [(oldEndpoints e).2, (oldEndpoints f).2]
      exact congrArg (fun p : PartICore m j × PartICore m j => ({p.1,p.2} : Finset (PartICore m j))) h)
  have hlast : Fintype.card (⊤ : SimpleGraph W).edgeSet ≤ (Fintype.card W)^2 := by
    rw [pow_two, ← Fintype.card_prod]
    exact Fintype.card_le_of_injective (fun e => (terminalLeft e, terminalRight e)) (by
      intro e f h
      apply Subtype.ext
      change (terminalLeft e, terminalRight e) = (terminalLeft f, terminalRight f) at h
      have he : e.val = s(terminalLeft e, terminalRight e) := (terminal_endpoints e).choose_spec.choose_spec.2
      have hf : f.val = s(terminalLeft f, terminalRight f) := (terminal_endpoints f).choose_spec.choose_spec.2
      rw [he, hf]
      exact congrArg (fun p : W × W => s(p.1,p.2)) h)
  simp only [WitnessTest, Fintype.card_sum]
  rw [Fintype.card_prod (PartICore m j) W]
  nlinarith only [hold, hlast, Nat.zero_le (Fintype.card (PartICore m j) * Fintype.card W)]

/-- Four equally sized pools and fewer than four extra labels fill the exact order. -/
theorem original_padding_parameters (v h w n : ℕ) (hold : v + h ≤ n/4) (hw : w ≤ n/8) :
    ∃ s q : ℕ, n/8 ≤ s ∧ q < 4 ∧ v + w + h + 4*s + q = n := by
  exact ⟨(n-(v+h+w))/4, (n-(v+h+w))%4, by omega, by omega, by omega⟩

theorem old_group_minimum (g : OldGroup m j) : m ^ (2*(j-1)) ≤ #(oldGroupCenters g) := by
  classical
  rcases g with ⟨r, - | ⟨l,x⟩⟩
  · have hm : 0 < m := Nat.pos_of_ne_zero (NeZero.ne m)
    have he : oldGroupCenters (m := m) (j := j) (r, none) = univ := by ext c; simp [oldGroupCenters]
    rw [he, card_univ]
    change _ ≤ Fintype.card (Fin j → ZMod m × ZMod m)
    rw [Fintype.card_fun, Fintype.card_fin, Fintype.card_prod, ZMod.card]
    rw [← pow_two, ← pow_mul]
    exact Nat.pow_le_pow_right hm (by omega)
  · have hfilter : oldGroupCenters (r, some (l,x)) = univ.filter (fun d : ProductGrid m j => d l.1 = x) := by
      ext d
      simp [oldGroupCenters]
    rw [hfilter]
    have heq : {d : ProductGrid m j // d ∈ univ.filter (fun d : ProductGrid m j => d l.1 = x)} ≃
        {d : ProductGrid m j // d l.1 = x} :=
      Equiv.subtypeEquivRight (fun _ => by simp)
    rw [← Fintype.card_coe, Fintype.card_congr heq, product_grid_fiber_card]

theorem witness_tail_sum_le {s q : ℕ} {W : Type} [Fintype W] [DecidableEq W]
    (cs : PartICylinders ε m j) (r : ℝ) (hr₀ : 0 ≤ r) (hr₁ : r ≤ 1) :
    (∑ e : WitnessTest ε m j W, r ^ (witnessAvailable (k := k) (s := s) (q := q) cs e).card) ≤
      ((Fintype.card (PartICore m j) + Fintype.card W : ℕ) : ℝ)^2 * r ^ min (k*m^(2*(j-1))) s := by
  classical
  let K := min (k*m^(2*(j-1))) s
  have hmin (e : WitnessTest ε m j W) : K ≤ (witnessAvailable (k := k) (s := s) (q := q) cs e).card := by
    rcases e with e | e | e
    · simp only [witnessAvailable, card_map, oldBaseHosts_card]
      exact (min_le_left _ _).trans (Nat.mul_le_mul_left k (old_group_minimum (oldRequestGroup cs e)))
    · simpa only [witnessAvailable, card_map, card_univ, Fintype.card_fin] using (min_le_right (k*m^(2*(j-1))) s)
    · simpa only [witnessAvailable, card_map, card_univ, Fintype.card_fin] using (min_le_right (k*m^(2*(j-1))) s)
  calc
    _ ≤ ∑ _e : WitnessTest ε m j W, r ^ K := sum_le_sum fun e _ => pow_le_pow_of_le_one hr₀ hr₁ (hmin e)
    _ = (Fintype.card (WitnessTest ε m j W) : ℝ) * r^K := by simp [nsmul_eq_mul]
    _ ≤ _ := mul_le_mul_of_nonneg_right (by exact_mod_cast (witness_test_count (ε := ε) (m := m) (j := j) (W := W)))
      (pow_nonneg hr₀ _)

end
end SplitGapIII
