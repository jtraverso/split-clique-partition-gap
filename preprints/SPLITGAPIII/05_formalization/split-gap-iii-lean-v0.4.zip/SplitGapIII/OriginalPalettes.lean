module

public import SplitGapIII.PartIWitness
public import SplitGapIII.SharedSeed

@[expose] public section

namespace SplitGapIII

open Finset GapExtremal GapExtremal.R434 GapExtremal.R434.EHPS

noncomputable section

local instance (m j : ℕ) : DecidableEq (PartICore m j) :=
  inferInstanceAs (DecidableEq (H54.Role × ProductGrid m j))

abbrev CylinderLabel (j : ℕ) := Fin j × PlaneLabel
abbrev OldHost (m j k : ℕ) := Sym2 H54.Role × Option (CylinderLabel j) × ProductGrid m j × Fin k
abbrev OldGroup (m j : ℕ) := Sym2 H54.Role × Option (CylinderLabel j × Grid m)

variable {ε : ℝ} {m j k : ℕ} [NeZero m]

def oldHostGroup (b : OldHost m j k) : OldGroup m j :=
  (b.1, b.2.1.map fun l => (l, b.2.2.1 l.1))

def oldCenter (u v : PartICore m j) : ProductGrid m j := productHalf m j * (u.2 + v.2)

def oldDirection (u v : PartICore m j) : ProductGrid m j :=
  pairDirection (H54.roleStep (productHalf m j)) u v

def cylinderLabel (cs : PartICylinders ε m j) (a : ProductGrid m j) : Option (CylinderLabel j) :=
  if ha : a ∉ productSupport ε m j then
    some ((cs.cover a ha).choose, (cs.cover a ha).choose_spec.choose)
  else none

theorem cylinderLabel_spec (cs : PartICylinders ε m j) {a : ProductGrid m j}
    (ha : a ∉ productSupport ε m j) :
    ∃ l : CylinderLabel j, cylinderLabel cs a = some l ∧ a l.1 ∈ cs.bands l.2 := by
  let l : CylinderLabel j := ((cs.cover a ha).choose, (cs.cover a ha).choose_spec.choose)
  exact ⟨l, by simp [cylinderLabel, ha, l], (cs.cover a ha).choose_spec.choose_spec⟩

def oldPairGroup (cs : PartICylinders ε m j) (u v : PartICore m j) : OldGroup m j :=
  (s(u.1,v.1), if H54.roleGraph.Adj u.1 v.1 then
      (cylinderLabel cs (oldDirection u v)).map fun l => (l, oldCenter u v l.1)
    else none)

theorem oldPairGroup_swap (cs : PartICylinders ε m j) (u v : PartICore m j) :
    oldPairGroup cs u v = oldPairGroup cs v u := by
  have hadj : H54.roleGraph.Adj u.1 v.1 ↔ H54.roleGraph.Adj v.1 u.1 := ⟨fun h => h.symm, fun h => h.symm⟩
  have hdir : oldDirection u v = oldDirection v u :=
    (pairDirection_swap _ (H54.roleStep_swap _) _ _).symm
  simp only [oldPairGroup, hadj, hdir, oldCenter, add_comm u.2 v.2, Sym2.eq_swap]

/-- A host sees the endpoints of all required pairs of its own cylinder and center fiber. -/
def oldPalettes (cs : PartICylinders ε m j) (b : OldHost m j k) : Finset (PartICore m j) := by
  classical
  exact univ.filter fun u => ∃ v, u ≠ v ∧ ¬ (partIResidual ε m j).Adj u v ∧
    oldPairGroup cs u v = oldHostGroup b

theorem oldPalettes_pair (cs : PartICylinders ε m j) {b : OldHost m j k}
    {u v : PartICore m j} (hne : u ≠ v) (hn : ¬ (partIResidual ε m j).Adj u v)
    (hg : oldPairGroup cs u v = oldHostGroup b) :
    u ∈ oldPalettes cs b ∧ v ∈ oldPalettes cs b := by
  classical
  refine ⟨mem_filter.mpr ⟨mem_univ _, v, hne, hn, hg⟩, mem_filter.mpr ⟨mem_univ _, u, hne.symm,
    fun hv => hn hv.symm, (oldPairGroup_swap cs v u).trans hg⟩⟩

theorem oldPalettes_independent (hm : Odd m) (cs : PartICylinders ε m j)
    (b : OldHost m j k) {x y : PartICore m j}
    (hx : x ∈ oldPalettes cs b) (hy : y ∈ oldPalettes cs b) :
    ¬ (partIResidual ε m j).Adj x y := by
  classical
  intro hab
  change H54.roleGraph.Adj x.1 y.1 ∧ oldDirection x y ∈ productSupport ε m j at hab
  obtain ⟨x', _, hxx, hxg⟩ := (mem_filter.mp hx).2
  obtain ⟨y', _, hyy, hyg⟩ := (mem_filter.mp hy).2
  have eq := hxg.trans hyg.symm
  have roles : s(x.1,x'.1) = s(y.1,y'.1) := congrArg Prod.fst eq
  rcases Sym2.eq_iff.mp roles with ⟨he, _⟩ | ⟨hr, hs⟩
  · exact H54.roleGraph.loopless.irrefl _ (he ▸ hab.1)
  · have ax : H54.roleGraph.Adj x.1 x'.1 := hs.symm ▸ hab.1
    have ay : H54.roleGraph.Adj y.1 y'.1 := hr ▸ hab.1.symm
    have dx : oldDirection x x' ∉ productSupport ε m j := fun h => hxx ⟨ax,h⟩
    have dy : oldDirection y y' ∉ productSupport ε m j := fun h => hyy ⟨ay,h⟩
    obtain ⟨l, hl, bl⟩ := cylinderLabel_spec cs dx
    obtain ⟨l', hl', bl'⟩ := cylinderLabel_spec cs dy
    have same : (l, oldCenter x x' l.1) = (l', oldCenter y y' l'.1) := by
      simpa only [oldPairGroup, ite_eq_left ax, ite_eq_left ay, hl, hl', Option.map_some,
        Option.some.injEq] using congrArg Prod.snd eq
    obtain ⟨hle, hc⟩ := Prod.mk.inj same
    subst l'
    let proj (u : PartICore m j) : H54.Role × Grid m := (u.1, u.2 l.1)
    let half : Grid m := (oddHalf m, oddHalf m)
    have hh : 2 * half = 1 := Prod.ext (two_mul_oddHalf hm) (two_mul_oddHalf hm)
    have hdir := direction_of_cross_fibre
      (fun a d => H54.roleStep (productHalf m j) a d l.1) half
      (fun a d => congrFun (H54.roleStep_swap (productHalf m j) a d) l.1) hh
      (proj x) (proj x') (proj y) (proj y') hr hs hc
    change oldDirection x y l.1 = half * (oldDirection x x' l.1 + oldDirection y y' l.1) at hdir
    let u := Function.update (oldDirection x y) l.1 (oldDirection x x' l.1)
    let v := Function.update (oldDirection x y) l.1 (oldDirection y y' l.1)
    apply cs.closed l.1 l.2 u v (by simpa [u] using bl) (by simpa [v] using bl')
    have heq : productHalf m j * (u + v) = oldDirection x y := by
      funext i
      change half * (u i + v i) = oldDirection x y i
      by_cases hi : i = l.1
      · subst i
        simpa [u, v] using hdir.symm
      · simp only [u, v, Function.update_of_ne hi]
        rw [← two_mul, ← mul_assoc, mul_comm half (2 : Grid m), hh, one_mul]
    rw [heq]
    exact hab.2

abbrev OldRequest (ε : ℝ) (m j : ℕ) [NeZero m] := (jPairs (partIResidual ε m j) univ : Type)

theorem oldRequest_endpoints (e : OldRequest ε m j) :
    ∃ u v, u ≠ v ∧ e.val = {u,v} := card_eq_two.mp (two_of_mem_jPairs e.property)

def oldLeft (e : OldRequest ε m j) := (oldRequest_endpoints e).choose
def oldRight (e : OldRequest ε m j) := (oldRequest_endpoints e).choose_spec.choose

theorem oldEndpoints (e : OldRequest ε m j) :
    oldLeft e ≠ oldRight e ∧ e.val = {oldLeft e, oldRight e} :=
  (oldRequest_endpoints e).choose_spec.choose_spec

def oldRequestGroup (cs : PartICylinders ε m j) (e : OldRequest ε m j) : OldGroup m j :=
  oldPairGroup cs (oldLeft e) (oldRight e)

def oldRequestCenter (e : OldRequest ε m j) : ProductGrid m j := oldCenter (oldLeft e) (oldRight e)

def oldGroupCenters (g : OldGroup m j) : Finset (ProductGrid m j) := by
  classical
  exact univ.filter fun c => ∀ z ∈ g.2, c z.1.1 = z.2

theorem oldCenter_mem (cs : PartICylinders ε m j) (e : OldRequest ε m j) :
    oldRequestCenter e ∈ oldGroupCenters (oldRequestGroup cs e) := by
  classical
  apply mem_filter.mpr
  refine ⟨mem_univ _, ?_⟩
  dsimp only [oldRequestGroup, oldPairGroup]
  split
  · cases cylinderLabel cs (oldDirection (oldLeft e) (oldRight e)) <;>
      simp [oldRequestCenter]
  · simp

private theorem oldPair_cancel (hm : Odd m) (cs : PartICylinders ε m j) (u v z : PartICore m j)
    (hg : oldPairGroup cs u v = oldPairGroup cs u z) (hc : oldCenter u v = oldCenter u z) : v = z := by
  have hr := congrArg Prod.fst hg
  have hre : v.1 = z.1 := (Sym2.eq_iff.mp hr).elim And.right
    (fun h => h.2.trans h.1)
  exact Prod.ext hre (midpoint_partner_unique _ _ _ _ (productHalf_spec hm) hc)

private theorem oldRequest_orient (e : OldRequest ε m j) {x : PartICore m j} (h : x ∈ e.val) :
    ∃ z, e.val = {x,z} ∧ ∀ cs : PartICylinders ε m j,
      oldRequestGroup cs e = oldPairGroup cs x z ∧ oldRequestCenter e = oldCenter x z := by
  rw [(oldEndpoints e).2, mem_insert, mem_singleton] at h
  rcases h with rfl | rfl
  · exact ⟨oldRight e, (oldEndpoints e).2, fun _ => ⟨rfl,rfl⟩⟩
  · refine ⟨oldLeft e, (oldEndpoints e).2.trans (pair_comm _ _), fun cs => ⟨oldPairGroup_swap cs _ _, ?_⟩⟩
    simp [oldRequestCenter, oldCenter, add_comm (oldLeft e).2 (oldRight e).2]

def oldIncident (cs : PartICylinders ε m j) (g : OldGroup m j) (x : PartICore m j) :
    Finset (OldRequest ε m j) := by
  classical
  exact univ.filter fun e => oldRequestGroup cs e = g ∧ x ∈ e.val

theorem oldIncidence_bound (hm : Odd m) (cs : PartICylinders ε m j) (g : OldGroup m j)
    (x : PartICore m j) :
    #(oldIncident cs g x) ≤ #(oldGroupCenters g) := by
  classical
  let S := univ.filter fun e : OldRequest ε m j => oldRequestGroup cs e = g ∧ x ∈ e.val
  have hsub : S.image oldRequestCenter ⊆ oldGroupCenters g := by
    intro z hz
    obtain ⟨e, he, rfl⟩ := mem_image.mp hz
    rw [← (mem_filter.mp he).2.1]
    exact oldCenter_mem cs e
  have hinj : Set.InjOn (oldRequestCenter (ε := ε) (m := m) (j := j)) (↑S : Set _) := by
    intro e he f hf hcen
    obtain ⟨he1, he2⟩ := (mem_filter.mp (show e ∈ S from he)).2
    obtain ⟨hf1, hf2⟩ := (mem_filter.mp (show f ∈ S from hf)).2
    obtain ⟨a, ha, ha'⟩ := oldRequest_orient e he2
    obtain ⟨b, hb, hb'⟩ := oldRequest_orient f hf2
    have eq := oldPair_cancel hm cs x a b ((ha' cs).1.symm.trans (he1.trans (hf1.symm.trans (hb' cs).1)))
      ((ha' cs).2.symm.trans (hcen.trans (hb' cs).2))
    apply Subtype.ext
    rw [ha, hb, eq]
  simpa only [S, oldIncident, card_image_of_injOn hinj] using card_le_card hsub

def oldBaseHosts (g : OldGroup m j) (k : ℕ) : Finset (OldHost m j k) := by
  classical
  exact ((oldGroupCenters g) ×ˢ (univ : Finset (Fin k))).image fun z => (g.1, g.2.map Prod.fst, z.1, z.2)

theorem oldBaseHosts_card (g : OldGroup m j) (k : ℕ) :
    #(oldBaseHosts g k) = k * #(oldGroupCenters g) := by
  classical
  unfold oldBaseHosts
  rw [card_image_of_injective _ (fun _ _ h => Prod.ext (congrArg (fun b : OldHost m j k => b.2.2.1) h)
    (congrArg (fun b : OldHost m j k => b.2.2.2) h)), card_product, card_univ, Fintype.card_fin, Nat.mul_comm]

theorem oldBaseHosts_group {g : OldGroup m j} {b : OldHost m j k} (hb : b ∈ oldBaseHosts g k) :
    oldHostGroup b = g := by
  classical
  obtain ⟨⟨c,z⟩, hp, rfl⟩ := mem_image.mp hb
  have hcen := (mem_filter.mp (mem_product.mp hp).1).2
  rcases g with ⟨r, - | ⟨l,x⟩⟩
  · rfl
  · have hc : c l.1 = x := hcen (l,x) (by simp)
    simp [oldHostGroup, hc]

theorem oldBaseHosts_positive (g : OldGroup m j) (k : ℕ) (hk : 0 < k) :
    (oldBaseHosts g k).Nonempty := by
  classical
  apply card_pos.mp
  rw [oldBaseHosts_card]
  refine Nat.mul_pos hk (card_pos.mpr ?_)
  cases g with
  | mk r label =>
    cases label with
    | none => exact ⟨0, by simp [oldGroupCenters]⟩
    | some z => exact ⟨fun _ => z.2, by simp [oldGroupCenters]⟩

set_option maxHeartbeats 800000 in
/-- Build the complete old-core assignment from surviving lists of its own physical hosts. -/
theorem old_assignment_of_lists (hm : Odd m) (cs : PartICylinders ε m j) (hk : 0 < k)
    (live : OldHost m j k → Finset (PartICore m j))
    (large : ∀ e : OldRequest ε m j,
      2 * #(oldGroupCenters (oldRequestGroup cs e)) <
        #((oldBaseHosts (oldRequestGroup cs e) k).filter fun b => e.val ⊆ live b)) :
    ∃ host : OldRequest ε m j → OldHost m j k,
      Assigned live (jPairs (partIResidual ε m j) univ) host := by
  classical
  let E := OldRequest ε m j
  let lists (e : E) := (oldBaseHosts (oldRequestGroup cs e) k).filter fun b => e.val ⊆ live b
  let conflict (e f : E) := e ≠ f ∧ oldRequestGroup cs e = oldRequestGroup cs f ∧ ¬ Disjoint e.val f.val
  have hs : ∀ ⦃e f : E⦄, conflict e f → conflict f e := by
    intro e f h
    exact ⟨h.1.symm, h.2.1.symm, fun hd => h.2.2 hd.symm⟩
  have hbound (e : E) : #(univ.filter (conflict e)) < #(lists e) := by
    let L := univ.filter fun f : E => oldRequestGroup cs f = oldRequestGroup cs e ∧ oldLeft e ∈ f.val
    let R := univ.filter fun f : E => oldRequestGroup cs f = oldRequestGroup cs e ∧ oldRight e ∈ f.val
    have hsub : univ.filter (conflict e) ⊆ L ∪ R := by
      intro f hf
      obtain ⟨_, heq, hn⟩ := (mem_filter.mp hf).2
      obtain ⟨x, hx, hy⟩ := not_disjoint_iff.mp hn
      rw [(oldEndpoints e).2, mem_insert, mem_singleton] at hx
      rcases hx with h | h
      · exact mem_union.mpr (Or.inl (mem_filter.mpr ⟨mem_univ _, heq.symm, h ▸ hy⟩))
      · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨mem_univ _, heq.symm, h ▸ hy⟩))
    have hL : #L ≤ #(oldGroupCenters (oldRequestGroup cs e)) :=
      oldIncidence_bound hm cs (oldRequestGroup cs e) (oldLeft e)
    have hR : #R ≤ #(oldGroupCenters (oldRequestGroup cs e)) :=
      oldIncidence_bound hm cs (oldRequestGroup cs e) (oldRight e)
    exact lt_of_le_of_lt ((card_le_card hsub).trans ((card_union_le L R).trans (by omega))) (large e)
  let g : OldGroup m j := (s((0,0),(0,0)), none)
  let init : E → OldHost m j k := fun _ => (oldBaseHosts_positive g k hk).choose
  obtain ⟨host, hhost, _⟩ := extend_shared_lists conflict hs (fun _ h => h.1 rfl)
    univ ∅ (empty_subset _) lists (fun e _ => hbound e) init (by simp [ListPrefix])
  refine ⟨host, fun e => (mem_filter.mp (hhost.1 e (mem_univ _))).2, ?_⟩
  intro e f heq x hx hy
  by_contra hne
  have he := oldBaseHosts_group (mem_filter.mp (hhost.1 e (mem_univ _))).1
  have hf := oldBaseHosts_group (mem_filter.mp (hhost.1 f (mem_univ _))).1
  have hg : oldRequestGroup cs e = oldRequestGroup cs f := he.symm.trans ((congrArg oldHostGroup heq).trans hf)
  exact hhost.2 e (mem_univ _) f (mem_univ _) ⟨hne,hg,not_disjoint_iff.mpr ⟨x,hx,hy⟩⟩ heq

end

end SplitGapIII
