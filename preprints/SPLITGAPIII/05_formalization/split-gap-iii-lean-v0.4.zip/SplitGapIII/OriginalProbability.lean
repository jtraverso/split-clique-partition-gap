module

public import SplitGapIII.OriginalPalettes

@[expose] public section

namespace SplitGapIII
open Finset GapExtremal QuadraticExteriorPalomar GapExtremal.R434 GapExtremal.R434.EHPS
open MeasureTheory ProbabilityTheory
open scoped BigOperators ENNReal

noncomputable section

local instance (m j : ℕ) : DecidableEq (PartICore m j) :=
  inferInstanceAs (DecidableEq (H54.Role × ProductGrid m j))

local instance (m j k : ℕ) : DecidableEq (OldHost m j k) :=
  Classical.typeDecidableEq _

variable {ε : ℝ} {m j k s q : ℕ} [NeZero m]
variable {W : Type} [Fintype W] [DecidableEq W]

abbrev WitnessTest (ε : ℝ) (m j : ℕ) [NeZero m] (W : Type) :=
  OldRequest ε m j ⊕ ((PartICore m j × W) ⊕ (⊤ : SimpleGraph W).edgeSet)

omit [Fintype W] [DecidableEq W] in
theorem terminal_endpoints (e : (⊤ : SimpleGraph W).edgeSet) :
    ∃ a b, a ≠ b ∧ e.val = s(a,b) := by
  obtain ⟨v,hv⟩ := e
  induction v using Sym2.ind with
  | h a b => exact ⟨a,b,by simpa using hv,rfl⟩

def terminalLeft (e : (⊤ : SimpleGraph W).edgeSet) := (terminal_endpoints e).choose
def terminalRight (e : (⊤ : SimpleGraph W).edgeSet) := (terminal_endpoints e).choose_spec.choose

private theorem terminal_pair (e : (⊤ : SimpleGraph W).edgeSet) :
    terminalLeft e ≠ terminalRight e ∧ e.val = s(terminalLeft e, terminalRight e) :=
  (terminal_endpoints e).choose_spec.choose_spec

def witnessLeft : WitnessTest ε m j W → PartICore m j ⊕ W
  | .inl e => .inl (oldLeft e)
  | .inr (.inl e) => .inl e.1
  | .inr (.inr e) => .inr (terminalLeft e)

def witnessRight : WitnessTest ε m j W → PartICore m j ⊕ W
  | .inl e => .inl (oldRight e)
  | .inr (.inl e) => .inr e.2
  | .inr (.inr e) => .inr (terminalRight e)

theorem witness_test_distinct (e : WitnessTest ε m j W) : witnessLeft e ≠ witnessRight e := by
  rcases e with e | e | e
  · exact fun h => (oldEndpoints e).1 (Sum.inl.inj h)
  · simp [witnessLeft, witnessRight]
  · exact fun h => (terminal_pair e).1 (Sum.inr.inj h)

def mixedEmbedding (c : Fin 3) : Fin s ↪ WitnessHosts (OldHost m j k) s q :=
  ⟨fun h => .inr (.inl (c,h)), fun _ _ h => congrArg Prod.snd (Sum.inl.inj (Sum.inr.inj h))⟩

def terminalEmbedding : Fin s ↪ WitnessHosts (OldHost m j k) s q :=
  Function.Embedding.inl.trans (Function.Embedding.inr.trans Function.Embedding.inr)

def witnessAvailable (cs : PartICylinders ε m j) :
    WitnessTest ε m j W → Finset (WitnessHosts (OldHost m j k) s q)
  | .inl e => (oldBaseHosts (oldRequestGroup cs e) k).map Function.Embedding.inl
  | .inr (.inl (a, _)) => univ.map (mixedEmbedding a.1.1)
  | .inr (.inr _) => univ.map terminalEmbedding

def witnessLive {Ω : Type} (cs : PartICylinders ε m j)
    (keep : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W) → Set Ω) (ω : Ω) :
    WitnessHosts (OldHost m j k) s q → Finset (PartICore m j ⊕ W) := by
  classical
  exact fun b => (witnessPalettes (oldPalettes cs) (fun a => a.1.1) s q b).filter fun x => ω ∈ keep (b,x)

private theorem original_witness_available (cs : PartICylinders ε m j)
    (e : WitnessTest ε m j W) {b : WitnessHosts (OldHost m j k) s q}
    (hb : b ∈ witnessAvailable cs e) :
    witnessLeft e ∈ witnessPalettes (oldPalettes cs) (fun a => a.1.1) s q b ∧
    witnessRight e ∈ witnessPalettes (oldPalettes cs) (fun a => a.1.1) s q b := by
  classical
  rcases e with e | ⟨a,b'⟩ | e
  · obtain ⟨d,hd,rfl⟩ := mem_map.mp hb
    have hpair := oldEndpoints e
    have hnon := nonadj_of_mem_jPairs e.property (oldLeft e) (by rw [hpair.2]; simp)
      (oldRight e) (by rw [hpair.2]; simp)
    simpa only [witnessLeft, witnessRight, Function.Embedding.inr_apply,
      Function.Embedding.inl_apply, witnessPalettes, inl_mem_disjSum] using
      oldPalettes_pair cs hpair.1 hnon (oldBaseHosts_group hd).symm
  · obtain ⟨d,_,rfl⟩ := mem_map.mp hb
    change Sum.inl a ∈ witnessPalettes (oldPalettes cs) (fun x => x.1.1) s q (.inr (.inl (a.1.1, d))) ∧
      Sum.inr b' ∈ witnessPalettes (oldPalettes cs) (fun x => x.1.1) s q (.inr (.inl (a.1.1, d)))
    simp [witnessPalettes]
  · obtain ⟨d,_,rfl⟩ := mem_map.mp hb
    simp [witnessLeft, witnessRight, witnessPalettes, terminalEmbedding]

private theorem count_live_hosts {Ω : Type} (cs : PartICylinders ε m j)
    (keep : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W) → Set Ω) (ω : Ω)
    (e : WitnessTest ε m j W) :
    surviving_hosts (witnessAvailable cs e) keep (witnessLeft e) (witnessRight e) ω =
      (witnessAvailable cs e).filter fun b =>
        witnessLeft e ∈ witnessLive cs keep ω b ∧ witnessRight e ∈ witnessLive cs keep ω b := by
  classical
  ext b
  simp only [surviving_hosts, witnessLive, mem_filter]
  constructor
  · rintro ⟨hb, hx, hy⟩
    have hh := original_witness_available cs e hb
    exact ⟨hb,⟨hh.1,hx⟩,hh.2,hy⟩
  · rintro ⟨hb, ⟨_,hx⟩, _,hy⟩
    exact ⟨hb,hx,hy⟩

private theorem filter_map_count {A B : Type} (f : A ↪ B) (P : Finset A) (p : B → Prop)
    [DecidablePred p] : #((P.map f).filter p) = #(P.filter fun a => p (f a)) := by
  rw [filter_map, card_map]
  rfl

private theorem old_live_test_count {Ω : Type} (cs : PartICylinders ε m j)
    (keep : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W) → Set Ω) (ω : Ω)
    (e : OldRequest ε m j) :
    #(surviving_hosts (witnessAvailable (W := W) cs (.inl e)) keep (.inl (oldLeft e)) (.inl (oldRight e)) ω) =
      #((oldBaseHosts (oldRequestGroup cs e) k).filter fun b => e.val ⊆ (witnessLive cs keep ω (.inl b)).toLeft) := by
  classical
  rw [show Sum.inl (oldLeft e) = witnessLeft (W := W) (.inl e) from rfl,
    show Sum.inl (oldRight e) = witnessRight (W := W) (.inl e) from rfl, count_live_hosts]
  rw [witnessAvailable, filter_map_count]
  congr 1
  ext b
  rw [(oldEndpoints e).2]
  simp [witnessLeft, witnessRight, insert_subset_iff, mem_toLeft]

private theorem mixed_live_test_count {Ω : Type} (cs : PartICylinders ε m j)
    (keep : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W) → Set Ω) (ω : Ω)
    (a : PartICore m j) (b : W) :
    #(surviving_hosts (witnessAvailable cs (.inr (.inl (a,b)))) keep (.inl a) (.inr b) ω) =
      #(witnessMixedList (witnessLive cs keep ω) (fun x => x.1.1) a b) := by
  classical
  change #(surviving_hosts (witnessAvailable cs (.inr (.inl (a,b)))) keep
    (witnessLeft (ε := ε) (.inr (.inl (a,b)))) (witnessRight (ε := ε) (.inr (.inl (a,b)))) ω) = _
  rw [count_live_hosts, witnessAvailable, filter_map_count]
  rfl

private theorem terminal_live_test_count {Ω : Type} (cs : PartICylinders ε m j)
    (keep : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W) → Set Ω) (ω : Ω)
    (e : (⊤ : SimpleGraph W).edgeSet) :
    #(surviving_hosts (witnessAvailable cs (.inr (.inr e))) keep (.inr (terminalLeft e))
      (.inr (terminalRight e)) ω) = #(witnessTerminalList (witnessLive cs keep ω) e) := by
  classical
  change #(surviving_hosts (witnessAvailable cs (.inr (.inr e))) keep
    (witnessLeft (ε := ε) (.inr (.inr e))) (witnessRight (ε := ε) (.inr (.inr e))) ω) = _
  rw [count_live_hosts, witnessAvailable, filter_map_count]
  congr 1
  ext b
  have hc : corePair (V := PartICore m j ⊕ W) Function.Embedding.inr e =
      {Sum.inr (terminalLeft e), Sum.inr (terminalRight e)} := by
    unfold corePair
    rw [(terminal_pair e).2, Sym2.toFinset_mk_eq]
    simp
  simp [witnessLeft, witnessRight, witnessTerminalList, terminalEmbedding, hc, insert_subset_iff]

set_option maxHeartbeats 800000 in
/-- Construct the full assignment from one set of surviving physical incidences. -/
theorem recover_witness_from_counts {Ω : Type} (hm : Odd m) (cs : PartICylinders ε m j)
    (hk : 0 < k) (hs : 0 < s) (hw : Fintype.card (PartICore m j) ≤ Fintype.card W)
    (keep : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W) → Set Ω) (ω : Ω)
    (a : ℝ) (ha : 2 ≤ a * k) (hnew : (Fintype.card W : ℝ) ≤ a * s)
    (counts : ∀ e : WitnessTest ε m j W, a * (witnessAvailable (k := k) (s := s) (q := q) cs e).card <
      (surviving_hosts (witnessAvailable cs e) keep (witnessLeft e) (witnessRight e) ω).card) :
    Nonempty (WitnessSelection (partIResidual ε m j) (fun x => x.1.1) (witnessLive cs keep ω)) := by
  classical
  let N := witnessLive cs keep ω
  have hold (e : OldRequest ε m j) :
      2 * #(oldGroupCenters (oldRequestGroup cs e)) <
        #((oldBaseHosts (oldRequestGroup cs e) k).filter fun b => e.val ⊆ (N (.inl b)).toLeft) := by
    let E : WitnessTest ε m j W := .inl e
    have hb := counts E
    have hc : #(witnessAvailable (k := k) (s := s) (q := q) cs E) =
        k * #(oldGroupCenters (oldRequestGroup cs e)) := by
      simp only [E, witnessAvailable, card_map, oldBaseHosts_card]
    rw [hc] at hb
    have hb' : (2 : ℝ) * #(oldGroupCenters (oldRequestGroup cs e)) <
        #((oldBaseHosts (oldRequestGroup cs e) k).filter fun b => e.val ⊆ (N (.inl b)).toLeft) := by
      refine lt_of_le_of_lt (mul_le_mul_of_nonneg_right ha (by positivity)) ?_
      simpa only [← mul_assoc, Nat.cast_mul, E, witnessLeft, witnessRight,
        old_live_test_count, N] using hb
    exact_mod_cast hb'
  obtain ⟨old, hOld⟩ := old_assignment_of_lists hm cs hk (fun b => (N (.inl b)).toLeft) hold
  let g : OldGroup m j := (s((0,0),(0,0)), none)
  letI : Nonempty (OldHost m j k) := ⟨(oldBaseHosts_positive g k hk).choose⟩
  obtain ⟨assign, hassign⟩ := host_hyp_of_assigned (partIResidual ε m j)
    (fun b => (N (.inl b)).toLeft) (by
      intro b x hx y hy
      apply oldPalettes_independent hm cs b
      · have hx' : Sum.inl x ∈ N (.inl b) := mem_toLeft.mp hx
        simpa [N, witnessPalettes] using (mem_filter.mp hx').1
      · have hy' : Sum.inl y ∈ N (.inl b) := mem_toLeft.mp hy
        simpa [N, witnessPalettes] using (mem_filter.mp hy').1) old hOld
  apply witness_selection_of_lists (partIResidual ε m j) (fun x => x.1.1) hs N assign hassign hw
  · intro x y
    have hb := counts (.inr (.inl (x,y)))
    simp only [witnessLeft, witnessRight] at hb
    rw [mixed_live_test_count] at hb
    simp only [witnessAvailable, card_map, card_univ, Fintype.card_fin] at hb
    have hh : (Fintype.card W : ℝ) ≤ (#(witnessMixedList N (fun x => x.1.1) x y) : ℕ) := hnew.trans hb.le
    exact_mod_cast hh
  · intro e
    have hb := counts (.inr (.inr e))
    simp only [witnessLeft, witnessRight] at hb
    rw [terminal_live_test_count] at hb
    simp only [witnessAvailable, card_map, card_univ, Fintype.card_fin] at hb
    have hh : (Fintype.card W : ℝ) ≤ (#(witnessTerminalList N e) : ℕ) := hnew.trans hb.le
    exact_mod_cast hh

set_option maxHeartbeats 800000 in
/-- The independent coins drive the same split graph used by the explicit producer. -/
theorem original_witness_probability {Ω : Type} [MeasurableSpace Ω] (μ : Measure Ω)
    [IsProbabilityMeasure μ] (hm : Odd m) (cs : PartICylinders ε m j)
    (hk : 0 < k) (hs : 0 < s) (hw : Fintype.card (PartICore m j) ≤ Fintype.card W)
    (keep : WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W) → Set Ω)
    (hkeep : ∀ r, MeasurableSet (keep r)) (hcoin : iIndepSet keep μ) (p : ℝ≥0∞)
    (hp : ∀ r, μ (keep r) = p) (a t : ℝ) (ht : t ≤ 0) (ha : 2 ≤ a * k)
    (hnew : (Fintype.card W : ℝ) ≤ a * s) :
    μ.real {ω | gap (hostGraph (witnessLive cs keep ω)) ≠
      residualSup (withIsolates (X := W) (partIResidual ε m j)) -
        residualInt (withIsolates (X := W) (partIResidual ε m j))} ≤
    ∑ e : WitnessTest ε m j W,
      (Real.exp (-t * a) * (1 - p.toReal ^ 2 + p.toReal ^ 2 * Real.exp t)) ^
        (witnessAvailable (k := k) (s := s) (q := q) cs e).card := by
  classical
  let ports (e : WitnessTest ε m j W) (b : WitnessHosts (OldHost m j k) s q) :=
    ({(b,witnessLeft e),(b,witnessRight e)} : Finset
      (WitnessHosts (OldHost m j k) s q × (PartICore m j ⊕ W)))
  have htwo (e : WitnessTest ε m j W) (b : WitnessHosts (OldHost m j k) s q) : #(ports e b) = 2 := by
    simp [ports, witness_test_distinct e]
  have hsep (e : WitnessTest ε m j W) (b d : WitnessHosts (OldHost m j k) s q) (hne : b ≠ d) :
      Disjoint (ports e b) (ports e d) := by
    apply disjoint_left.mpr
    intro x hx hy
    have h₁ : x.1 = b := by simp only [ports, mem_insert, mem_singleton] at hx; rcases hx with hx | hx <;> simp [hx]
    have h₂ : x.1 = d := by simp only [ports, mem_insert, mem_singleton] at hy; rcases hy with hy | hy <;> simp [hy]
    exact hne (h₁.symm.trans h₂)
  let Good := {ω | gap (hostGraph (witnessLive cs keep ω)) =
      residualSup (withIsolates (X := W) (partIResidual ε m j)) -
        residualInt (withIsolates (X := W) (partIResidual ε m j))}
  have hgood (ω : Ω) (hc : ∀ e ∈ (univ : Finset (WitnessTest ε m j W)),
      a * (witnessAvailable (k := k) (s := s) (q := q) cs e).card <
        ∑ b ∈ witnessAvailable (k := k) (s := s) (q := q) cs e,
          (⋂ r ∈ ports e b, keep r).indicator (fun _ => (1 : ℝ)) ω) : ω ∈ Good := by
    obtain ⟨select⟩ := recover_witness_from_counts hm cs hk hs hw keep ω a ha hnew (by
      intro e
      rw [surviving_hosts_count]
      simpa only [ports] using hc e (mem_univ _))
    change gap (hostGraph (witnessLive cs keep ω)) =
      residualSup (withIsolates (X := W) (partIResidual ε m j)) -
        residualInt (withIsolates (X := W) (partIResidual ε m j))
    exact gap_eq_residual_difference (assembled_host_hyp (partIResidual ε m j) (fun x => x.1.1)
      (fun _ _ he => H54.core_is_tripartite _ _ he) (oldPalettes cs) (witnessLive cs keep ω)
      (fun b => filter_subset _ _) select)
  exact physical_survival_bound univ (witnessAvailable cs) ports keep hkeep hcoin p hp
    htwo hsep a t ht Good hgood

end
end SplitGapIII
