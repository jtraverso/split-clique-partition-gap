module

public import R434.EHPSCompactExterior
public import SplitGapIII.PartIParameters

@[expose] public section

namespace SplitGapIII
open GapExtremal.R434 GapExtremal.R434.EHPS

/-- The plane part of the compact label of Part I. The factor index is selected separately. -/
abbrev PlaneLabel := Fin 6 × Fin 2 × Fin 2

theorem plane_label_card : Fintype.card PlaneLabel = 24 := by
  simp [PlaneLabel]

/-- Read the one-factor instance of the published compact coloring on a single coordinate. -/
theorem one_factor_classes {m : ℕ} [NeZero m] {ε : ℝ} (hm : Odd m) (he : 0 < ε) :
    ∃ χ : {z : Grid m // ¬ Region ε (gridPoint m z)} → PlaneLabel,
      ∀ u v, χ u = χ v →
        ¬ Region ε (gridPoint m ((oddHalf m, oddHalf m) * (u.val + v.val))) := by
  classical
  let lift (z : {z : Grid m // ¬ Region ε (gridPoint m z)}) :
      {a : ProductGrid m 1 // a ∉ productSupport ε m 1} :=
    ⟨fun _ => z.val, fun h => z.property ((mem_productSupport.mp h) 0)⟩
  obtain ⟨color, hcolor⟩ := CompactExterior.product_colouring (j := 1) hm he
  refine ⟨fun z => (color (lift z)).2, ?_⟩
  intro u v huv hmids
  have hcol : color (lift u) = color (lift v) := Prod.ext (Subsingleton.elim _ _) huv
  apply hcolor _ _ hcol
  exact mem_productSupport.mpr fun _ => hmids

/-- Cylinders replace the first-failure restrictions in the other coordinates.
The same 24 plane labels cover each factor and keep the midpoint outside the support. -/
structure PartICylinders (ε : ℝ) (m j : ℕ) [NeZero m] where
  bands : PlaneLabel → Set (Grid m)
  cover : ∀ a : ProductGrid m j, a ∉ productSupport ε m j →
    ∃ (p : Fin j) (l : PlaneLabel), a p ∈ bands l
  closed : ∀ (p : Fin j) (l : PlaneLabel) (u v : ProductGrid m j),
    u p ∈ bands l → v p ∈ bands l →
      productHalf m j * (u + v) ∉ productSupport ε m j

theorem partI_cylinders {m j : ℕ} [NeZero m] {ε : ℝ} (hm : Odd m) (he : 0 < ε) :
    Nonempty (PartICylinders ε m j) := by
  classical
  obtain ⟨χ, hχ⟩ := one_factor_classes hm he
  let band (l : PlaneLabel) : Set (Grid m) :=
    {z | ∃ hz : ¬ Region ε (gridPoint m z), χ ⟨z, hz⟩ = l}
  refine ⟨⟨band, ?_, ?_⟩⟩
  · intro a ha
    obtain ⟨p, hp⟩ := exists_factor_for_required_direction
      {z : Grid m | Region ε (gridPoint m z)} a (fun h => ha (mem_productSupport.mpr h))
    exact ⟨p, χ ⟨a p, hp⟩, hp, rfl⟩
  · intro p l u v hu hv hmem
    obtain ⟨hu', hlu⟩ := hu
    obtain ⟨hv', hlv⟩ := hv
    exact hχ ⟨u p, hu'⟩ ⟨v p, hv'⟩ (hlu.trans hlv.symm) ((mem_productSupport.mp hmem) p)

/-- At every sufficiently large order, the published parameters have the compact cylinder
cover and enough hosts in every center fiber for the probability bound. -/
theorem partI_cylinders_at_order (M : ℕ) (hM : 25 ≤ M) :
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n →
      ∃ (m j : ℕ) (_ : NeZero m),
        Odd m ∧ 1 ≤ j ∧ M * (255 + 2880*j) * m ^ (2*j) ≤ n ∧
        (12000 : ℝ)*(j : ℝ) ≤ m ∧
        Nonempty (PartICylinders (7/(1080*(j : ℝ))) m j) ∧
        (∀ (p : Fin j) (a : Grid m), n ≤ (Fintype.card {c : ProductGrid m j // c p = a})^2) ∧
        Real.exp (-Real.log (24/7) * (j : ℝ)) * (m : ℝ)^(4*j) /
          (27 * (1 + (200*(1080/7)^2) * (j : ℝ)^3 * (m : ℝ)^2)) ≥
        orderAmplitude (3135*(M : ℝ)) (200*(1080/7)^2) (Real.log (24/7)) * n^2 /
          (Real.log n)^(5/2 : ℝ) * Real.exp (-2 * Real.sqrt (Real.log (24/7) * Real.log n)) := by
  obtain ⟨N,hN⟩ := partI_linear_parameters M hM
  refine ⟨N, fun n hn => ?_⟩
  obtain ⟨m,j,hm,hmOdd,hj,hbudget,hgrid,hfiber,hgap⟩ := hN n hn
  letI : NeZero m := ⟨by omega⟩
  have hjR : (0 : ℝ) < j := by exact_mod_cast (show 0 < j by omega)
  refine ⟨m,j,inferInstance,hmOdd,hj,hbudget,hgrid,partI_cylinders hmOdd (by positivity), ?_,hgap⟩
  intro p a
  rw [product_grid_fiber_card]
  exact hfiber

end SplitGapIII
