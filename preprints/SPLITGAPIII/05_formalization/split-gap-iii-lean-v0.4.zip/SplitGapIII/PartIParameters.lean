/-
Adapts R434.PolylogOrder.joint_order_parameters from the published Split Gap I
freeze by Juan Pablo Traverso Gianini, Apache-2.0.
-/
module

public import R434.PolylogOrder
public import SplitGapIII.RecoveryProbability
public import SplitGapIII.Cylinders
public import Mathlib.Data.ZMod.Basic

@[expose] public section

namespace SplitGapIII
open Real GapExtremal.R434

/-- On the same rounded parameters as in Part I, a single midpoint coordinate
can be fixed while leaving at least sqrt(n) distinct centers. -/
theorem fiber_growth_of_rounding {n m j : ℕ} {A c t : ℝ}
    (_hA : 1 ≤ A) (hc : 0 < c) (ht : 4 ≤ t) (hm : 1 ≤ m) (hj : 1 ≤ j)
    (hn : 0 < (n : ℝ)) (hL : log n = c*t^2)
    (hround : 2 * (log n - 2 * (j : ℝ) * log m) ≤ 2 * (log A + log t + 1))
    (hshort : 2 * log m ≤ c*(t+2))
    (herr : 1*log t + (log A + 1 + 2*c) ≤ c*t) :
    n ≤ (m ^ (2*(j-1)))^2 := by
  have hmpos : 0 < (m : ℝ) := by exact_mod_cast (Nat.zero_lt_of_lt hm)
  have hdec : (j : ℝ) = ((j-1 : ℕ) : ℝ) + 1 := by
    exact_mod_cast (Nat.sub_add_cancel hj).symm
  rw [hdec] at hround
  have hquad : 4*c*t ≤ c*t^2 := by
    nlinarith [mul_nonneg hc.le (mul_nonneg (by linarith : 0 ≤ t) (sub_nonneg.mpr ht))]
  have hlog : log n ≤ log ((((m : ℝ) ^ (2*(j-1)))^2)) := by
    rw [log_pow, log_pow]
    push_cast
    nlinarith only [hL, hround, hshort, herr, hquad]
  exact_mod_cast (log_le_log_iff hn (by positivity)).mp hlog

theorem joint_order_with_fiber_growth (H : ℕ → ℕ) (A K c W : ℝ)
    (hA : 1 ≤ A) (hK : 0 ≤ K) (hc : 0 < c) (hW : 10 ≤ W)
    (hH : ∀ j : ℕ, 1 ≤ j → 1 ≤ H j ∧ (H j : ℝ) ≤ A * (j : ℝ)) :
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n → ∃ m j : ℕ,
      1 ≤ m ∧ Odd m ∧ 1 ≤ j ∧ H j * m ^ (2*j) ≤ n ∧ W/2*(j : ℝ) ≤ m ∧
      n ≤ (m ^ (2*(j-1)))^2 ∧
      sqrt c / (A * exp 1) * n / sqrt (log n) ≤ (m : ℝ)^(2*j) ∧
      orderAmplitude A K c * n^2 / (log n)^(5/2 : ℝ) * exp (-2 * sqrt (c * log n)) ≤
        exp (-c * (j : ℝ)) * (m : ℝ)^(4*j) /
          (27 * (1 + K * (j : ℝ)^3 * (m : ℝ)^2)) := by
  let C := 27 * (1 + K)
  have hC : 0 < C := by dsimp [C]; positivity
  let b := 2 * log A + 2 + 2*c + log C - (5/2)*log c
  obtain ⟨U, hU, herr⟩ := log_linear_error 1 (log A + 1 + 2*c) c
    (by norm_num) (by nlinarith [log_nonneg hA]) hc
  let m₀ : ℕ := ⌈max 4 U⌉₊
  obtain ⟨N,hN⟩ := rounded_order_witness H A c hA hc W hW m₀ hH
  refine ⟨N, fun n hn => ?_⟩
  obtain ⟨m,j,hm,_,hod,hj,horder,hw,hnpos,ht,hjt,hL,hround,hshort⟩ := hN n hn
  let t := sqrt (log n / c)
  change (m₀ : ℝ) + 2 ≤ t at ht
  have htlarge : max 4 U ≤ t := (Nat.le_ceil _).trans (by linarith)
  have h4 : 4 ≤ t := (le_max_left _ _).trans htlarge
  have hU' : U ≤ t := (le_max_right _ _).trans htlarge
  change (j : ℝ) ≤ t at hjt
  change log n = c*t^2 at hL
  change _ ≤ 2*(log A + log t + 1) at hround
  change _ ≤ c*(t+2) at hshort
  have htpos : 0 < t := by linarith
  have hLpos : 0 < log n := hL ▸ by positivity
  have hm1 : (1 : ℝ) ≤ m := by exact_mod_cast hm
  have hj1 : (1 : ℝ) ≤ j := by exact_mod_cast hj
  have hp : 0 < (m : ℝ) := by linarith
  have hjp : 0 < (j : ℝ) := by linarith
  have hgrowth : n ≤ (m ^ (2*(j-1)))^2 :=
    fiber_growth_of_rounding hA hc h4 hm hj hnpos hL hround hshort (herr t hU')
  refine ⟨m,j,hm,hod,hj,horder,hw,hgrowth,?_,?_⟩
  · have hAl : 0 < A := by linarith
    have hs : sqrt (log n) = sqrt c*t := by rw [hL,sqrt_mul hc.le,sqrt_sq htpos.le]
    have hlogbd : log n ≤ log (A * exp 1 * t * (m : ℝ)^(2*j)) := by
      rw [log_mul (by positivity) (pow_ne_zero _ hp.ne'),
        log_mul (by positivity) htpos.ne', log_mul hAl.ne' (exp_pos 1).ne',log_exp,log_pow]
      push_cast
      linarith only [hround]
    have hnle := (log_le_log_iff hnpos (by positivity)).mp hlogbd
    rw [hs]
    apply (div_le_iff₀ (by positivity)).mpr
    rw [div_mul_eq_mul_div, div_le_iff₀ (by positivity)]
    have hp' := mul_le_mul_of_nonneg_left hnle (sqrt_nonneg c)
    linarith only [hp']
  have hLj : log (j : ℝ) ≤ log t := log_le_log hjp hjt
  have hct : c*(j : ℝ) ≤ c*t := mul_le_mul_of_nonneg_left hjt hc.le
  have hroot : sqrt (c*log n) = c*t := by
    rw [hL, show c*(c*t^2)=(c*t)^2 by ring, sqrt_sq (by positivity)]
  have hlog : log (log n) = log c + 2 * log t := by
    conv_lhs => rw [hL, log_mul hc.ne' (pow_ne_zero _ htpos.ne'), log_pow]
    norm_num
  let D := 27*(1+K*(j : ℝ)^3*(m : ℝ)^2)
  have hD : 0 < D := by dsimp [D]; positivity
  have hprod : 1 ≤ (j : ℝ)^3*(m : ℝ)^2 :=
    one_le_mul_of_one_le_of_one_le (one_le_pow₀ hj1) (one_le_pow₀ hm1)
  have hDlog : log D ≤ log C + 3*log (j : ℝ) + 2*log (m : ℝ) := by
    have hle : D ≤ C*(j : ℝ)^3*(m : ℝ)^2 := by dsimp [D,C]; nlinarith only [hprod]
    have h := log_le_log hD hle
    rw [log_mul (by positivity : C*(j : ℝ)^3 ≠ 0) (pow_ne_zero _ hp.ne'),
      log_mul hC.ne' (pow_ne_zero _ hjp.ne'), log_pow, log_pow] at h
    exact_mod_cast h
  change exp (-b) * (n : ℝ)^2 / (log n)^(5/2 : ℝ) * exp (-2 * sqrt (c*log n)) ≤
    exp (-c*(j : ℝ)) * (m : ℝ)^(4*j) / D
  apply (log_le_log_iff (by positivity) (by positivity)).mp
  rw [log_mul (by positivity) (by positivity), log_div (by positivity) (by positivity),
    log_mul (by positivity) (by positivity), log_exp, log_pow, log_rpow hLpos,
    log_exp, hroot, hlog, log_div (by positivity) hD.ne',
    log_mul (by positivity) (by positivity), log_exp, log_pow]
  push_cast
  dsimp [b]
  linarith only [hround,hshort,hDlog,hLj,hct]

/-- The two-copy families and the extra padding fit the actual host budget
of the linear-connectivity construction of Part I. -/
theorem two_copy_budget (n j t : ℕ) (hn : 400 ≤ n)
    (hBase : 25 * (255 + 2880*j) * t ≤ n) :
    (147 + 2592*j)*t + 4*((n+4)/5) + 3*(15*t) + 3*(n/100) ≤ n := by
  have hcoef : 147 + 2592*j ≤ 255 + 2880*j := by omega
  have hsmall : 25*((147 + 2592*j)*t) ≤ n := by
    exact (Nat.mul_le_mul_left 25 (Nat.mul_le_mul_right t hcoef)).trans
      (by simpa only [Nat.mul_assoc] using hBase)
  have hv : 25*(15*t) ≤ n := by
    exact (Nat.mul_le_mul_left 25 (Nat.mul_le_mul_right t (by omega : 15 ≤ 255 + 2880*j))).trans
      (by simpa only [Nat.mul_assoc] using hBase)
  omega

/-- The center palette on the actual product grid of Part I. -/
theorem product_grid_fiber_card (m j : ℕ) [NeZero m] (p : Fin j) (a : ZMod m × ZMod m) :
    Fintype.card {c : Fin j → ZMod m × ZMod m // c p = a} = m ^ (2*(j-1)) := by
  have hcard : Fintype.card {i : Fin j // i ≠ p} = j - 1 := by
    rw [Fintype.card_subtype_compl (fun i : Fin j => i = p)]
    simp
  rw [centerFiber_card, hcard, Fintype.card_prod, ZMod.card, ← pow_two, ← pow_mul]

/-- At the published Part I scale the same odd modulus and dimension meet the affine host
budget, retain the quantitative lower bound, and give large probabilistic reserve lists.
The multiplier is 25 in Part I and may be increased by a fixed factor to reserve more copies. -/
theorem partI_linear_parameters (M : ℕ) (hM : 25 ≤ M) :
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n → ∃ m j : ℕ,
      1 ≤ m ∧ Odd m ∧ 1 ≤ j ∧ M * (255 + 2880*j) * m ^ (2*j) ≤ n ∧
      (12000 : ℝ)*(j : ℝ) ≤ m ∧ n ≤ (m ^ (2*(j-1)))^2 ∧
      orderAmplitude (3135*(M : ℝ)) (200*(1080/7)^2) (log (24/7)) * n^2 /
        (log n)^(5/2 : ℝ) * exp (-2 * sqrt (log (24/7) * log n)) ≤
      exp (-log (24/7) * (j : ℝ)) * (m : ℝ)^(4*j) /
        (27 * (1 + (200*(1080/7)^2) * (j : ℝ)^3 * (m : ℝ)^2)) := by
  have hMreal : (25 : ℝ) ≤ M := by exact_mod_cast hM
  have hMpos : (0 : ℝ) ≤ M := by positivity
  have hsize (j : ℕ) (hj : 1 ≤ j) :
      1 ≤ M * (255 + 2880*j) ∧
        ((M * (255 + 2880*j) : ℕ) : ℝ) ≤ (3135*(M : ℝ)) * (j : ℝ) := by
    constructor
    · have hpM : 0 < M := by omega
      exact Nat.mul_pos hpM (by omega)
    · have hj' : (1 : ℝ) ≤ j := by exact_mod_cast hj
      push_cast
      calc
        (M : ℝ) * (255 + 2880*(j : ℝ)) ≤ (M : ℝ) * (3135*(j : ℝ)) :=
          mul_le_mul_of_nonneg_left (by linarith) hMpos
        _ = (3135*(M : ℝ)) * (j : ℝ) := by ring
  obtain ⟨N, hN⟩ := joint_order_with_fiber_growth (fun j => M * (255 + 2880*j))
    (3135*(M : ℝ)) (200*(1080/7)^2) (log (24/7)) 24000
    (by linarith) (by norm_num) (log_pos (by norm_num)) (by norm_num) hsize
  refine ⟨N, fun n hn => ?_⟩
  obtain ⟨m,j,hm,hod,hj,horder,hgrid,hfiber,_,hgap⟩ := hN n hn
  exact ⟨m,j,hm,hod,hj,horder,by linarith,hfiber,hgap⟩

/-- Old hosts use at most a quarter of the vertices with one monitored copy and k reserve copies. -/
theorem monitored_copies_budget (n j t M k : ℕ)
    (hM : 4 * (k+1) ≤ M) (hBase : M * (255+2880*j) * t ≤ n) :
    4 * ((k+1) * (66+1296*j) * t) ≤ n := by
  calc
    4 * ((k+1) * (66+1296*j) * t) = (4*(k+1)) * (66+1296*j) * t := by ac_rfl
    _ ≤ M * (255+2880*j) * t :=
      Nat.mul_le_mul_right t (Nat.mul_le_mul hM (by omega))
    _ ≤ n := hBase

/-- At the Part I orders, one coordinate fiber suffices for a union bound over all requests. -/
theorem partI_failure_tendsto_zero (m j : ℕ → ℕ) (q : ℝ) (hq0 : 0 ≤ q) (hq1 : q < 1)
    (hfiber : ∀ᶠ n in Filter.atTop, n ≤ (m n ^ (2*(j n-1)))^2)
    (failure : ℕ → ℝ) (nonneg : ∀ n, 0 ≤ failure n)
    (bound : ∀ᶠ n in Filter.atTop, failure n ≤ (n : ℝ)^2 * q ^ (m n ^ (2*(j n-1)))) :
    Filter.Tendsto failure Filter.atTop (nhds 0) :=
  failure_tendsto_zero (fun n => m n ^ (2*(j n-1))) q hq0 hq1 hfiber failure nonneg bound

end SplitGapIII
