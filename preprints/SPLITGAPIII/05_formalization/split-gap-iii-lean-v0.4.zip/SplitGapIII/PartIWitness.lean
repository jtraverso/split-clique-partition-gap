/-
The score calculation adapts `R434.FiniteR434` from the Split Gap I freeze
of Juan Pablo Traverso Gianini, released under the Apache 2.0 license.
-/
module

public import R434.CoreFractional
public import R434.EHPSHostTransfer
public import SplitGapIII.PartICylinders
public import SplitGapIII.WitnessAssembly

@[expose] public section

namespace SplitGapIII

open Finset GapExtremal QuadraticExteriorPalomar GapExtremal.R434 GapExtremal.R434.EHPS
open scoped BigOperators

noncomputable section

abbrev PartICore (m j : ℕ) := H54.Role × ProductGrid m j

local instance (m j : ℕ) : DecidableEq (PartICore m j) :=
  inferInstanceAs (DecidableEq (H54.Role × ProductGrid m j))

abbrev partIResidual (ε : ℝ) (m j : ℕ) [NeZero m] : SimpleGraph (PartICore m j) :=
  H54.coreGraph (productHalf m j) (productSupport ε m j)

set_option maxHeartbeats 800000 in
/-- The finite score difference from `R434.FiniteR434.finite_gap_of_product_for`,
with the graph realization factored out so it can be used after deletions. -/
theorem partI_score_certificates {ε : ℝ} {m j : ℕ} [NeZero m]
    (hε : 0 < ε) (hε₁ : ε ≤ 1) (hm : Odd m) :
    ∃ (I : ℤ) (y : Finset (PartICore m j) → ℝ),
      (∀ P : Finset (Finset (PartICore m j)), IsPack P →
        ∑ S ∈ P, w (partIResidual ε m j) S ≤ I) ∧ ResPack y ∧
      6 * (((gridSupport ε m).card : ℝ) ^ j * ((m : ℝ) ^ 2) ^ j) /
        (27 * (1 + 200 / ε ^ 2 * (j : ℝ) * (m : ℝ) ^ 2)) ≤
      (∑ Q, y Q * (w (partIResidual ε m j) Q : ℝ)) - I := by
  classical
  let A := productSupport ε m j
  let h := productHalf m j
  let B := partIResidual ε m j
  let τ : ℝ := ((A.card * Fintype.card (ProductGrid m j) : ℕ) : ℝ)
  let R : ℝ := (j : ℝ) * (100 * (m : ℝ) ^ 2 / ε ^ 2)
  let D : ℝ := 6 * τ / (27 * (1 + 2 * R / 1))
  let I := ⌊36 * τ - D⌋
  have hh : 2 * h = 1 := productHalf_spec hm
  have hi (P : Finset (Finset (PartICore m j))) (hP : IsPack P) :
      ∑ S ∈ P, w B S ≤ I := by
    apply Int.le_floor.mpr
    have hdef := H54.core_integer_defect_six h hh A R 1 (by dsimp [R]; positivity) (by norm_num)
      (productPotential ε m j) (fun _ ha => product_potential_bounds hε hε₁ ha)
      (fun a b c ha hb hc hab he => product_potential_midpoint hm hε hε₁ ha hc hb hab he) hP
    change D ≤ 36 * τ - ∑ S ∈ P, (w B S : ℝ) at hdef
    push_cast
    linarith only [hdef]
  obtain ⟨y, hy, _, hscore⟩ := H54.core_fractional_score_small h hh A
  refine ⟨I, y, hi, hy, ?_⟩
  change _ ≤ (∑ Q, y Q * (w B Q : ℝ)) - I
  rw [show (∑ Q, y Q * (w B Q : ℝ)) = 36 * τ from hscore]
  have hfloor : (I : ℝ) ≤ 36 * τ - D := Int.floor_le _
  have hD : D ≤ 36 * τ - (I : ℝ) := by linarith only [hfloor]
  have hgrid : Fintype.card (ProductGrid m j) = (m ^ 2) ^ j := by simp [ZMod.card,pow_two]
  have hnume : τ = ((gridSupport ε m).card : ℝ) ^ j * ((m : ℝ) ^ 2) ^ j := by
    dsimp [τ,A]
    rw [productSupport_card, hgrid]
    push_cast
    rfl
  have hden : 27 * (1 + 2 * R / 1) = 27 * (1 + 200 / ε ^ 2 * (j : ℝ) * (m : ℝ) ^ 2) := by
    dsimp [R]
    ring
  simpa only [D, hnume, hden] using hD

/-- A complete assignment of unordered requests gives the symmetric host map on the
same vertex types, without adjoining auxiliary hosts. -/
theorem host_hyp_of_assigned {V H : Type} [Fintype V] [DecidableEq V] [Nonempty H]
    (B : SimpleGraph V) [DecidableRel B.Adj] (N : H → Finset V)
    (independent : ∀ h, ∀ a ∈ N h, ∀ b ∈ N h, ¬ B.Adj a b)
    (host : jPairs B univ → H) (hhost : Assigned N (jPairs B univ) host) :
    ∃ φ : V → V → H, HostHyp B N φ := by
  classical
  let color (e : Finset V) : H := if he : e ∈ jPairs B univ then host ⟨e, he⟩ else Classical.arbitrary H
  have marked {a b : V} (hab : a ≠ b) (hn : ¬ B.Adj a b) : {a,b} ∈ jPairs B univ := by
    apply mem_filter.mpr
    refine ⟨mem_powersetCard.mpr ⟨subset_univ _, card_pair hab⟩, ?_⟩
    rintro ⟨x, hx, y, hy, hxy⟩
    simp only [mem_insert, mem_singleton] at hx hy
    rcases hx with rfl | rfl <;> rcases hy with rfl | rfl
    · exact hxy.ne rfl
    · exact hn hxy
    · exact hn hxy.symm
    · exact hxy.ne rfl
  refine ⟨fun a b => color {a,b}, independent, ?_, fun a b => congrArg color (pair_comm a b), ?_⟩
  · intro a b hab hn
    have hp := marked hab hn
    simpa only [color, dif_pos hp] using
      And.intro (hhost.1 ⟨_, hp⟩ (by simp : a ∈ ({a,b} : Finset V)))
        (hhost.1 ⟨_, hp⟩ (by simp : b ∈ ({a,b} : Finset V)))
  · intro a b d hab hb had hd eq
    have hp := marked hab hb
    have hq := marked had hd
    simp only [color, dif_pos hp, dif_pos hq] at eq
    have he : ({a,b} : Finset V) = {a,d} :=
      congrArg Subtype.val (hhost.2 ⟨_, hp⟩ ⟨_, hq⟩ eq a (by simp) (by simp))
    have hm : b ∈ ({a,d} : Finset V) := by rw [← he]; simp
    exact mem_singleton.mp ((mem_insert.mp hm).resolve_left hab.symm)

set_option maxHeartbeats 800000 in
/-- Assemble the finite Part I residual and all three types of requests in the
same graph after deletions. The input for old-core requests is a family of
solutions on disjoint physical palettes. -/
theorem partI_witness_of_group_solutions {ε : ℝ} {m j : ℕ} [NeZero m]
    (hε : 0 < ε) (hε₁ : ε ≤ 1) (hm : Odd m)
    {H W G : Type} [Fintype H] [DecidableEq H] [Nonempty H] [Fintype W] [DecidableEq W]
    (oldN : H → Finset (PartICore m j)) (n : ℕ) {s q : ℕ} (hs : 0 < s)
    (order : Fintype.card (PartICore m j) + Fintype.card W + Fintype.card H + 4*s + q = n)
    (live : WitnessHosts H s q → Finset (PartICore m j ⊕ W))
    (subset : ∀ h, live h ⊆ witnessPalettes oldN (fun a => a.1.1) s q h)
    (independent : ∀ h, ∀ a ∈ (live (.inl h)).toLeft, ∀ b ∈ (live (.inl h)).toLeft,
      ¬ (partIResidual ε m j).Adj a b)
    (group : jPairs (partIResidual ε m j) univ → G) (palette : G → Finset H)
    (disjoint : ∀ g g', g ≠ g' → Disjoint (palette g) (palette g'))
    (solve : ∀ g, ∃ c : {e : jPairs (partIResidual ε m j) univ // group e = g} → H,
      (∀ e, c e ∈ palette g ∧ e.val.val ⊆ (live (.inl (c e))).toLeft) ∧
      ∀ e f, c e = c f → ∀ v ∈ e.val.val, v ∈ f.val.val → e = f)
    (hw : Fintype.card (PartICore m j) ≤ Fintype.card W)
    (mixLarge : ∀ a b, Fintype.card W ≤ (witnessMixedList live (fun x => x.1.1) a b).card)
    (lastLarge : ∀ e, Fintype.card W ≤ (witnessTerminalList live e).card) :
    Fintype.card ((PartICore m j ⊕ W) ⊕ WitnessHosts H s q) = n ∧
      IsSplit (hostGraph live) ∧
      gap (hostGraph live) = residualSup (withIsolates (X := W) (partIResidual ε m j)) -
        residualInt (withIsolates (X := W) (partIResidual ε m j)) ∧
      6 * (((gridSupport ε m).card : ℝ) ^ j * ((m : ℝ) ^ 2) ^ j) /
        (27 * (1 + 200 / ε ^ 2 * (j : ℝ) * (m : ℝ) ^ 2)) ≤ gap (hostGraph live) := by
  obtain ⟨color, hcolor⟩ := assemble_groups (fun h => (live (.inl h)).toLeft) _ group palette disjoint solve
  obtain ⟨old, hold⟩ := host_hyp_of_assigned (partIResidual ε m j)
    (fun h => (live (.inl h)).toLeft) independent color hcolor
  obtain ⟨I, y, hi, hy, hscore⟩ := partI_score_certificates hε hε₁ hm (j := j)
  obtain ⟨horder, heq, hgap⟩ := witness_of_surviving_lists (partIResidual ε m j)
    (fun a => a.1.1) (fun a b he => H54.core_is_tripartite _ _ he)
    oldN n hs order live subset old hold hw mixLarge lastLarge I hi y hy
  exact ⟨horder, isSplit_hostGraph live, heq, hscore.trans hgap⟩

end

end SplitGapIII
