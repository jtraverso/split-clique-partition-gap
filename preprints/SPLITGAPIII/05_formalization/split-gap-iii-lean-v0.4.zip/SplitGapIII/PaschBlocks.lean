module

public import SplitGapIII.PartICylinders
public import Mathlib.Tactic.Abel

@[expose] public section

namespace SplitGapIII

variable {A : Type*} [AddCommGroup A]

/-- The data that identify a bundle before choosing its pair of prefix fibres. -/
structure PaschBundle (support : Set A) (level : ℕ) where
  direction : ℕ → A
  direction_mem : ∀ a < level, direction a ∈ support
  band : Set A
  midpoint_outside : ∀ {a b x}, a ∈ band → b ∈ band → x + x = a + b → x ∉ support
  centerSum : A

def PaschBundle.Owns {support : Set A} {level : ℕ} (g : PaschBundle support level)
    (u v : ℕ → A) : Prop :=
  (∀ a < level, v a - u a = g.direction a) ∧
  u level + v level = g.centerSum ∧ v level - u level ∈ g.band

private theorem not_lt_of_alternating_bundles
    {S : Set A} {i k : ℕ} (g : PaschBundle S i) (h : PaschBundle S k)
    {u₁ u₂ v₁ v₂ : ℕ → A} (h₁₁ : g.Owns u₁ v₁) (h₂₂ : g.Owns u₂ v₂)
    (h₁₂ : h.Owns u₁ v₂) (h₂₁ : h.Owns u₂ v₁) : ¬ i < k := by
  intro hik
  apply g.midpoint_outside h₁₁.2.2 h₂₂.2.2 _ (h.direction_mem i hik)
  calc
    h.direction i + h.direction i = (v₂ i - u₁ i) + (v₁ i - u₂ i) := by
      rw [h₁₂.1 i hik, h₂₁.1 i hik]
    _ = (v₁ i - u₁ i) + (v₂ i - u₂ i) := by abel

/-- An alternating four-cycle has one level and one pair of prefix fibres.
A deterministic label of the direction and center therefore puts all four bases
in the same block. -/
theorem alternating_bundles_same_prefix
    (hdouble : Function.Injective (fun a : A => a + a))
    {S : Set A} {i k : ℕ} (g : PaschBundle S i) (h : PaschBundle S k)
    {u₁ u₂ v₁ v₂ : ℕ → A} (h₁₁ : g.Owns u₁ v₁) (h₂₂ : g.Owns u₂ v₂)
    (h₁₂ : h.Owns u₁ v₂) (h₂₁ : h.Owns u₂ v₁) :
    i = k ∧ g.centerSum = h.centerSum ∧
      ∀ a ≤ i, u₁ a = u₂ a ∧ v₁ a = v₂ a := by
  have hik : i = k := le_antisymm
    (Nat.le_of_not_gt (not_lt_of_alternating_bundles h g h₁₂ h₂₁ h₁₁ h₂₂))
    (Nat.le_of_not_gt (not_lt_of_alternating_bundles g h h₁₁ h₂₂ h₁₂ h₂₁))
  subst k
  have hc : g.centerSum = h.centerSum := hdouble (calc
    g.centerSum + g.centerSum = (u₁ i + v₁ i) + (u₂ i + v₂ i) := by
      rw [h₁₁.2.1, h₂₂.2.1]
    _ = (u₁ i + v₂ i) + (u₂ i + v₁ i) := by abel
    _ = h.centerSum + h.centerSum := by rw [h₁₂.2.1, h₂₁.2.1])
  refine ⟨rfl, hc, fun a ha => ?_⟩
  rcases lt_or_eq_of_le ha with hlt | rfl
  · have hd : g.direction a = h.direction a := hdouble (calc
      g.direction a + g.direction a = (v₁ a - u₁ a) + (v₂ a - u₂ a) := by
        rw [h₁₁.1 a hlt, h₂₂.1 a hlt]
      _ = (v₂ a - u₁ a) + (v₁ a - u₂ a) := by abel
      _ = h.direction a + h.direction a := by rw [h₁₂.1 a hlt, h₂₁.1 a hlt])
    exact ⟨by
      have he : v₁ a - u₁ a = v₁ a - u₂ a := by rw [h₁₁.1 a hlt, h₂₁.1 a hlt, hd]
      exact (sub_right_inj.mp he),
      by
        have he : v₁ a - u₁ a = v₂ a - u₁ a := by rw [h₁₁.1 a hlt, h₁₂.1 a hlt, hd]
        exact (sub_left_inj.mp he)⟩
  · exact ⟨add_right_cancel (h₁₁.2.1.trans (hc.trans h₂₁.2.1.symm)),
      add_left_cancel (h₁₁.2.1.trans (hc.trans h₁₂.2.1.symm))⟩

open GapExtremal.R434 GapExtremal.R434.EHPS

/-- Doubling is injective on the actual coordinate grid for odd modulus. -/
theorem grid_double_injective {m : ℕ} (hm : Odd m) :
    Function.Injective (fun a : Grid m => a + a) := by
  have hd : Function.Injective (fun a : ZMod m => a + a) := by
    intro a b hab
    calc
      a = oddHalf m * (a + a) := by
        rw [← two_mul, ← mul_assoc, mul_comm (oddHalf m), two_mul_oddHalf hm, one_mul]
      _ = oddHalf m * (b + b) := congrArg (fun x => oddHalf m * x) hab
      _ = b := by
        rw [← two_mul, ← mul_assoc, mul_comm (oddHalf m), two_mul_oddHalf hm, one_mul]
  intro a b hab
  exact Prod.ext (hd (congrArg Prod.fst hab)) (hd (congrArg Prod.snd hab))

/-- The certified bands of Part I forbid the midpoint of two same-band directions. -/
theorem partI_band_midpoint_outside {ε : ℝ} {m j : ℕ} [NeZero m]
    (hm : Odd m) (cs : PartICylinders ε m j) (p : Fin j) (l : PlaneLabel)
    {a b x : Grid m} (ha : a ∈ cs.bands l) (hb : b ∈ cs.bands l) (hx : x + x = a + b) :
    ¬ Region ε (gridPoint m x) := by
  have hclosure := cs.closed p l (fun _ => a) (fun _ => b) ha hb
  intro hxS
  apply hclosure
  apply mem_productSupport.mpr
  intro z
  have he : (productHalf m j * ((fun _ => a : ProductGrid m j) + (fun _ => b : ProductGrid m j))) z = x := by
    change (oddHalf m, oddHalf m) * (a + b) = x
    rw [← hx]
    apply Prod.ext <;> change oddHalf m * (_ + _) = _ <;>
      rw [← two_mul, ← mul_assoc, mul_comm (oddHalf m), two_mul_oddHalf hm, one_mul]
  rwa [he]

end SplitGapIII
