module

public import RequestProject.TypedTriangle.ApplicationsOctahedronTransport

@[expose] public section
namespace SplitGapIII
open Finset TypedTriangle TypedTriangle.Applications.Octahedron

noncomputable section
open Classical
variable {V I : Type} [Fintype V]

/-- Ordered choices of the two auxiliary vertices. The first four positions
are fixed; membership tests the six physical output triangles. -/
def hingeCompletions (H : Host V I) (F : Set (Multiset I)) (u v a b : V) :
    Finset (Fin 6 ↪ V) := univ.filter fun f =>
  f 0 = u ∧ f 1 = v ∧ f 2 = a ∧ f 3 = b ∧
    ∀ T ∈ mode 2 3 ∪ mode 3 2, IsAllowed H F (T.map f)

/-- With ordered roots the auxiliary edge set recovers positions 5 and 4 as
the unique neighbors of roots 0 and 1. Thus there is no multiplicity loss. -/
theorem physical_hinges_ge_completions (H : Host V I) (F : Set (Multiset I))
    (u v a b : V) :
    (hingeCompletions H F u v a b).card ≤ (hinges H F u v a b 6).card := by
  apply Finset.card_le_card_of_injOn coreImage
  · intro f hf
    obtain ⟨h0,h1,h2,h3,hm⟩ := (mem_filter.mp hf).2
    have hh := hinge_of_modes H F f hm
    rw [h0,h1,h2,h3] at hh
    exact mem_filter.mpr ⟨mem_univ _,hh,card_support_coreImage f⟩
  · intro f hf g hg heq
    obtain ⟨f0,f1,f2,f3,_⟩ := (mem_filter.mp hf).2
    obtain ⟨g0,g1,g2,g3,_⟩ := (mem_filter.mp hg).2
    have h5 := (edge_at_zero f (f 5)).mpr rfl
    have h4 := (edge_at_one f (f 4)).mpr rfl
    rw [heq, f0, ← g0] at h5
    rw [heq, f1, ← g1] at h4
    have eq5 := (edge_at_zero g (f 5)).mp h5
    have eq4 := (edge_at_one g (f 4)).mp h4
    ext i
    fin_cases i <;> simp_all

theorem selected_hinge_condition (H : Host V I) (F : Set (Multiset I)) (α : ℝ)
    (hs : ∀ (u v a b : V), a ≠ b → IsAllowed H F {u,v,a} → IsAllowed H F {u,v,b} →
      α * (Fintype.card V : ℝ)^2 ≤ (hingeCompletions H F u v a b).card) :
    HingeCond H F α 6 := by
  intro u v a b hab ha hb
  refine ⟨6,le_rfl,le_rfl,(hs u v a b hab ha hb).trans ?_⟩
  exact_mod_cast physical_hinges_ge_completions H F u v a b

end
end SplitGapIII
