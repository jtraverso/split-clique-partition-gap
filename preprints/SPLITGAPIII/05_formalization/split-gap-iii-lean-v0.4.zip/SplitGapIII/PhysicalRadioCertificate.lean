module

public import SplitGapIII.BalancedRadios
public import SplitGapIII.RadioSeed
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Algebra.BigOperators.Fin
public import Mathlib.Tactic.FinCases

@[expose] public section

namespace SplitGapIII

open Finset

variable {U V H : Type*} [Fintype U] [Fintype V] [Fintype H]

/-- The real list of hosts of a central before selecting its factor. -/
def availableRadioHosts [DecidableEq U] [DecidableEq H]
    (F : Finset (U × H)) (u : U) : Finset H :=
  univ.filter fun h => (u, h) ∈ F

omit [Fintype U] in
private theorem retained_radio_host_loss [DecidableEq U] [DecidableEq H]
    (F : Finset (U × H)) (P : H → Finset U) (d : ℕ)
    (hsub : ∀ h u, u ∈ P h → (u, h) ∈ F)
    (hd : ∀ u, (univ.filter fun h => u ∈ P h).card = d) (u : U) :
    (availableRadioHosts F u \ (univ.filter fun h => u ∈ P h)).card =
      (availableRadioHosts F u).card - d := by
  rw [card_sdiff_of_subset, hd]
  intro h hh
  exact mem_filter.mpr ⟨mem_univ _, hsub _ _ (mem_filter.mp hh).2⟩

/-- The cuts select the two factors on the original available radios. A
strict common-host margin for each anchored rectangle certifies the signed
lattice condition for the whole selected bipartite support. -/
theorem bipartite_integer_certificate_of_cuts [DecidableEq U] [DecidableEq V] [DecidableEq H]
    (L : Finset (U × H)) (R : Finset (V × H)) (a : H → ℕ)
    (hbalance : ∑ h, a h = Fintype.card U * Fintype.card V)
    (hL : ∀ (X : Finset U) (Y : Finset H), X.card * Fintype.card V ≤
      (L.filter fun e => e.1 ∈ X ∧ e.2 ∉ Y).card + ∑ h ∈ Y, a h)
    (hR : ∀ (X : Finset V) (Y : Finset H), X.card * Fintype.card U ≤
      (R.filter fun e => e.1 ∈ X ∧ e.2 ∉ Y).card + ∑ h ∈ Y, a h)
    (u₀ : U) (v₀ : V)
    (hrich : ∀ u v,
      (availableRadioHosts L u).card - Fintype.card V +
      ((availableRadioHosts L u₀).card - Fintype.card V) +
      ((availableRadioHosts R v).card - Fintype.card U) +
      ((availableRadioHosts R v₀).card - Fintype.card U) <
      (availableRadioHosts L u ∩ availableRadioHosts L u₀ ∩
        availableRadioHosts R v ∩ availableRadioHosts R v₀).card) :
    ∃ (A : H → Finset U) (B : H → Finset V) (Z : H → U → V → ℤ),
      (∀ h u, u ∈ A h → (u,h) ∈ L) ∧
      (∀ h v, v ∈ B h → (v,h) ∈ R) ∧
      (∀ h, (A h).card = a h ∧ (B h).card = a h) ∧
      (∀ u, (univ.filter fun h => u ∈ A h).card = Fintype.card V) ∧
      (∀ v, (univ.filter fun h => v ∈ B h).card = Fintype.card U) ∧
      (∀ h u v, (u ∉ A h ∨ v ∉ B h) → Z h u v = 0) ∧
      (∀ h u, ∑ v, Z h u v = if u ∈ A h then 1 else 0) ∧
      (∀ h v, ∑ u, Z h u v = if v ∈ B h then 1 else 0) ∧
      (∀ u v, ∑ h, Z h u v = 1) := by
  classical
  obtain ⟨A, hAs, hAa, hAd⟩ := exists_surviving_radio_palettes L
    (fun _ => Fintype.card V) a
    (by simp [sum_const, hbalance])
    (by simpa [sum_const, nsmul_eq_mul] using hL)
  obtain ⟨B, hBs, hBa, hBd⟩ := exists_surviving_radio_palettes R
    (fun _ => Fintype.card U) a
    (by simp [sum_const, hbalance, Nat.mul_comm])
    (by simpa [sum_const, nsmul_eq_mul] using hR)
  have hAloss := retained_radio_host_loss L A _ hAs hAd
  have hBloss := retained_radio_host_loss R B _ hBs hBd
  have hsupply (u : U) (v : V) :
      ∃ h, u ∈ A h ∧ u₀ ∈ A h ∧ v ∈ B h ∧ v₀ ∈ B h := by
    let S := availableRadioHosts L u ∩ availableRadioHosts L u₀ ∩
      availableRadioHosts R v ∩ availableRadioHosts R v₀
    let old : Fin 4 → Finset H := ![availableRadioHosts L u, availableRadioHosts L u₀,
      availableRadioHosts R v, availableRadioHosts R v₀]
    let kept : Fin 4 → Finset H := ![univ.filter (fun h => u ∈ A h), univ.filter (fun h => u₀ ∈ A h),
      univ.filter (fun h => v ∈ B h), univ.filter (fun h => v₀ ∈ B h)]
    have hcommon : ∀ h ∈ S, ∀ i, h ∈ old i := by
      intro h hh i
      have hh' := mem_inter.mp hh
      have hthree := mem_inter.mp hh'.1
      have htwo := mem_inter.mp hthree.1
      fin_cases i <;> simp [old, hh'.2, hthree.2, htwo.1, htwo.2]
    let decGood : DecidablePred (fun h : H => ∀ i, h ∈ kept i) := Classical.decPred _
    let good := @Finset.filter H (fun h => ∀ i, h ∈ kept i) decGood S
    have hloss : S.card ≤ good.card + ∑ i, (old i \ kept i).card :=
      @common_hosts_after_losses (Fin 4) H _ _ S old kept decGood hcommon
    have hsum : (∑ i, (old i \ kept i).card) < S.card := by
      simpa [old, kept, S, Fin.sum_univ_succ, hAloss, hBloss, Nat.add_assoc] using hrich u v
    have hpos : 0 < good.card := by omega
    obtain ⟨h, hh⟩ := card_pos.mp hpos
    have hg := (mem_filter.mp hh).2
    exact ⟨h, by simpa [kept] using hg 0, by simpa [kept] using hg 1,
      by simpa [kept] using hg 2, by simpa [kept] using hg 3⟩
  obtain ⟨Z, hZs, hZl, hZr, hZb⟩ := bipartite_integer_certificate A B
    (fun h => (hAa h).trans (hBa h).symm) hAd hBd u₀ v₀ hsupply
  exact ⟨A, B, Z, hAs, hBs, fun h => ⟨hAa h, hBa h⟩, hAd, hBd, hZs, hZl, hZr, hZb⟩

end SplitGapIII
