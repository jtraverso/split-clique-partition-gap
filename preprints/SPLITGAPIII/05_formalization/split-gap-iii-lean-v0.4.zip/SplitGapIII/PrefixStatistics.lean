module

public import SplitGapIII.Reassignment

@[expose] public section

namespace SplitGapIII
open Finset
open scoped BigOperators

/-- The unmarked terminal pieces can change the sum of a bounded monitor only
by their number. -/
theorem monitor_shift_le_terminal_card {T : Type*} [DecidableEq T]
    (first terminal : Finset T) (hd : Disjoint first terminal)
    (w : T → ℝ) (hw : ∀ e ∈ terminal, |w e| ≤ 1) :
    |(∑ e ∈ first ∪ terminal, w e) - ∑ e ∈ first, w e| ≤ (terminal.card : ℝ) := by
  rw [sum_union hd]
  have hs : (∑ e ∈ first, w e) + (∑ e ∈ terminal, w e) - (∑ e ∈ first, w e) =
      ∑ e ∈ terminal, w e := by ring
  rw [hs]
  calc
    |∑ e ∈ terminal, w e| ≤ ∑ e ∈ terminal, |w e| := abs_sum_le_sum_abs _ _
    _ ≤ ∑ _ ∈ terminal, (1 : ℝ) := sum_le_sum hw
    _ = terminal.card := by simp

/-- A linear upper bound on the loss of colors is sufficient for the local
degree threshold, even if the prefix and the repair share hosts. -/
theorem shared_reserve_local_bound {H : Type*} [DecidableEq H]
    (lists usedA usedB : Finset H) (degreeA degreeB usedDegreeA usedDegreeB : ℕ)
    (hA : usedDegreeA ≤ degreeA) (hB : usedDegreeB ≤ degreeB)
    (budgetA : degreeA + (lists ∩ usedA).card + (lists ∩ usedB).card ≤
      lists.card + usedDegreeA)
    (budgetB : degreeB + (lists ∩ usedA).card + (lists ∩ usedB).card ≤
      lists.card + usedDegreeB) :
    max (degreeA - usedDegreeA) (degreeB - usedDegreeB) ≤
      (lists \ (usedA ∪ usedB)).card := by
  have hb : max (degreeA - usedDegreeA) (degreeB - usedDegreeB) +
      (lists ∩ usedA).card + (lists ∩ usedB).card ≤ lists.card := by
    rw [max_def]
    split <;> omega
  have htrim := trim_two_lists lists (lists ∩ usedA) (lists ∩ usedB) _ hb
  have heq : lists \ ((lists ∩ usedA) ∪ (lists ∩ usedB)) =
      lists \ (usedA ∪ usedB) := by
    ext x
    simp only [mem_sdiff, mem_union, mem_inter]
    tauto
  rwa [heq] at htrim

/-- The joint monitor gives enough colors for the sum of both residual degrees
and retains an explicit slack for further choices. -/
theorem shared_reserve_joint_bound {H : Type*} [DecidableEq H]
    (lists usedA usedB : Finset H) (degreeA degreeB usedDegreeA usedDegreeB slack : ℕ)
    (hA : usedDegreeA ≤ degreeA) (hB : usedDegreeB ≤ degreeB)
    (budget : degreeA + degreeB + slack + (lists ∩ usedA).card + (lists ∩ usedB).card ≤
      lists.card + usedDegreeA + usedDegreeB) :
    degreeA - usedDegreeA + (degreeB - usedDegreeB) + slack ≤
      (lists \ (usedA ∪ usedB)).card := by
  have h := trim_two_lists lists (lists ∩ usedA) (lists ∩ usedB)
    (degreeA - usedDegreeA + (degreeB - usedDegreeB) + slack) (by omega)
  have heq : lists \ ((lists ∩ usedA) ∪ (lists ∩ usedB)) = lists \ (usedA ∪ usedB) := by
    ext x
    simp only [mem_sdiff, mem_union, mem_inter]
    tauto
  rwa [heq] at h

end SplitGapIII
