module

public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Algebra.BigOperators.Field
public import Mathlib.Basic.Real.Basic
public import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
public import Mathlib.Data.Fintype.EquivFin
public import Mathlib.Tactic.Ring

/-! # The bipartite seed and its base deficit

Every radio has the required load on an individual host rectangle. The
remaining base correction is an integer-linear combination of rectangle
switches with zero radio margins. -/

@[expose] public section

namespace SplitGapIII

open Finset

variable {U V H : Type*} [Fintype U] [Fintype V] [Fintype H]

noncomputable def rectangleSeed [DecidableEq U] [DecidableEq V]
    (A : H → Finset U) (B : H → Finset V) (a : H → ℕ) (h : H) (u : U) (v : V) : ℝ :=
  if u ∈ A h ∧ v ∈ B h then (a h : ℝ)⁻¹ else 0

omit [Fintype H] in
theorem rectangleSeed_radio_margins [DecidableEq U] [DecidableEq V]
    (A : H → Finset U) (B : H → Finset V) (a : H → ℕ)
    (hA : ∀ h, (A h).card = a h) (hB : ∀ h, (B h).card = a h) :
    (∀ h u, ∑ v, rectangleSeed A B a h u v = if u ∈ A h then 1 else 0) ∧
    (∀ h v, ∑ u, rectangleSeed A B a h u v = if v ∈ B h then 1 else 0) := by
  constructor
  · intro h u
    by_cases hu : u ∈ A h
    · have ha : (a h : ℝ) ≠ 0 := by
        exact_mod_cast (hA h ▸ card_ne_zero.mpr ⟨u, hu⟩)
      simp only [rectangleSeed, hu, true_and, ite_true]
      rw [← sum_filter]
      have he : univ.filter (fun v => v ∈ B h) = B h := by ext v; simp
      rw [he, sum_const, nsmul_eq_mul, hB, mul_inv_cancel₀ ha]
    · simp [rectangleSeed, hu]
  · intro h v
    by_cases hv : v ∈ B h
    · have ha : (a h : ℝ) ≠ 0 := by
        exact_mod_cast (hB h ▸ card_ne_zero.mpr ⟨v, hv⟩)
      simp only [rectangleSeed, hv, and_true, ite_true]
      rw [← sum_filter]
      have he : univ.filter (fun u => u ∈ A h) = A h := by ext u; simp
      rw [he, sum_const, nsmul_eq_mul, hA, mul_inv_cancel₀ ha]
    · simp [rectangleSeed, hv]

private theorem base_deficit_zero_margins {R : Type*} [Ring R]
    [DecidableEq U] [DecidableEq V] (A : H → Finset U) (B : H → Finset V)
    (W : H → U → V → R)
    (hl : ∀ h u, ∑ v, W h u v = if u ∈ A h then 1 else 0)
    (hr : ∀ h v, ∑ u, W h u v = if v ∈ B h then 1 else 0)
    (hU : ∀ u, (univ.filter fun h => u ∈ A h).card = Fintype.card V)
    (hV : ∀ v, (univ.filter fun h => v ∈ B h).card = Fintype.card U) :
    (∀ u, ∑ v, (1 - ∑ h, W h u v) = 0) ∧
    (∀ v, ∑ u, (1 - ∑ h, W h u v) = 0) := by
  constructor
  · intro u
    rw [sum_sub_distrib, sum_comm]
    simp only [hl, ← sum_filter, sum_const, nsmul_eq_mul, mul_one, card_univ, hU, sub_self]
  · intro v
    rw [sum_sub_distrib, sum_comm]
    simp only [hr, ← sum_filter, sum_const, nsmul_eq_mul, mul_one, card_univ, hV, sub_self]

theorem rectangleSeed_base_deficit_zero_margins [DecidableEq U] [DecidableEq V]
    (A : H → Finset U) (B : H → Finset V) (a : H → ℕ)
    (hA : ∀ h, (A h).card = a h) (hB : ∀ h, (B h).card = a h)
    (hU : ∀ u, (univ.filter fun h => u ∈ A h).card = Fintype.card V)
    (hV : ∀ v, (univ.filter fun h => v ∈ B h).card = Fintype.card U) :
    (∀ u, ∑ v, (1 - ∑ h, rectangleSeed A B a h u v) = 0) ∧
    (∀ v, ∑ u, (1 - ∑ h, rectangleSeed A B a h u v) = 0) := by
  obtain ⟨hl, hr⟩ := rectangleSeed_radio_margins A B a hA hB
  exact base_deficit_zero_margins A B _ hl hr hU hV

section Switches

variable {R : Type*} [CommRing R] [DecidableEq U] [DecidableEq V]

/-- The signed row or column of a switch, centered at one anchor. -/
def rectangleAnchorSign {X : Type*} [DecidableEq X] (x u anchor : X) : R :=
  (if x = u then 1 else 0) - if x = anchor then 1 else 0

private theorem sum_rectangleAnchorSign {X : Type*} [Fintype X] [DecidableEq X] (u a : X) :
    ∑ x, (rectangleAnchorSign x u a : R) = 0 := by
  simp [rectangleAnchorSign, sum_sub_distrib]

private theorem sum_mul_rectangleAnchorSign {X : Type*} [Fintype X] [DecidableEq X]
    (f : X → R) (h : ∑ x, f x = 0) (x a : X) :
    ∑ u, f u * rectangleAnchorSign x u a = f x := by
  simp only [rectangleAnchorSign, mul_sub, sum_sub_distrib]
  rw [← sum_mul, h, zero_mul, sub_zero]
  simp [mul_ite]

/-- Every array with zero row and column sums is a sum of signed rectangle
switches, for any two fixed anchors. This works over both integers and reals. -/
theorem rectangle_switch_expansion (D : U → V → R)
    (hrow : ∀ u, ∑ v, D u v = 0) (hcol : ∀ v, ∑ u, D u v = 0)
    (a : U) (b : V) (x : U) (y : V) :
    (∑ u, ∑ v, D u v * rectangleAnchorSign x u a * rectangleAnchorSign y v b) = D x y := by
  calc
    _ = ∑ u, (∑ v, D u v * rectangleAnchorSign y v b) * rectangleAnchorSign x u a := by
      apply sum_congr rfl
      intro u _
      rw [sum_mul]
      apply sum_congr rfl
      intro v _
      ring
    _ = ∑ u, D u y * rectangleAnchorSign x u a := by
      simp only [sum_mul_rectangleAnchorSign (D _) (hrow _) y b]
    _ = D x y := sum_mul_rectangleAnchorSign (fun u => D u y) (hcol y) x a

/-- If every anchored rectangle has an available host, distribute the
switches among those hosts. The correction occupies only the actual host
rectangles, leaves all radio loads unchanged, and realizes the base deficit. -/
theorem exists_radio_neutral_correction
    (A : H → Finset U) (B : H → Finset V) (D : U → V → R)
    (hrow : ∀ u, ∑ v, D u v = 0) (hcol : ∀ v, ∑ u, D u v = 0)
    (a : U) (b : V)
    (hsupply : ∀ u v, ∃ h, u ∈ A h ∧ a ∈ A h ∧ v ∈ B h ∧ b ∈ B h) :
    ∃ δ : H → U → V → R,
      (∀ h x y, (x ∉ A h ∨ y ∉ B h) → δ h x y = 0) ∧
      (∀ h x, ∑ y, δ h x y = 0) ∧
      (∀ h y, ∑ x, δ h x y = 0) ∧
      (∀ x y, ∑ h, δ h x y = D x y) := by
  classical
  choose pick hpick using hsupply
  let δ (h : H) (x : U) (y : V) :=
    ∑ u, ∑ v, if pick u v = h then D u v * rectangleAnchorSign x u a * rectangleAnchorSign y v b else 0
  refine ⟨δ, ?_, ?_, ?_, ?_⟩
  · intro h x y hout
    apply sum_eq_zero
    intro u _
    apply sum_eq_zero
    intro v _
    by_cases hp : pick u v = h
    · have hmem := hp ▸ hpick u v
      rcases hout with hx | hy
      · have hxu : x ≠ u := fun he => hx (he ▸ hmem.1)
        have hxa : x ≠ a := fun he => hx (he ▸ hmem.2.1)
        simp [hp, rectangleAnchorSign, hxu, hxa]
      · have hyv : y ≠ v := fun he => hy (he ▸ hmem.2.2.1)
        have hyb : y ≠ b := fun he => hy (he ▸ hmem.2.2.2)
        simp [hp, rectangleAnchorSign, hyv, hyb]
    · simp [hp]
  · intro h x
    dsimp only [δ]
    rw [sum_comm]
    apply sum_eq_zero
    intro u _
    rw [sum_comm]
    apply sum_eq_zero
    intro v _
    by_cases hp : pick u v = h
    · simp only [hp, ite_true, ← mul_sum, sum_rectangleAnchorSign, mul_zero]
    · simp [hp]
  · intro h y
    dsimp only [δ]
    rw [sum_comm]
    apply sum_eq_zero
    intro u _
    rw [sum_comm]
    apply sum_eq_zero
    intro v _
    by_cases hp : pick u v = h
    · simp only [hp, ite_true, ← sum_mul, ← mul_sum, sum_rectangleAnchorSign, mul_zero, zero_mul]
    · simp [hp]
  · intro x y
    dsimp only [δ]
    rw [sum_comm]
    calc
      _ = ∑ u, ∑ v, D u v * rectangleAnchorSign x u a * rectangleAnchorSign y v b := by
        apply sum_congr rfl
        intro u _
        rw [sum_comm]
        apply sum_congr rfl
        intro v _
        simp
      _ = D x y := rectangle_switch_expansion D hrow hcol a b x y

end Switches

omit [Fintype H] in
private theorem exists_palette_matching_matrix [DecidableEq U] [DecidableEq V]
    (A : Finset U) (B : Finset V) (hcard : A.card = B.card) :
    ∃ W : U → V → ℤ,
      (∀ u v, (u ∉ A ∨ v ∉ B) → W u v = 0) ∧
      (∀ u, ∑ v, W u v = if u ∈ A then 1 else 0) ∧
      (∀ v, ∑ u, W u v = if v ∈ B then 1 else 0) := by
  let matchHost := A.equivOfCardEq hcard
  let W (u : U) (v : V) : ℤ :=
    if hu : u ∈ A then if (matchHost ⟨u, hu⟩ : V) = v then 1 else 0 else 0
  refine ⟨W, ?_, ?_, ?_⟩
  · intro u v hout
    by_cases hu : u ∈ A
    · have hv := hout.resolve_left (not_not_intro hu)
      have hne : (matchHost ⟨u, hu⟩ : V) ≠ v :=
        fun he => hv (he ▸ (matchHost ⟨u, hu⟩).property)
      simp [W, hu, hne]
    · simp [W, hu]
  · intro u
    by_cases hu : u ∈ A <;> simp [W, hu]
  · intro v
    by_cases hv : v ∈ B
    · let hit := matchHost.symm ⟨v, hv⟩
      have he (u : U) : W u v = if u = hit.val then 1 else 0 := by
        by_cases hu : u ∈ A
        · have hi : (matchHost ⟨u, hu⟩ : V) = v ↔ u = hit.val := by
            constructor
            · intro hh
              have hs : matchHost ⟨u, hu⟩ = matchHost hit :=
                Subtype.ext (by simpa [hit] using hh)
              exact congrArg Subtype.val (matchHost.injective hs)
            · intro hh
              have hs : (⟨u, hu⟩ : A) = hit := Subtype.ext hh
              simp [hs, hit]
          simp [W, hu, hi]
        · have hn : u ≠ hit.val := fun hh => hu (hh.symm ▸ hit.property)
          simp [W, hu, hn]
      simp [he, hv]
    · have he (u : U) : W u v = 0 := by
        by_cases hu : u ∈ A
        · have hn : (matchHost ⟨u, hu⟩ : V) ≠ v :=
            fun hh => hv (hh ▸ (matchHost ⟨u, hu⟩).property)
          simp [W, hu, hn]
        · simp [W, hu]
      simp [he, hv]

/-- A signed triangle-lattice certificate for the complete bipartite base
and all selected radios, under the balanced palettes and switch supply. -/
theorem bipartite_integer_certificate [DecidableEq U] [DecidableEq V]
    (A : H → Finset U) (B : H → Finset V)
    (hhost : ∀ h, (A h).card = (B h).card)
    (hU : ∀ u, (univ.filter fun h => u ∈ A h).card = Fintype.card V)
    (hV : ∀ v, (univ.filter fun h => v ∈ B h).card = Fintype.card U)
    (a : U) (b : V)
    (hsupply : ∀ u v, ∃ h, u ∈ A h ∧ a ∈ A h ∧ v ∈ B h ∧ b ∈ B h) :
    ∃ Z : H → U → V → ℤ,
      (∀ h u v, (u ∉ A h ∨ v ∉ B h) → Z h u v = 0) ∧
      (∀ h u, ∑ v, Z h u v = if u ∈ A h then 1 else 0) ∧
      (∀ h v, ∑ u, Z h u v = if v ∈ B h then 1 else 0) ∧
      (∀ u v, ∑ h, Z h u v = 1) := by
  classical
  choose W hw using fun h => exists_palette_matching_matrix (A h) (B h) (hhost h)
  let D (u : U) (v : V) : ℤ := 1 - ∑ h, W h u v
  obtain ⟨hrow, hcol⟩ :=
    base_deficit_zero_margins A B W (fun h => (hw h).2.1) (fun h => (hw h).2.2) hU hV
  obtain ⟨δ, hd0, hdl, hdr, hdb⟩ :=
    exists_radio_neutral_correction A B D hrow hcol a b hsupply
  refine ⟨fun h u v => W h u v + δ h u v, ?_, ?_, ?_, ?_⟩
  · intro h u v huv
    change W h u v + δ h u v = 0
    rw [(hw h).1 u v huv, hd0 h u v huv, add_zero]
  · intro h u
    rw [sum_add_distrib, (hw h).2.1, hdl, add_zero]
  · intro h v
    rw [sum_add_distrib, (hw h).2.2, hdr, add_zero]
  · intro u v
    rw [sum_add_distrib, hdb]
    simp [D]

end SplitGapIII
