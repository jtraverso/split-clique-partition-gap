module

public import SplitGapIII.PhysicalHinges
public import RequestProject.TypedTriangle.MainPaperIIIPasch

@[expose] public section
namespace SplitGapIII

open Finset TypedTriangle Classical
open scoped BigOperators

/-- Finite T+ transfer on the selected graph, with the reference targets
fixed separately. The same decomposition pays every monitor and Pasch. -/
theorem selected_decomposition_with_reference_targets {I : Type} (F : Set (Multiset I))
    (α C ε : ℝ) (q : ℕ) (hα : 0 < α) (hC : 1 ≤ C) (hε : 0 < ε) :
    ∃ n₀ : ℕ, ∀ {V : Type} [Fintype V] (H : Host V I) (μ : Finset V → ℝ),
      n₀ ≤ Fintype.card V → IsDiffuseSeed H F C μ → IsPhysical H F (edges H) →
      CommonNbrCond H F α →
      (∀ (u v a b : V), a ≠ b → IsAllowed H F {u,v,a} → IsAllowed H F {u,v,b} →
        α * (Fintype.card V : ℝ)^2 ≤ (hingeCompletions H F u v a b).card) →
      ∀ (J : Type) [Fintype J] (w : J → Finset V → ℝ)
        (linearTarget linearError : J → ℝ) (paschTarget paschError : ℝ),
        (Fintype.card J : ℝ) ≤ (Fintype.card V : ℝ)^q →
        (∀ j T, IsAllowed H F T → |w j T| ≤ 1) →
        (∀ j, |(∑ T ∈ allowed H F, μ T * w j T) - linearTarget j| ≤ linearError j) →
        |Pasch.target μ (allowed H F) - paschTarget| ≤ paschError →
        ∃ D, IsDecomposition H F (edges H) D ∧
          (∀ j, |(∑ T ∈ D, w j T) - linearTarget j| ≤ ε * (Fintype.card V : ℝ)^2 + linearError j) ∧
          |(Pasch.count D : ℝ) - paschTarget| ≤ ε * (Fintype.card V : ℝ)^2 + paschError := by
  classical
  obtain ⟨n₀, h⟩ := Vortex.main_theorem_T_with_triangle_monitors_and_pasch F α C ε 6 q
    hα hC le_rfl hε
  refine ⟨n₀, ?_⟩
  intro V _ H μ hn hμ hphys hnbr hc J _ w lt le pt pe hj hw hl hp
  obtain ⟨D,hD,hwD,hpD⟩ := h H μ hn hμ hphys hnbr (selected_hinge_condition H F α hc)
    J w hj hw
  exact ⟨D,hD,fun j => (abs_sub_le _ _ _).trans (add_le_add (hwD j) (hl j)),
    (abs_sub_le _ _ _).trans (add_le_add hpD hp)⟩

end SplitGapIII
