module

public import SplitGapIII.PrefixStatistics

@[expose] public section

namespace SplitGapIII
open Finset
open scoped BigOperators

/-- A coloring is defined on a finite subset of its requests. -/
def ListPrefix {E H : Type*} (conflict : E → E → Prop) (lists : E → Finset H)
    (J : Finset E) (assign : E → H) : Prop :=
  (∀ e ∈ J, assign e ∈ lists e) ∧
    ∀ e ∈ J, ∀ f ∈ J, conflict e f → assign e ≠ assign f

/-- With more colors than conflicting requests, every compatible partial coloring extends,
using the same lists and preserving every color already assigned. -/
theorem extend_shared_lists {E H : Type*} [DecidableEq E] [DecidableEq H]
    (conflict : E → E → Prop) [DecidableRel conflict]
    (symmetric : ∀ ⦃a b⦄, conflict a b → conflict b a) (loopless : ∀ e, ¬ conflict e e)
    (J P : Finset E) (hP : P ⊆ J) (lists : E → Finset H)
    (large : ∀ e ∈ J, (J.filter (conflict e)).card < (lists e).card)
    (initial : E → H) (hprefix : ListPrefix conflict lists P initial) :
    ∃ assign : E → H, ListPrefix conflict lists J assign ∧ ∀ e ∈ P, assign e = initial e := by
  classical
  let states := J.powerset.filter fun S =>
    P ⊆ S ∧ ∃ c : E → H, ListPrefix conflict lists S c ∧ ∀ e ∈ P, c e = initial e
  have hs : states.Nonempty := ⟨P, mem_filter.mpr
    ⟨mem_powerset.mpr hP, Subset.rfl, initial, hprefix, fun _ _ => rfl⟩⟩
  obtain ⟨S, hS, hmax⟩ := exists_max_image states card hs
  obtain ⟨hSJ, hPS, c, hc, hkeep⟩ := mem_filter.mp hS
  have hsub : S ⊆ J := mem_powerset.mp hSJ
  have hEq : S = J := by
    apply Subset.antisymm hsub
    intro e he
    by_contra hen
    let used := (S.filter (conflict e)).image c
    have hle : used.card ≤ (J.filter (conflict e)).card :=
      card_image_le.trans (card_le_card (fun f hf => mem_filter.mpr
        ⟨hsub (mem_filter.mp hf).1, (mem_filter.mp hf).2⟩))
    have hpos : 0 < ((lists e) \ used).card := by
      have h := card_le_card_sdiff_add_card (s := lists e) (t := used)
      have h' := large e he
      omega
    obtain ⟨k, hk⟩ := card_pos.mp hpos
    let c' := Function.update c e k
    have hnew : ListPrefix conflict lists (insert e S) c' := by
      constructor
      · intro a ha
        rcases mem_insert.mp ha with rfl | ha
        · simpa [c'] using (mem_sdiff.mp hk).1
        · have hne : a ≠ e := fun h => hen (h ▸ ha)
          simpa [c', Function.update_of_ne hne] using hc.1 a ha
      · intro a ha b hb hab
        rcases mem_insert.mp ha with h | haS <;> rcases mem_insert.mp hb with h' | hbS
        · subst a; subst b
          exact (loopless _ hab).elim
        · subst a
          have hn : b ≠ e := fun h => hen (h ▸ hbS)
          have hk' : k ≠ c b := by
            intro eq
            exact (mem_sdiff.mp hk).2 (mem_image.mpr ⟨b, mem_filter.mpr ⟨hbS, hab⟩, eq.symm⟩)
          simpa [c', Function.update_of_ne hn] using hk'
        · subst b
          have hn : a ≠ e := fun h => hen (h ▸ haS)
          have hk' : c a ≠ k := by
            intro eq
            exact (mem_sdiff.mp hk).2 (mem_image.mpr ⟨a, mem_filter.mpr ⟨haS, symmetric hab⟩, eq⟩)
          simpa [c', Function.update_of_ne hn] using hk'
        · have ha' : a ≠ e := fun h => hen (h ▸ haS)
          have hb' : b ≠ e := fun h => hen (h ▸ hbS)
          simpa [c', Function.update_of_ne ha', Function.update_of_ne hb'] using hc.2 a haS b hbS hab
    have hmem : insert e S ∈ states := by
      refine mem_filter.mpr ⟨mem_powerset.mpr (insert_subset he hsub),
        hPS.trans (subset_insert _ _), c', hnew, ?_⟩
      intro a ha
      have hn : a ≠ e := fun h => hen (h ▸ hPS ha)
      simpa [c', Function.update_of_ne hn] using hkeep a ha
    have hcard := hmax _ hmem
    rw [card_insert_of_notMem hen] at hcard
    omega
  exact hEq ▸ ⟨c, hc, hkeep⟩

/-- On a nonempty surviving list the uniform seed saturates its request. -/
theorem uniform_seed_saturation {H : Type*} (L : Finset H) (hL : L.Nonempty) :
    ∑ _ ∈ L, (1 : ℝ) / L.card = 1 := by
  have hp : (0 : ℝ) < L.card := by exact_mod_cast card_pos.mpr hL
  simp [sum_const, nsmul_eq_mul, hp.ne']

/-- When the lists have twice the size of the incidence degree, the uniform
seed loads any one radio to at most one half. -/
theorem uniform_seed_port_slack {E H : Type*} (incident : Finset E)
    (L : E → Finset H) (degree : ℕ) (hd : 0 < degree)
    (hcount : incident.card ≤ degree) (large : ∀ e ∈ incident, 2*degree ≤ (L e).card) :
    ∑ e ∈ incident, (1 : ℝ) / (L e).card ≤ 1/2 := by
  have hdR : (0 : ℝ) < degree := by exact_mod_cast hd
  calc
    ∑ e ∈ incident, (1 : ℝ) / (L e).card ≤ ∑ _ ∈ incident, (1 : ℝ) / (2*degree) := by
      apply sum_le_sum
      intro e he
      exact one_div_le_one_div_of_le (by positivity) (by exact_mod_cast large e he)
    _ = (incident.card : ℝ) / (2*degree) := by simp [sum_const, nsmul_eq_mul, div_eq_mul_inv]
    _ ≤ 1/2 := by
      apply (div_le_iff₀ (by positivity)).mpr
      have hc : (incident.card : ℝ) ≤ degree := by exact_mod_cast hcount
      linarith

end SplitGapIII
