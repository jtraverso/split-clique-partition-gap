module

public import SplitGapIII.Cylinders

@[expose] public section

namespace SplitGapIII
open Finset GapExtremal QuadraticExteriorPalomar

variable {V H W : Type*} [Fintype V] [DecidableEq V] [Fintype H] [DecidableEq H]
variable [Fintype W] [DecidableEq W]

/-- Translate a pair of padding vertices to its original two core vertices. -/
def corePair (embed : W ↪ V) (e : (⊤ : SimpleGraph W).edgeSet) : Finset V :=
  e.val.toFinset.map embed

/-- A complete terminal clique can be filled after a compatible prefix. Its lists already
exclude every port occupied by the prefix. -/
theorem fill_terminal_clique
    (N : H → Finset V) (J P : Finset (Finset V)) (first : P → H)
    (hfirst : Assigned N P first) (embed : W ↪ V)
    (lists : (⊤ : SimpleGraph W).edgeSet → Finset H)
    (large : ∀ e, Fintype.card W ≤ (lists e).card)
    (physical : ∀ e h, h ∈ lists e → corePair embed e ⊆ N h)
    (unused : ∀ e h, h ∈ lists e → ∀ f : P, first f = h →
      ∀ v ∈ f.val, v ∉ corePair embed e)
    (cover : ∀ e ∈ J, e ∈ P ∨ ∃ t, corePair embed t = e) :
    ∃ host : J → H, Assigned N J host := by
  classical
  obtain ⟨color, hcolor⟩ := recover_complete lists large
  let T : Finset (Finset V) := univ.image (corePair embed)
  have select (e : T) : ∃ t, corePair embed t = e.val := by
    obtain ⟨t, _, ht⟩ := mem_image.mp e.property
    exact ⟨t, ht⟩
  choose index hindex using select
  let terminal (e : T) := color (index e)
  have hterminal : Assigned N T terminal := by
    refine ⟨?_, ?_⟩
    · intro e
      rw [← hindex e]
      exact physical (index e) _ (hcolor (index e))
    · intro e f heq v hev hfv
      have same : index e = index f := by
        by_contra hdifferent
        have he : v ∈ corePair embed (index e) := by rwa [hindex e]
        have hf : v ∈ corePair embed (index f) := by rwa [hindex f]
        obtain ⟨x, hx, heqv⟩ := mem_map.mp he
        obtain ⟨y, hy, hfy⟩ := mem_map.mp hf
        have hxy : x = y := embed.injective (heqv.trans hfy.symm)
        exact color.valid (SimpleGraph.lineGraph_adj_iff_exists.mpr
          ⟨hdifferent, x, Sym2.mem_toFinset.mp hx, Sym2.mem_toFinset.mp (hxy.symm ▸ hy)⟩) heq
      apply Subtype.ext
      rw [← hindex e, ← hindex f, same]
  refine assemble_prefix_and_terminal N J P T ?_ first terminal hfirst hterminal ?_
  · intro e he
    rcases cover e he with hp | ⟨t, ht⟩
    · exact Or.inl hp
    · exact Or.inr (mem_image.mpr ⟨t, mem_univ _, ht⟩)
  · intro e f heq v he hf
    exact unused (index f) _ (hcolor (index f)) e heq v he (by rwa [hindex f])

/-- The padded split has exactly the residual gap once its terminal lists can be filled. -/
theorem exact_gap_after_terminal_clique (B : SimpleGraph V) [DecidableRel B.Adj]
    (N : H → Finset V) (independent : ∀ h, ∀ a ∈ N h, ∀ b ∈ N h, ¬ B.Adj a b)
    (P : Finset (Finset V)) (first : P → H)
    (hfirst : Assigned N P first) (embed : W ↪ V)
    (lists : (⊤ : SimpleGraph W).edgeSet → Finset H)
    (large : ∀ e, Fintype.card W ≤ (lists e).card)
    (physical : ∀ e h, h ∈ lists e → corePair embed e ⊆ N h)
    (unused : ∀ e h, h ∈ lists e → ∀ f : P, first f = h →
      ∀ v ∈ f.val, v ∉ corePair embed e)
    (cover : ∀ e ∈ jPairs B univ, e ∈ P ∨ ∃ t, corePair embed t = e) :
    gap (hostGraph N) = residualSup B - residualInt B := by
  obtain ⟨host, hhost⟩ := fill_terminal_clique N (jPairs B univ) P first hfirst embed lists
    large physical unused cover
  exact gap_of_complete_recovery B N independent host hhost

end SplitGapIII
