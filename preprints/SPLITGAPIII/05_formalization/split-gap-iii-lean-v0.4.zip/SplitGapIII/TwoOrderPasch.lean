module

public import SplitGapIII.PaschBlocks

/-! # Alternating cycles in the two-order palette

A pool fixes the center at every observed coordinate. Its owned edges have
directions in the support at all original coordinates preceding the failure,
including the original penultimate coordinate in the secondary stage. -/

@[expose] public section

namespace SplitGapIII

/-- With j+2 coordinates, the primary order can fail anywhere but the original
last coordinate. The secondary order observes that last coordinate instead
of the penultimate one. -/
inductive TwoOrderStage (j : ℕ)
  | primary (i : Fin (j + 1))
  | secondary

def TwoOrderStage.failure {j : ℕ} : TwoOrderStage j → ℕ
  | .primary i => i.val
  | .secondary => j + 1

def TwoOrderStage.observes {j : ℕ} : TwoOrderStage j → ℕ → Prop
  | .primary i, k => k ≤ i.val
  | .secondary, k => k < j ∨ k = j + 1

private theorem TwoOrderStage.observes_failure {j : ℕ} (s : TwoOrderStage j) :
    s.observes s.failure := by
  cases s <;> simp [TwoOrderStage.observes, TwoOrderStage.failure]

private theorem TwoOrderStage.failure_injective {j : ℕ} :
    Function.Injective (TwoOrderStage.failure : TwoOrderStage j → ℕ) := by
  intro s t h
  cases s with
  | primary i =>
    cases t with
    | primary k => exact congrArg TwoOrderStage.primary (Fin.ext h)
    | secondary =>
      have hi := i.isLt
      simp [TwoOrderStage.failure] at h
      omega
  | secondary =>
    cases t with
    | primary k =>
      have hk := k.isLt
      simp [TwoOrderStage.failure] at h
      omega
    | secondary => rfl

variable {A : Type*}

/-- Every exterior direction has one owner, located by its first original
failure. The secondary stage handles the case where that failure is last. -/
theorem two_order_owner_unique {j : ℕ} (S : Set A) (w : ℕ → A)
    (hout : ∃ i < j + 2, w i ∉ S) :
    ∃! s : TwoOrderStage j, (∀ i < s.failure, w i ∈ S) ∧ w s.failure ∉ S := by
  classical
  have he : ∃ i, w i ∉ S := by
    obtain ⟨i, _, hi⟩ := hout
    exact ⟨i, hi⟩
  let k := Nat.find he
  have hk : k < j + 2 := by
    obtain ⟨i, hi, hwi⟩ := hout
    exact (Nat.find_min' he hwi).trans_lt hi
  have hs : ∃ t : TwoOrderStage j, t.failure = k := by
    by_cases hj : k < j + 1
    · exact ⟨.primary ⟨k, hj⟩, rfl⟩
    · exact ⟨.secondary, show j + 1 = k by omega⟩
  obtain ⟨s, hsk⟩ := hs
  have ha : (∀ i < s.failure, w i ∈ S) ∧ w s.failure ∉ S := by
    rw [hsk]
    exact ⟨fun i hi => not_not.mp (Nat.find_min he hi), Nat.find_spec he⟩
  refine ⟨s, ha, fun t ht => TwoOrderStage.failure_injective ?_⟩
  apply le_antisymm
  · exact le_of_not_gt (fun h => ha.2 (ht.1 _ h))
  · exact le_of_not_gt (fun h => ht.2 (ha.1 _ h))

/-- Each stage leaves at least one of the j+2 coordinate factors free. -/
theorem two_order_unobserved_coordinate {j : ℕ} (s : TwoOrderStage j) :
    ∃ i < j + 2, ¬ s.observes i := by
  cases s with
  | primary k =>
    refine ⟨j + 1, by omega, ?_⟩
    have hk := k.isLt
    change ¬ j + 1 ≤ k.val
    omega
  | secondary =>
    exact ⟨j, by omega, by simp [TwoOrderStage.observes]⟩

variable [AddCommGroup A]

/-- The class and prefix center attached to a hard-host pool. -/
structure TwoOrderPaschPool (S : Set A) (j : ℕ) where
  stage : TwoOrderStage j
  band : Set A
  midpoint_outside : ∀ {x y z}, x ∈ band → y ∈ band → z + z = x + y → z ∉ S
  centerSum : ℕ → A

def TwoOrderPaschPool.Owns {S : Set A} {j : ℕ} (p : TwoOrderPaschPool S j)
    (u v : ℕ → A) : Prop :=
  (∀ k < p.stage.failure, v k - u k ∈ S) ∧
  (∀ k, p.stage.observes k → u k + v k = p.centerSum k) ∧
  v p.stage.failure - u p.stage.failure ∈ p.band

private theorem not_lt_of_two_order_alternation
    {S : Set A} {j : ℕ} (p q : TwoOrderPaschPool S j)
    {u₁ u₂ v₁ v₂ : ℕ → A} (h₁₁ : p.Owns u₁ v₁) (h₂₂ : p.Owns u₂ v₂)
    (h₁₂ : q.Owns u₁ v₂) : ¬ p.stage.failure < q.stage.failure := by
  intro hlt
  let k := p.stage.failure
  have hc : u₁ k + v₁ k = u₂ k + v₂ k :=
    (h₁₁.2.1 k p.stage.observes_failure).trans (h₂₂.2.1 k p.stage.observes_failure).symm
  apply p.midpoint_outside h₁₁.2.2 h₂₂.2.2 _ (h₁₂.1 k hlt)
  calc
    (v₂ k - u₁ k) + (v₂ k - u₁ k) =
        (v₁ k - u₁ k) + (v₂ k - u₂ k) + ((u₂ k + v₂ k) - (u₁ k + v₁ k)) := by abel
    _ = (v₁ k - u₁ k) + (v₂ k - u₂ k) := by rw [hc, sub_self, add_zero]

/-- An alternating cycle of owned bases lies in one stage and the same
prefix fibers. With a deterministic band label, all four bases use one
physical block. -/
theorem alternating_two_order_same_prefix
    (hdouble : Function.Injective (fun x : A => x + x))
    {S : Set A} {j : ℕ} (p q : TwoOrderPaschPool S j)
    {u₁ u₂ v₁ v₂ : ℕ → A} (h₁₁ : p.Owns u₁ v₁) (h₂₂ : p.Owns u₂ v₂)
    (h₁₂ : q.Owns u₁ v₂) (h₂₁ : q.Owns u₂ v₁) :
    p.stage = q.stage ∧ ∀ k, p.stage.observes k →
      u₁ k = u₂ k ∧ v₁ k = v₂ k ∧ p.centerSum k = q.centerSum k := by
  have hs : p.stage = q.stage := TwoOrderStage.failure_injective
    (le_antisymm
      (Nat.le_of_not_gt (not_lt_of_two_order_alternation q p h₁₂ h₂₁ h₁₁))
      (Nat.le_of_not_gt (not_lt_of_two_order_alternation p q h₁₁ h₂₂ h₁₂)))
  refine ⟨hs, fun k hk => ?_⟩
  have hk' : q.stage.observes k := hs ▸ hk
  have hp := (h₁₁.2.1 k hk).trans (h₂₂.2.1 k hk).symm
  have hq := (h₁₂.2.1 k hk').trans (h₂₁.2.1 k hk').symm
  have hu : u₁ k = u₂ k := hdouble (calc
    u₁ k + u₁ k = (u₁ k + v₁ k) + (u₁ k + v₂ k) - (v₁ k + v₂ k) := by abel
    _ = (u₂ k + v₂ k) + (u₂ k + v₁ k) - (v₁ k + v₂ k) := by rw [hp, hq]
    _ = u₂ k + u₂ k := by abel)
  have hv : v₁ k = v₂ k := add_left_cancel (by simpa only [← hu] using hp)
  exact ⟨hu, hv, (h₁₁.2.1 k hk).symm.trans ((congrArg (u₁ k + ·) hv).trans (h₁₂.2.1 k hk'))⟩

end SplitGapIII
