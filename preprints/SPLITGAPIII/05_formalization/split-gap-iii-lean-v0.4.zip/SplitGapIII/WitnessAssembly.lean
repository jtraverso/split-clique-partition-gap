module

public import SplitGapIII.ResidualPadding
public import SplitGapIII.TerminalClique

@[expose] public section

namespace SplitGapIII
open Finset GapExtremal QuadraticExteriorPalomar GapExtremal.R434

/-- Old hosts, the three mixed pools, a terminal pool, and padding to the exact order. -/
abbrev WitnessHosts (H : Type*) (s q : ℕ) := H ⊕ ((Fin 3 × Fin s) ⊕ (Fin s ⊕ Fin q))

variable {V H W : Type} [Fintype V] [DecidableEq V] [Fintype H] [DecidableEq H]
variable [Fintype W] [DecidableEq W]

/-- The full split silhouette. Every host sees W before crossing deletions. -/
def witnessPalettes (old : H → Finset V) (color : V → Fin 3) (s q : ℕ) :
    WitnessHosts H s q → Finset (V ⊕ W)
  | .inl h => (old h).disjSum univ
  | .inr (.inl (c, _)) => (univ.filter fun v => color v = c).disjSum univ
  | .inr (.inr _) => (∅ : Finset V).disjSum univ

/-- The chosen assignment is typed by the parts of the two endpoints. -/
def witnessAssignment (old : V → V → H) (color : V → Fin 3) {s q : ℕ}
    (mixed : V → W → Fin s) (last : W → W → Fin s) :
    V ⊕ W → V ⊕ W → WitnessHosts H s q
  | .inl a, .inl b => .inl (old a b)
  | .inl a, .inr b => .inr (.inl (color a, mixed a b))
  | .inr a, .inl b => .inr (.inl (color b, mixed b a))
  | .inr a, .inr b => .inr (.inr (.inl (last a b)))

/-- Conditions on the physical selections. They are imposed on the surviving palettes. -/
structure WitnessSelection (B : SimpleGraph V) (color : V → Fin 3) {s q : ℕ}
    (live : WitnessHosts H s q → Finset (V ⊕ W)) where
  old : V → V → H
  mixed : V → W → Fin s
  last : W → W → Fin s
  oldHyp : HostHyp B (fun h => (live (.inl h)).toLeft) old
  mixedMem : ∀ a b, Sum.inl a ∈ live (.inr (.inl (color a, mixed a b))) ∧
    Sum.inr b ∈ live (.inr (.inl (color a, mixed a b)))
  mixedLeft : ∀ a b b', mixed a b = mixed a b' → b = b'
  mixedRight : ∀ a a' b, color a = color a' → mixed a b = mixed a' b → a = a'
  lastMem : ∀ a b, a ≠ b → Sum.inr a ∈ live (.inr (.inr (.inl (last a b)))) ∧
    Sum.inr b ∈ live (.inr (.inr (.inl (last a b))))
  lastSymm : ∀ a b, last a b = last b a
  lastInj : ∀ a b b', a ≠ b → a ≠ b' → last a b = last a b' → b = b'

/-- All three stages assemble in one split graph, using only original surviving radios. -/
theorem assembled_host_hyp (B : SimpleGraph V) [DecidableRel B.Adj]
    (color : V → Fin 3) (proper : ∀ a b, B.Adj a b → color a ≠ color b)
    (oldN : H → Finset V) {s q : ℕ} (live : WitnessHosts H s q → Finset (V ⊕ W))
    (subset : ∀ h, live h ⊆ witnessPalettes oldN color s q h)
    (select : WitnessSelection B color live) :
    HostHyp (withIsolates (X := W) B) live (witnessAssignment (q := q) select.old color select.mixed select.last) := by
  constructor
  · intro h a ha b hb hab
    rcases a with a | a <;> rcases b with b | b
    · have hab' := (isolates_adj_inl B a b).mp hab
      rcases h with h | (⟨c,k⟩ | (i | j))
      · exact select.oldHyp.indep h a (by simpa [mem_toLeft] using ha)
          b (by simpa [mem_toLeft] using hb) hab'
      · have ha' : color a = c := by simpa [witnessPalettes] using subset _ ha
        have hb' : color b = c := by simpa [witnessPalettes] using subset _ hb
        exact proper a b hab' (ha'.trans hb'.symm)
      · have ha' := subset _ ha
        simp [witnessPalettes] at ha'
      · have ha' := subset _ ha
        simp [witnessPalettes] at ha'
    · exact isolates_not_adj_inr B _ _ hab
    · exact isolates_not_adj_inr B _ _ hab.symm
    · exact isolates_not_adj_inr B _ _ hab
  · intro a b hne hnadj
    rcases a with a | a <;> rcases b with b | b
    · simpa [witnessAssignment, mem_toLeft] using
        select.oldHyp.cover a b (fun e => hne (congrArg Sum.inl e))
          (fun e => hnadj ((isolates_adj_inl B a b).mpr e))
    · exact select.mixedMem a b
    · exact (select.mixedMem b a).symm
    · exact select.lastMem a b (fun e => hne (congrArg Sum.inr e))
  · rintro (a|a) (b|b) <;> simp [witnessAssignment, select.oldHyp.symm, select.lastSymm]
  · intro a b b' hab ha hab' ha' he
    rcases a with a | a <;> rcases b with b | b <;> rcases b' with b' | b'
    all_goals simp only [witnessAssignment, Sum.inl.injEq, Sum.inr.injEq, Sum.inl_ne_inr,
      Sum.inr_ne_inl, Prod.mk.injEq] at he
    all_goals try contradiction
    · exact congrArg Sum.inl (select.oldHyp.inj a b b'
        (fun e => hab (congrArg Sum.inl e)) (fun e => ha ((isolates_adj_inl B a b).mpr e))
        (fun e => hab' (congrArg Sum.inl e)) (fun e => ha' ((isolates_adj_inl B a b').mpr e)) he)
    · exact congrArg Sum.inr (select.mixedLeft a b b' he.2)
    · exact congrArg Sum.inl (select.mixedRight b b' a he.1 he.2)
    · exact congrArg Sum.inr (select.lastInj a b b'
        (fun e => hab (congrArg Sum.inr e)) (fun e => hab' (congrArg Sum.inr e)) he)


/-- A complete rectangular block can be assigned from its actual surviving lists. -/
theorem recover_rectangle {A X F : Type*} [Fintype A] [Fintype X]
    (lists : A × X → Finset F) (d : ℕ) (ha : Fintype.card A ≤ d) (hx : Fintype.card X ≤ d)
    (large : ∀ e, d ≤ (lists e).card) :
    ∃ f : A × X → F, (∀ e, f e ∈ lists e) ∧
      GalvinMultigraph.Proper Prod.fst Prod.snd f := by
  apply recover_bipartite Prod.fst Prod.snd lists d _ _ large
  · intro a
    let eqv : {e : A × X // e.1 = a} ≃ X :=
      ⟨fun e => e.val.2, fun x => ⟨(a,x), rfl⟩,
        fun ⟨⟨_,_⟩,he⟩ => by subst_vars; rfl, fun _ => rfl⟩
    rw [Nat.card_congr eqv, Nat.card_eq_fintype_card]
    exact hx
  · intro x
    let eqv : {e : A × X // e.2 = x} ≃ A :=
      ⟨fun e => e.val.1, fun a => ⟨(a,x), rfl⟩,
        fun ⟨⟨_,_⟩,he⟩ => by subst_vars; rfl, fun _ => rfl⟩
    rw [Nat.card_congr eqv, Nat.card_eq_fintype_card]
    exact ha

/-- Lists of hosts for a mixed pair, read from the surviving graph. -/
def witnessMixedList {s q : ℕ} (live : WitnessHosts H s q → Finset (V ⊕ W))
    (color : V → Fin 3) (a : V) (b : W) : Finset (Fin s) :=
  univ.filter fun h => Sum.inl a ∈ live (.inr (.inl (color a,h))) ∧
    Sum.inr b ∈ live (.inr (.inl (color a,h)))

/-- Lists read from the terminal host pool for pairs internal to W. -/
def witnessTerminalList {s q : ℕ} (live : WitnessHosts H s q → Finset (V ⊕ W))
    (e : (⊤ : SimpleGraph W).edgeSet) : Finset (Fin s) :=
  univ.filter fun h => corePair Function.Embedding.inr e ⊆ live (.inr (.inr (.inl h)))

set_option maxHeartbeats 800000 in
/-- The two new stages are constructed from actual lists. Only the original-core
assignment is supplied to this assembler. -/
theorem witness_selection_of_lists (B : SimpleGraph V) (color : V → Fin 3)
    {s q : ℕ} (hs : 0 < s) (live : WitnessHosts H s q → Finset (V ⊕ W))
    (old : V → V → H) (oldHyp : HostHyp B (fun h => (live (.inl h)).toLeft) old)
    (hw : Fintype.card V ≤ Fintype.card W)
    (mixLarge : ∀ a b, Fintype.card W ≤ (witnessMixedList live color a b).card)
    (lastLarge : ∀ e, Fintype.card W ≤ (witnessTerminalList live e).card) :
    Nonempty (WitnessSelection B color live) := by
  classical
  have pick (c : Fin 3) : ∃ f : {a // color a = c} × W → Fin s,
      (∀ e, f e ∈ witnessMixedList live color e.1.val e.2) ∧
        GalvinMultigraph.Proper Prod.fst Prod.snd f := by
    have hc : Fintype.card {a // color a = c} ≤ Fintype.card V :=
      Fintype.card_le_of_injective Subtype.val Subtype.val_injective
    exact recover_rectangle (A := {a : V // color a = c}) (X := W)
      (fun e => witnessMixedList live color e.1.val e.2) (Fintype.card W)
      (hc.trans hw) le_rfl (fun _ => mixLarge _ _)
  choose f hf hfp using pick
  let mixed (a : V) (b : W) := f (color a) (⟨a, rfl⟩, b)
  obtain ⟨tail, htail⟩ := recover_complete (witnessTerminalList live) lastLarge
  let edge (a b : W) (h : a ≠ b) : (⊤ : SimpleGraph W).edgeSet :=
    ⟨s(a,b), by simpa using h⟩
  let last (a b : W) : Fin s :=
    if h : a ≠ b then tail (edge a b h) else ⟨0, hs⟩
  refine ⟨{ old := old, mixed := mixed, last := last, oldHyp := oldHyp
            mixedMem := ?_, mixedLeft := ?_, mixedRight := ?_, lastMem := ?_
            lastSymm := ?_, lastInj := ?_ }⟩
  · intro a b
    exact (mem_filter.mp (hf (color a) (⟨a, rfl⟩, b))).2
  · intro a b b' hh
    by_contra hne
    exact hfp (color a) (⟨a, rfl⟩, b) (⟨a, rfl⟩, b')
      (fun h => hne (congrArg Prod.snd h)) (Or.inl rfl) hh
  · intro a a' b hc hh
    have compare (i i' : Fin 3) (eq : i=i') (u : {a // color a = i})
        (v : {a // color a = i'}) (he : f i (u,b) = f i' (v,b)) : u.val = v.val := by
      subst i'
      by_contra hn
      exact hfp i (u,b) (v,b) (fun h => hn (congrArg (fun p => p.1.val) h)) (Or.inr rfl) he
    exact compare _ _ hc ⟨a,rfl⟩ ⟨a',rfl⟩ hh
  · intro a b h
    have hp := (mem_filter.mp (htail (edge a b h))).2
    have ha : (Sum.inr a : V ⊕ W) ∈ corePair Function.Embedding.inr (edge a b h) := by
      apply mem_map.mpr
      exact ⟨a, Sym2.mem_toFinset.mpr (by simp [edge]), rfl⟩
    have hb : (Sum.inr b : V ⊕ W) ∈ corePair Function.Embedding.inr (edge a b h) := by
      apply mem_map.mpr
      exact ⟨b, Sym2.mem_toFinset.mpr (by simp [edge]), rfl⟩
    simpa only [last, dif_pos h] using And.intro (hp ha) (hp hb)
  · intro a b
    by_cases h : a = b
    · subst b
      rfl
    · have hs' : b ≠ a := fun he => h he.symm
      have he : edge a b h = edge b a hs' := Subtype.ext Sym2.eq_swap
      simp only [last, dif_pos h, dif_pos hs', he]
  · intro a b b' h h' he
    have eq : tail (edge a b h) = tail (edge a b' h') := by simpa [last, h, h'] using he
    by_contra hne
    have hdiff : edge a b h ≠ edge a b' h' := by
      intro hd
      have hp := Sym2.eq_iff.mp (congrArg Subtype.val hd)
      exact (hp.elim (fun k => hne k.2) (fun k => h' k.1))
    exact tail.valid (SimpleGraph.lineGraph_adj_iff_exists.mpr
      ⟨hdiff, a, by simp [edge], by simp [edge]⟩) eq

/-- The explicit split graph has the prescribed order after consuming the remaining padding. -/
theorem witness_order (n s : ℕ)
    (budget : Fintype.card V + Fintype.card W + Fintype.card H + 4*s ≤ n) :
    Fintype.card ((V ⊕ W) ⊕ WitnessHosts H s
      (n - (Fintype.card V + Fintype.card W + Fintype.card H + 4*s))) = n := by
  simp only [WitnessHosts, Fintype.card_sum, Fintype.card_prod, Fintype.card_fin]
  omega

/-- The integral and fractional residual score certificates of the original core
bound the gap of the explicit padded graph after any compatible reassignment. -/
theorem witness_scores (B : SimpleGraph V) [DecidableRel B.Adj]
    (color : V → Fin 3) (proper : ∀ a b, B.Adj a b → color a ≠ color b)
    (oldN : H → Finset V) {s q : ℕ} (live : WitnessHosts H s q → Finset (V ⊕ W))
    (subset : ∀ h, live h ⊆ witnessPalettes oldN color s q h)
    (select : WitnessSelection B color live)
    (I : ℤ) (hi : ∀ P : Finset (Finset V), IsPack P → ∑ Q ∈ P, w B Q ≤ I)
    (y : Finset V → ℝ) (hy : ResPack y) :
    (∑ Q, y Q * (w B Q : ℝ)) - I ≤ gap (hostGraph live) := by
  obtain ⟨z, hz, hscore⟩ := isolate_fractional_lift (X := W) B hy
  rw [← hscore]
  exact gap_ge (assembled_host_hyp B color proper oldN live subset select) I
    (isolate_integral_bound B I hi) hz

/-- At the exact order, recover the mixed and terminal assignments from the surviving
lists and transfer the original-core score certificates to the resulting graph. -/
theorem witness_of_surviving_lists (B : SimpleGraph V) [DecidableRel B.Adj]
    (color : V → Fin 3) (proper : ∀ a b, B.Adj a b → color a ≠ color b)
    (oldN : H → Finset V) (n : ℕ) {s q : ℕ} (hs : 0 < s)
    (order : Fintype.card V + Fintype.card W + Fintype.card H + 4*s + q = n)
    (live : WitnessHosts H s q → Finset (V ⊕ W))
    (subset : ∀ h, live h ⊆ witnessPalettes oldN color s q h)
    (old : V → V → H) (oldHyp : HostHyp B (fun h => (live (.inl h)).toLeft) old)
    (hw : Fintype.card V ≤ Fintype.card W)
    (mixLarge : ∀ a b, Fintype.card W ≤ (witnessMixedList live color a b).card)
    (lastLarge : ∀ e, Fintype.card W ≤ (witnessTerminalList live e).card)
    (I : ℤ) (hi : ∀ P : Finset (Finset V), IsPack P → ∑ Q ∈ P, w B Q ≤ I)
    (y : Finset V → ℝ) (hy : ResPack y) :
    Fintype.card ((V ⊕ W) ⊕ WitnessHosts H s q) = n ∧
      gap (hostGraph live) = residualSup (withIsolates (X := W) B) -
        residualInt (withIsolates (X := W) B) ∧
      (∑ Q, y Q * (w B Q : ℝ)) - I ≤ gap (hostGraph live) := by
  obtain ⟨select⟩ := witness_selection_of_lists B color hs live old oldHyp hw mixLarge lastLarge
  refine ⟨?_, gap_eq_residual_difference (assembled_host_hyp B color proper oldN live subset select),
    witness_scores B color proper oldN live subset select I hi y hy⟩
  simp only [WitnessHosts, Fintype.card_sum, Fintype.card_prod, Fintype.card_fin]
  omega

end SplitGapIII
