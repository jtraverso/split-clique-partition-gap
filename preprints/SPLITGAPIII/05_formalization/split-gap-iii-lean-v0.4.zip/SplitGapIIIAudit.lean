import SplitGapIII.PartICylinders
import SplitGapIII.PrefixStatistics
import SplitGapIII.TerminalClique
import SplitGapIII.RecoveryProbability
import SplitGapIII.SharedSeed
import SplitGapIII.PartIWitness
import SplitGapIII.OriginalOrder
import SplitGapIII.AllOrders
import SplitGapIII.PaschBlocks
import SplitGapIII.PhysicalRadioCertificate
import SplitGapIII.AveragedRadioSeed
import SplitGapIII.TwoOrderPasch
import SplitGapIII.GlobalPasch
import SplitGapIII.HostedPaschShape
import SplitGapIII.HostedCliqueDeficit
import SplitGapIII.SelectedStatistics

#print axioms SplitGapIII.centerFiber_card
#print axioms SplitGapIII.recover_center_fiber
#print axioms SplitGapIII.assemble_groups
#print axioms SplitGapIII.assemble_prefix_and_terminal
#print axioms SplitGapIII.trim_two_lists
#print axioms SplitGapIII.gap_of_complete_recovery
#print axioms SplitGapIII.physical_survival_bound
#print axioms SplitGapIII.deletion_count_tail
#print axioms SplitGapIII.probability_gap_deviation
#print axioms SplitGapIII.failure_tendsto_zero
#print axioms SplitGapIII.exact_gap_after_terminal_clique
#print axioms SplitGapIII.joint_order_with_fiber_growth
#print axioms SplitGapIII.partI_linear_parameters
#print axioms SplitGapIII.partI_cylinders_at_order
#print axioms SplitGapIII.product_grid_fiber_card
#print axioms SplitGapIII.monitored_copies_budget
#print axioms SplitGapIII.assemble_prefix_and_terminal_preserving
#print axioms SplitGapIII.monitor_shift_le_terminal_card
#print axioms SplitGapIII.shared_reserve_local_bound
#print axioms SplitGapIII.shared_reserve_joint_bound
#print axioms SplitGapIII.extend_shared_lists
#print axioms SplitGapIII.uniform_seed_saturation
#print axioms SplitGapIII.uniform_seed_port_slack
#print axioms SplitGapIII.host_hyp_of_assigned
#print axioms SplitGapIII.assembled_host_hyp
#print axioms SplitGapIII.witness_selection_of_lists
#print axioms SplitGapIII.witness_order
#print axioms SplitGapIII.witness_of_surviving_lists
#print axioms SplitGapIII.partI_score_certificates
#print axioms SplitGapIII.partI_witness_of_group_solutions
#print axioms SplitGapIII.oldPairGroup_swap
#print axioms SplitGapIII.oldPalettes_pair
#print axioms SplitGapIII.oldPalettes_independent
#print axioms SplitGapIII.oldIncidence_bound
#print axioms SplitGapIII.oldBaseHosts_card
#print axioms SplitGapIII.old_assignment_of_lists
#print axioms SplitGapIII.recover_witness_from_counts
#print axioms SplitGapIII.original_witness_probability
#print axioms SplitGapIII.original_host_budget
#print axioms SplitGapIII.original_padding_parameters
#print axioms SplitGapIII.witness_test_count
#print axioms SplitGapIII.old_group_minimum
#print axioms SplitGapIII.witness_tail_sum_le
#print axioms SplitGapIII.original_gap_without_deletions
#print axioms SplitGapIII.original_parameters_all_orders
#print axioms SplitGapIII.split_gap_recovery_all_orders
#print axioms SplitGapIII.all_orders_error_tendsto_zero
#print axioms SplitGapIII.alternating_bundles_same_prefix
#print axioms SplitGapIII.grid_double_injective
#print axioms SplitGapIII.partI_band_midpoint_outside
#print axioms SplitGapIII.exists_radio_factor_of_cuts
#print axioms SplitGapIII.exists_surviving_radio_palettes
#print axioms SplitGapIII.rounded_host_degrees
#print axioms SplitGapIII.rounded_even_host_degrees
#print axioms SplitGapIII.common_hosts_after_losses
#print axioms SplitGapIII.rectangleSeed_radio_margins
#print axioms SplitGapIII.rectangleSeed_base_deficit_zero_margins
#print axioms SplitGapIII.rectangle_switch_expansion
#print axioms SplitGapIII.exists_radio_neutral_correction
#print axioms SplitGapIII.bipartite_integer_certificate
#print axioms SplitGapIII.bipartite_integer_certificate_of_cuts
#print axioms SplitGapIII.two_order_owner_unique
#print axioms SplitGapIII.two_order_unobserved_coordinate
#print axioms SplitGapIII.alternating_two_order_same_prefix
#print axioms SplitGapIII.exists_bounded_radio_correction
#print axioms SplitGapIII.exists_positive_bipartite_seed
#print axioms SplitGapIII.alternating_same_basePool
#print axioms SplitGapIII.alternating_same_ownedBlock
#print axioms SplitGapIII.alternating_candidates_one_block
#print axioms SplitGapIII.clique_integer_switch_generation
#print axioms SplitGapIII.hosted_switch_mem
#print axioms SplitGapIII.hosted_clique_deficit_mem
#print axioms SplitGapIII.physical_hinges_ge_completions
#print axioms SplitGapIII.selected_hinge_condition
#print axioms SplitGapIII.selected_decomposition_with_reference_targets
#print axioms SplitGapIII.hosted_pasch_alternates
#print axioms SplitGapIII.hosted_pasch_one_block
